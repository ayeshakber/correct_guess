<?php

Class Notification
{
    public function __construct() {
        // Notification
        add_action('wp_footer', array($this, 'notify_javascript'));
        add_action('wp_ajax_notify', array($this, 'notify_callback'));
        add_action('wp_ajax_nopriv_notify', array($this, 'notify_callback'));
        // NOTIFY SHORTCODE
        add_shortcode('notify', array($this, 'notify_html'));
    }

    public function notify_javascript() {
        ?>

        <script type="text/javascript">
            /* In front end of WordPress we have to define ajaxurl */
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
            var ajaxurl2 = '<?php echo PLUGIN_HTTP_URL . 'include/notifications/notify-update.php' ?>';

            jQuery(document).ready(function ($) {
                setInterval(function () {
                    var data = {
                        'action': 'notify_update',
                        'request': 'update_notify',
                    };
                    $.post(ajaxurl2, data, function (response) {
                        var result = response.split("|");
                        jQuery('.notifications').html(result[0]);
                        jQuery('.notiy-count').html(result[1]);
                    });
                }, 3000);


                jQuery(document).on('click', '.read-notify', function () {
                    var notify_to = jQuery(this).attr('id');
                    var data = {
                        'action': 'notify',
                        'notify_to': notify_to,
                        'request': 'update_notify',
                    };
                    $.post(ajaxurl, data, function (response) {
                    });
                });

            });
        </script>
        <?php
    }

    public function notify_callback() {
        $notify_to = $_POST['notify_to'];
        $request = $_POST['request'];

        $notifications = get_user_meta(get_current_user_id(), 'notify', true);
        $counter = 0;
        $new_notify = array();
        if (!empty($notifications)) {
            foreach ($notifications as $notify) {
                if ($counter == $notify_to) {
                    $notify['read'] = '1';
                }
                //update_user_meta();
                $counter++;
                $new_notify[] = $notify;
            }
        }
        update_user_meta(get_current_user_id(), 'notify', $new_notify);
        print_r($new_notify);

        die();
    }

    public function notify_html() {
        $notifications = get_user_meta(get_current_user_id(), 'notify', true);
        $counter = 0;
        $html = '';

        if (!is_user_logged_in())
            return true;

        $html .= '<div class="notifibox">';
        $html .= '<h3>Notification</h3>';
        $html .= $this->notify_count();
        if (!empty($notifications)) {
            $notifications = array_reverse($notifications);
            $html .= '<div class="notifications">';
            $counter = count($notifications) - 1;
            foreach ($notifications as $notify) {
                if ($notify['Type'] == 'Offer') {
                    $link = get_permalink(get_page_by_path('offer')) . '?task_id=' . $notify['t_id'] . '&user_id=' . $notify['m_uid'];
                } else if ($notify['Type'] == 'Message') {
                    $link = get_permalink(get_page_by_path('chats')) . '?task_id=' . $notify['t_id'] . '&user_id=' . $notify['m_uid'];
                }
                if ($notify['read'] == 0)
                    $html .= '<div class="read-notify unread" id="' . $counter-- . '"><a href="' . $link . '"><span>' . $notify['text'] . '</span>' . $notify['msg'] . '</a></div>';
                else
                    $html .= '<div class="read-notify" id="' . $counter-- . '"><a href="' . $link . '"><span>' . $notify['text'] . '</span>' . $notify['msg'] . '</a></div>';
            }
            $html .= '<div class="seeall">See All</div></div>';
        } else {
            $html .= '<div class="notifications">';
            $html .= '<div class="read-notify" >-- No Notification --</div>';
            $html .= '<div class="seeall">See All</div></div>';
        }

        $html .= '</div>';
        return $html;
    }

    public function notify_count() {
        $notifications = get_user_meta(get_current_user_id(), 'notify', true);
        $counter = 1;
        $notify_count = 0;
        if (!empty($notifications)) {
            $notifications = array_reverse($notifications);
            foreach ($notifications as $notify) {
                if ($notify['read'] == 0)
                    $notify_count = $counter++;
            }
        }

        if (!empty($notify_count))
            return '<div class="notiy-count">' . $notify_count . '</div>';
    }

    public function send_notification($type, $read, $text, $msg, $m_uid, $t_id, $notify_to) {

    }
}