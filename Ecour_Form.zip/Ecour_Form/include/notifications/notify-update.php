<?php

include '../../../../../wp-config.php';

$user_id = get_current_user_id();
 global $post;
  $post_id = $post->ID;
    $author_id = $post->post_author;
    $post_title= $post->post_title;
        /*echo "<br>POST ID:";
        print_r($post_id);
        echo "<br>Author ID:";
        print_r($author_id);
        echo "<br>POST title:";
        print_r($post_title);*/



  $post_accepted = get_post_meta($post_id,'offer_accepted',true);//user id

if($_POST['request'] == 'update_notify') {
    $html = '<h3>Notification</h3>';

    $notifications = get_user_meta(get_current_user_id(),'notify',true);
    $counter = 0; $html = '';
    if(!empty($notifications)) {
       // $html .= '<div class="notifibox">';
        $notifications = array_reverse($notifications);
       // $html .= '<h3>Notification1</h3>';
        //$html .= notify_count();
        //$html .= '<div class="notifications">';
        $counter = count($notifications) - 1;
        foreach($notifications as $notify) {
            if($notify['Type'] == 'Offer') {

                $link = get_permalink(get_page_by_path('offer')) . '?task_id='.$notify['t_id'] . '&user_id=' . $notify['m_uid'];

            } else if($notify['Type'] == 'Message') {
                $link = get_permalink(get_page_by_path('chats')) . '?task_id='.$notify['t_id']. '&user_id=' . $notify['m_uid'];
            }
            if($notify['read'] == 0)
                $html .= '<div class="read-notify unread" id="'.$counter--.'"><a href="'.$link.'"><span>'.$notify['text'].'</span>' . $notify['msg'] . '</a></div>';
            else
                $html .= '<div class="read-notify" id="'.$counter--.'"><a href="'.$link.'"><span>'.$notify['text'].'</span>' . $notify['msg'] . '</a></div>';
        }
        $html .= '<div class="seeall">See All</div>
        <!-- </div>
        </div> -->';
    } else {
        //$html .= '<div class="notifications">';
        $html .= '<div class="read-notify" >-- No Notification --</div>';
        $html .= '<div class="seeall">See All</div>';
    }

    echo $html . '|' . notify_count();
}


function notify_count() {
    $notifications = get_user_meta(get_current_user_id(),'notify',true);
    $counter = 1;

    if(!empty($notifications)) {
        $notifications = array_reverse($notifications);
        foreach($notifications as $notify) {
            if($notify['read'] == 0)
                $notify_count = $counter++;
        }
    }
    return $notify_count;
}