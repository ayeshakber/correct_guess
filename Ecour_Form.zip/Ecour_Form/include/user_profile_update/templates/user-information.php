<?php
get_header();
?>
<script src="http://code.jquery.com/ui/1.9.1/jquery-ui.js"></script>
<!-- credit card validation check AISHA -->
<!-- <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script> -->
<!-- credit card validation check AISHA -->

<?php
do_action('save_information');
$user_id = get_current_user_id();
?>
<style>
      #locationField, #controls {
        position: relative;
        width: 480px;
      }
      #autocomplete {
        position: absolute;
        top: 0px;
        left: 0px;
        width: 99%;
      }
      .label {
        text-align: right;
        font-weight: bold;
        width: 100px;
        color: #303030;
      }
      #address {
        border: 1px solid #000090;
        background-color: #f0f0ff;
        width: 480px;
        padding-right: 2px;
      }
      #address td {
        font-size: 10pt;
      }
      .field {
        width: 99%;
      }
      .slimField {
        width: 80px;
      }
      .wideField {
        width: 200px;
      }
      #locationField {
        height: 20px;
        margin-bottom: 2px;
      }
    </style>
<div class="main-user-profile-page">
	<div class="side-user-profile-dashboard">
		<div id="tabs">
    <ul>
    <li>
    	<h1>Your wallet</h1>
    </li>
        <li>
            <a href="#payment">Payment details</a>
        </li>
       <!--  <li>
            <a href="#coupon">Coupons</a>
        </li> -->
        <li>
            <h1>Account settings</h1>
        </li>
        <!--<li>
            <a href="#Notifications">Notifications</a>
        </li>-->
		<li>
			<a href="#personal-info">Personal info</a>
		</li>
    </ul>
    <div id="payment">
	
        <h1>Payment details</h1>
		<p>All of your payment and payout information</p>
		<h4>Payment methods</h4>
		
			<h4><a href="javascript:void(0);"><i class="fa fa-plus-square myplus" aria-hidden="true"></i></a>Add your Credit or Debit Card</h4>
			<p>Fill in the information, click the button, and you're ready to go! What you are sending will then be insured and you won't be charged anything until delivery is confirmed.</p>
			<div class="light_box_user_profile">
			<form action="#" method="post" id="myform">
			<div class="info-container">
			<?php
			$url = plugin_dir_url( $file );
			$images_full_url = $url.'Ecour_Form/images/'
			?>
          <img src="<?php echo $images_full_url; ?>icon-card-visa.png" class="info visa-logo" style="width:50px;">
          <img src="<?php echo $images_full_url; ?>icon-card-mastercard.png" class="info mastercard-logo" style="width:50px;">
          <img src="<?php echo $images_full_url; ?>icon-card-amex.png" class="info amex-logo" style="width:50px;">
          <div class="info secure-payments">Secure Payments</div>
        </div>
		<div class="main-prof">
			<div class="frm-div">
				<label>Name on card</label>
				<?php
					
					$cartholdername = get_user_meta($user_id,'cardholder_name',true);
					if(!empty($cartholdername)){
						?>
						<input id="cardholder-name" name="cardholder_name" type="text" value="<?php echo $cartholdername; ?>" class="cc-name">
				<?php
					}
					else{
				?>
				<input id="cardholder-name" name="cardholder_name" type="text" data-stripe="name" required="" aria-required="true" placeholder="Full name on the front side" class="cc-name">
				<?php
					}
				?>
			</div>
			<div class="frm-div">
				<!-- <form id="myform"> -->
					<label for="credit_card_number">Card number</label>
					<?php
						$credit_card_number = get_user_meta($user_id,'credit_card_detail',true);
						if(!empty($credit_card_number)){
							?>
							<input type="tel" id="credit_card_number" name="credit_card_number" value="<?php echo $credit_card_number['card_num'];  ?>" class="cc-number">
							<?php
						}
						else{
						?>
						<input type="tel" id="credit_card_number" name="credit_card_number" data-stripe="number" required="" aria-required="true" placeholder="e.g. 4000056655665556" pattern="[0-9]*" class="cc-number">
						<?php					
						}
					?>
				<!-- </form> -->
			</div>
			<div class="frm-div">
			<fieldset class="cc-date-fieldset">
          <label for="credit-card-exp-year">Expiry date</label> 
          <!-- <label>Expiry date</label> -->
          <div class="dropdowns-wrapper">
            <div class="custom-dropdown custom-dropdown card-date-dropdown card-date-dropdown--month">
			<?php
			$credit_card_exp_month = get_user_meta($user_id,'credit_card_exp_month',true);
			
			$exp_month_html = '';
			for($i=1;$i<=12;$i++) {
				if($credit_card_exp_month == $i)
					$exp_month_html .= '<option selected value="'.$i.'">'.$i.'</option>';
				else
					$exp_month_html .= '<option value="'.$i.'">'.$i.'</option>';
			}
			?>
				<select data-stripe="exp-month" name="credit_card_exp_month" id="credit-card-exp-month" class="custom-dropdown card-date-dropdown card-date-dropdown--month">
				 <?php echo $exp_month_html ?>
				</select>
			</div>
			<div class="custom-dropdown custom-dropdown card-date-dropdown card-date-dropdown--year">
			<?php
			$credit_card_exp_month = get_user_meta($user_id,'credit_card_exp_year',true);
			$exp_year_html = '';
			for($j=2016;$j<=2041;$j++){
				if($j==$credit_card_exp_month){
					$exp_year_html .= '<option selected value="'.$j.'">'.$j.'</option>';
				}
				else{
					$exp_year_html .= '<option value="'.$j.'">'.$j.'</option>';
				}
			}
			
			?>
				<select data-stripe="exp-year" name="credit_card_exp_year" id="credit-card-exp-year" required="" aria-required="true" class="custom-dropdown card-date-dropdown card-date-dropdown--year">
					  <?php echo $exp_year_html ; ?>
				</select>
			</div>
          </div><!-- dropdowns-wrapper -->
        </fieldset>
		</div>
		<div class="frm-div">
		<fieldset class="cc-cvv-fieldset form-group">
          <!-- CVV -->
          <label for="cvv">CVV/CCV</label>
		  <?php
			$cvv = get_user_meta($user_id,'credit_card_detail',true);
			if(!empty($cvv)){
				?>
			<input type="tel" name="cvvs"  id="cvv" class="cc-cvc" value="<?php echo $cvv['card_csv']; ?>">
			<?php	
			}
			else{
			?>
			<input type="tel" name="cvvs" data-stripe="cvc" id="cvv" required="" aria-required="true" class="cc-cvc" placeholder="e.g. 123" pattern="[0-9]*">
			<?php			
			}
		  ?>
          <div class="error-message hidden">
              <img src="/public/images/icon-notice.svg" alt="!" class="error-message__icon">
              Should be 3 digits
          </div>
        </fieldset>
		</div>
		<div class="frm-div">
			<div class="payment-form__cta">
			<button type="submit" name="payment_info_btn" class="submit-button button-red" data-disable-with="Authorising...">
			  Authorise card
			</button>
		  </div>
		 </div>
		</div>
		</form>
		</div>
		<h4>Payout methods</h4>
		<div class="main_head_secnd">
			<p>You have no bank accounts yet</p>
			<a href="javascript:void(0);" class="banck_ac"><span>Add a new bank account</span></a>
		</div>
		<div class="newbankaccount">
			<form action="#" method="post">
				<div class="country_main" style="display:none;">
					<a href="javascript:void(0);" class="btn-bank-type-close-btn"><i class="fa fa-times" aria-hidden="true"></i></a>
					<div class="choose_you_count">
					<label>Choose Your Country</label>
					<?php
						$country = get_user_meta($user_id,'country',true);
						$countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");
						?>
						<select name="country" class="language-dropdown js-chooser-dropdown" id="change-country-chooser">
						<?php
						foreach($countries as $value){
							if($value==$country){
								?>
								<option value="<?php echo $value ;?>" selected><?php echo $value; ?></option>
								<?php
							}
							else{
								?>
								 <option value="<?php echo $value ;?>"><?php echo $value ;?></option>
								<?php
							}
							
						}
					?>
						</select>
					</div>
					<div class="btn-continue-desc">
						<input type="button" name="countinue_btns" id="continue_btns" class="ctns_btns" value="Continue"/>
					</div>
				</div>
				<div class="continue_banck_account_detail" style="display:none;">
					<a href="javascript:void(0);" class="btn-bank-type-close">x</a>
					<h1>Add your bank account</h1>
					<p>When you add your bank account the first time we need to confirm your personal information</p>
					<div class="user_info_inner">
						<div class="sub_inner_info">
							<label>Account Type</label>
							<?php
								$bank_ac_type = get_user_meta($user_id,'banck_ac_type',true);
								if($bank_ac_type=="Personal"){
									?>
									<input type="radio" name="personal" id="personal" value="Personal" checked="checked"><span>Personal</span>
									<input type="radio" name="personal" id="personal" value="Business"><span>Business</span>
									<?php
								}
								else{
									?>
									<input type="radio" name="personal" id="personal" value="Personal" ><span>Personal</span>
									<input type="radio" name="personal" id="personal" value="Business" checked="checked"><span>Business</span>
									<?php
								}
							?>
						</div>
						<div class="sub_inner_info">
							<label>Name</label>
							<?php
							$bank_account_holder_name = get_user_meta($user_id,'bank_account_holder_name',true);
							if(!empty($bank_account_holder_name)){
									?>
									<input type="text" name="ac_holder_name" id="ac_holder_name" value="<?php echo $bank_account_holder_name;?>">
									<?php
							}
							else{
								?>
								<input type="text" name="ac_holder_name" id="ac_holder_name" value="" placeholder="Account holders name">
								<?php
							}
							?>
						</div>
						<div class="sub_inner_info">
							<label>Account Number</label>
							<?php
							$bank_account_number = get_user_meta($user_id,'bank_account_number',true);
							if(!empty($bank_account_number)){
								?>
								<input type="text" name="ac_holder_no" id="ac_holder_no" value="<?php echo $bank_account_number; ?>">
								<?php
							}
							else{
								?>
								<input type="text" name="ac_holder_no" id="ac_holder_no" value="" placeholder="eg: 0001234">
								<?php
							}
							?>
						</div>
						<div class="sub_inner_info">
							<label>Rounting Account Number</label>
							<?php
								$bank_rounting_number = get_user_meta($user_id,'bank_rounting_number',true);
								if(!empty($bank_rounting_number)){
										?>
										<input type="text" name="routing_ac_holder_no" id="routing_ac_holder_no" value="<?php echo $bank_rounting_number; ?>">
										<?php
								}
								else{
									?>
									<input type="text" name="routing_ac_holder_no" id="routing_ac_holder_no" placeholder="eg: 0001234">
									<?php
								}
							?>
						</div>
						<div class="sub_inner_info">
							<label>Currency</label>
							<select data-stripe="currency" name="currencys" id="currency" class="currency-dropdown">
							<?php
							$currency = get_user_meta($user_id,'currency',true);
							$currency_type = array("EUR","USD","GBP");
							foreach($currency_type as $value_type){
								if($value_type==$currency){
									?>
									<option value="<?php echo $value_type; ?>" selected><?php echo $value_type; ?></option>
									<?php
								}
								else{
									?>
									<option value="<?php echo $value_type; ?>"><?php echo $value_type; ?></option>
									<?php
								}
							}
							?>
							</select>
						</div>
						<div class="sub_inner_info">
							<input type="submit" name="bank_account_save" id="bank_account_save" value="Save Changes" disabled="disabled">
						</div>
					</div>
				</div>
			</form>
		</div>
    </div>
    <!-- <div id="coupon">
		<form action="#" method="post">
        <h1>Coupons</h1>
		<p>Apply coupons codes and offers to your account.</p>
		<h4>Have a coupon code?</h4>
		<div class="main-left-coupon">
			<div class="flds-coupon">
				<?php
					$code_coupon = get_user_meta($user_id,'code_coupon',true);
					if(!empty($code_coupon)){
						?>
						<input type="text" name="code_coupon" id="code-coupon" value="<?php echo $code_coupon; ?>">
						<?php
					}
					else{
						?>
						<input type="text" name="code_coupon" id="code-coupon" value="" placeholder="Enter Your Coupon Code">
						<?php
					}
				?>
			</div>
			<div class="redeem-coupon">
				<input type="submit" name="redeem_button" id="redeem_button" value="Redeem"/>
			</div>
		</div>
		</form>
    </div> -->
    <!--<div id="Notifications">
       <h1>Notifications</h1>
    </div>-->
    <div id="personal-info">
		<form action="#" method="post">
        <header class="page-header">
			  <h2 class="page-header__title">
				Personal info
			  </h2>
			  <p class="page-header__intro">
				Edit or add more personal info to your account.
			  </p>
		</header>
		<div class="profile_update_main">
			<div class="image_profile">
				<div class="flds_file_uploads">
				<?php
					$profile_picss = get_user_meta($user_id,'profile_pic',true);
					if(empty($profile_picss)){
						$profile_pic = get_avatar_url($user_id);
						?>
						<img alt="Upload your photo" src="<?php echo $profile_pic; ?>" title="Upload your photo" width="200" id="defulat_pic">
						<div class = "full-wd upload-form">
							<?php $upload_dir = wp_upload_dir(); ?>
							<div class="loader_animated" style="display:none;">
							<img src="<?php echo $upload_dir['baseurl']; ?>/ajax-loader.gif"/></div>
							<div class= "upload-response" style="display:none;"></div>
							<!--<div class="profile_imgs"><img src="<?php //echo $profile_picss; ?>" width="200"></div>-->
							<div class = "form-group photo_upload">
								<label><?php __('Select Files:', 'cvf-upload'); ?></label>
								<input type = "file" name = "files[]" accept = "image/*" class = "files-data form-control" multiple />
							</div>
							<div class = "form-group full-wd">
								<input type = "submit" value = "Import File" class = "btn btn-primary btn-upload" />
							</div>
						</div>
						<?php
					}
					else{
						?>
						<div class = "full-wd upload-form">
							<?php $upload_dir = wp_upload_dir(); ?>
							<div class="loader_animated" style="display:none;">
							<img src="<?php echo $upload_dir['baseurl']; ?>/ajax-loader.gif"/></div>
							<div class= "upload-response"></div>
							<div class="profile_imgs"><img src="<?php echo $profile_picss; ?>" width="200"></div>
							<div class = "form-group changepicbutton photo_upload">
								<label><?php __('Select Files:', 'cvf-upload'); ?></label>
								<input type = "file" name = "files[]" accept = "image/*" class = "files-data form-control" multiple />
							</div>
							<div class = "form-group full-wd">
								<input type = "submit" value = "Import File" class = "btn btn-primary btn-upload" />
							</div>
						</div>
						<?php
					}

				?>



				</div>
			</div>

			<!--<div class="changepicbutton">
			<button>Change Your Photo</button>
			</div>-->
			<div class="areawithin">
			<div class="first_flds">
				<label> First Name</label>
				<?php
				$firstname = get_user_meta($user_id,'first_name',true);
				if(!empty($firstname)){
					?>
					<input type="text" name="firstname" id="firstname" value="<?php echo $firstname; ?>"/>
					<?php
				}
				else{
					?>
					<input type="text" name="firstname" id="firstname" value=""/>
					<?php
				}
				?>
				
			</div>
			<div class="last_flds">
				<label> Last Name</label>
				<?php
				$last_name = get_user_meta($user_id,'last_name',true);
				if(!empty($last_name)){
					?>
					<input type="text" name="lastname" id="lastname" value="<?php echo $last_name; ?>"/>
					<?php
				}
				else{
					?>
					<input type="text" name="lastname" id="lastname" value=""/>
					<?php
				}
				?>
				
			</div>
			<div class="email_flds_address">
				<label> Email Address</label>
				<?php
				$author_obj = get_user_by('id', $user_id);
				if(!empty($author_obj->user_email)){
					?>
					<input type="email" name="email" id="email" value="<?php echo $author_obj->user_email ?>"/>
					<?php
				}
				else{
					?>
					<input type="email" name="email" id="email" value=""/>
					<?php
				}
				?>
				
			</div>
			<div class="first_flds address_maps">
				<label> Address</label>
				<?php
				$address = get_user_meta($user_id,'user_location',true);
				if(!empty($address)){
					?>
					<div id="locationField">
						<input id="autocomplete" name="address" placeholder="Enter your address" onFocus="geolocate()" type="text" value="<?php echo $address; ?>"></input>
					</div>
					<?php
				}
				else{
					?>
					<div id="locationField">
						<input id="autocomplete" name="address" placeholder="Enter your address" onFocus="geolocate()" type="text"></input>
					</div>
					<?php
				}
				?>
				
			</div>
			<div class="email_flds_addressnumber">
				<label> Mobile Number</label>
				<?php 
						$user_country_codes = get_user_meta($user_id,'user_country_code',true);
						$country_mb_code = explode('_',$user_country_codes);
						
						$countryCallingCodes = array(93 => "Afghanistan",355 => "Albania",213 => "Algeria",1 => "American Samoa",376 => "Andorra",244 => "Angola",1 => "Anguilla", 1 => "Antigua and Barbuda", 54 =>"Argentina",374 =>"Armenia", 297 => "Aruba", 247 => "Ascension", 61 => "Australia", 43 => "Austria",994 => "Azerbaijan", 1 => "Bahamas", 973 => "Bahrain", 880 => "Bangladesh", 1 => "Barbados", 375 => "Belarus", 32 => "Belgium", 501 => "Belize", 229 => "Benin", 1 => "Bermuda",975 => "Bhutan", 591 => "Bolivia", 387 => "Bosnia and Herzegovina",267=>"Botswana",55 => "Brazil", 1 => "British Virgin Islands", 673 => "Brunei", 359 => "Bulgaria",226 => "Burkina Faso", 257 => "Burundi", 855 => "Cambodia", 237 => "Cameroon", 1 => "Canada",238 => "Cape Verde", 1 => "Cayman Islands", 236 => "Central African Republic",235 => "Chad",	56 => "Chile", 86 => "China", 57 => "Colombia", 269 => "Comoros", 242 => "Congo",682 => "Cook Islands", 506 => "Costa Rica", 385 => "Croatia", 53 => "Cuba", 357 => "Cyprus",420 => "Czech Republic", 243 => "Democratic Republic of Congo", 45 => "Denmark",246 => "Diego Garcia", 253 => "Djibouti", 1 => "Dominica", 1 => "Dominican Republic",670 => "East Timor", 593 => "Ecuador", 20 => "Egypt", 503 => "El Salvador",240 => "Equatorial Guinea", 291 => "Eritrea", 372 => "Estonia", 251 => "Ethiopia",500 => "Falkland (Malvinas) Islands", 298 => "Faroe Islands", 679 => "Fiji", 358 =>"Finland",33 => "France", 594 => "French Guiana", 689 => "French Polynesia", 241 => "Gabon",220 => "Gambia", 995 => "Georgia", 49 => "Germany", 233 => "Ghana", 350 => "Gibraltar",30 => "Greece", 299 => "Greenland", 1 => "Grenada", 590 => "Guadeloupe", 1 => "Guam",502 => "Guatemala",224 => "Guinea",245 => "Guinea-Bissau",592 => "Guyana",509 => "Haiti",504 => "Honduras",852 => "Hong Kong",36 => "Hungary",354 => "Iceland",91 => "India",62 => "Indonesia",870  => "Inmarsat Satellite",98 => "Iran",964 => "Iraq",353 => "Ireland",972 => "Israel",39 => "Italy",225 => "Ivory Coast",1 => "Jamaica",81 => "Japan",962 => "Jordan",7 => "Kazakhstan",254 => "Kenya",686 => "Kiribati",965 => "Kuwait",996 => "Kyrgyzstan",856 => "Laos",371 => "Latvia",961 => "Lebanon",266 => "Lesotho",231 => "Liberia",218 => "Libya",423 => "Liechtenstein",370 => "Lithuania",352 => "Luxembourg",853 => "Macau",389 => "Macedonia",261 => "Madagascar",265 => "Malawi",60 => "Malaysia",960 => "Maldives",223 => "Mali",356 => "Malta",692 => "Marshall Islands",596 => "Martinique",222 => "Mauritania",230 => "Mauritius",262 => "Mayotte",52 => "Mexico",691 => "Micronesia",373 => "Moldova",377 => "Monaco",976 => "Mongolia",382 => "Montenegro",1 => "Montserrat",212 => "Morocco",258 => "Mozambique",95 => "Myanmar",264 => "Namibia",674 => "Nauru",977 => "Nepal",31 => "Netherlands",599 => "Netherlands Antilles",687 => "New Caledonia",64 => "New Zealand",505 => "Nicaragua",227 => "Niger",234 => "Nigeria",683 => "Niue Island",850 => "North Korea",1 => "Northern Marianas",47 => "Norway",968 => "Oman",92 => "Pakistan",680 => "Palau",507 => "Panama",675 => "Papua New Guinea",595 => "Paraguay",51 => "Peru",63 => "Philippines",48 => "Poland",351 => "Portugal",1 => "Puerto Rico",974 => "Qatar",262 => "Reunion",40 => "Romania",7 => "Russian Federation",250 => "Rwanda",290 => "Saint Helena",1 => "Saint Kitts and Nevis",1 => "Saint Lucia",508 => "Saint Pierre and Miquelon",1 => "Saint Vincent and the Grenadines",685 => "Samoa",378 => "San Marino",239 => "Sao Tome and Principe",966 => "Saudi Arabia",221 => "Senegal",381 => "Serbia",248 => "Seychelles",232 => "Sierra Leone",65 => "Singapore",421 => "Slovakia",386 => "Slovenia",677 => "Solomon Islands",252 => "Somalia",27 => "South Africa",82 => "South Korea",34 => "Spain",94 => "Sri Lanka",249 => "Sudan",597 => "Suriname",268 => "Swaziland",46 => "Sweden",41 => "Switzerland",963 => "Syria",886 => "Taiwan",992 => "Tajikistan",255 => "Tanzania",66 => "Thailand",228 => "Togo",690 => "Tokelau",1 => "Trinidad and Tobago",216 => "Tunisia",90 => "Turkey",993 => "Turkmenistan",1 => "Turks and Caicos Islands",688 => "Tuvalu",256 => "Uganda",380 => "Ukraine",971 => "United Arab Emirates",44 => "United Kingdom",1 => "United States of America",1 => "U.S. Virgin Islands",598 => "Uruguay",998 => "Uzbekistan",678 => "Vanuatu",379 => "Vatican City",58 => "Venezuela",84 => "Vietnam",681 => "Wallis and Futuna",967 => "Yemen",260 => "Zambia",263 => "Zimbabwe");
				?>
				<select id="user_country_phone_code" class="" name="user_country_phone_code">
				<?php
					foreach($countryCallingCodes as $countryCallingCodes_key => $value){
						if($countryCallingCodes_key==$country_mb_code[0]){
							?>
							<option value="<?php echo $countryCallingCodes_key; ?>" selected>
								<?php echo $countryCallingCodes_key; ?>
							</option>
							<?php
						}
						else{
							?>
							<option value="<?php echo $countryCallingCodes_key; ?>">
								<?php echo $countryCallingCodes_key; ?>
							</option>
							<?php	
						}
					}
				?>
				</select>
				
			</div>
			<div class="country_phone_numbers">
				<label> Country Phone Number</label>
				<?php
					$phone_number = get_user_meta($user_id,'user_phone',true);
					if(!empty($phone_number)){
						?>
						<input type="text" name="country_ph_number" id="country_ph_number" value="<?php echo $phone_number; ?>"/>
						<?php
					}
					else{
						?>
						<input type="text" name="country_ph_number" id="country_ph_number" value=""/>
						<?php
					}
				?>
				
			</div>
			<div class="password_flds_address">
				<label> Old Password Type</label>
				<input type="password" name="old_pass" id="old_pass" value=""/>
			</div>
			<div class="password_flds_address">
				<label> New Password Type</label>
				<input type="password" name="new_pass" id="new_pass" value=""/>
			</div>
			<div class="btm_flds_address">
				<input type="submit" name="update_info_btn" id="update_info_btn" value="Save Changes"/>
			</div>
		</div>
		</div>
	</form>
    </div>
</div>

	</div>
</div>
<!-- credit card validation AISHA -->
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
<link rel="stylesheet" href="https://jqueryvalidation.org/files/demo/site-demos.css">
<!-- credit card validation AISHA -->
<script>
	jQuery(document).ready(function() 
	{
		//when credit card enter to check validation of card AISHA
		/*jQuery('#credit-card-number').on('blur',function()
		{*/
			//alert('working..');
	// just for the demos, avoids form submit
			/*jQuery.validator.setDefaults({
			  debug: true,
			  success: "valid"
			});
			jQuery("#myform").validate({
			  rules: {
			    credit_card_number: {
			      required: true,
			      creditcard: true
			    }
			  }
			});*/

		/*});*/
		

	//when credit card enter to check validation of card AISHA
		// When the Upload button is clicked...
		jQuery('body').on('click', '.upload-form .btn-upload', function(e)
		{
			e.preventDefault();
			// alert("work");
			var fd = new FormData();
			var files_data = jQuery('.upload-form .files-data'); // The <input type="file" /> field

			// Loop through each data and create an array file[] containing our files data.
			jQuery.each(jQuery(files_data), function(i, obj) {
				jQuery.each(obj.files,function(j,file){
					fd.append('files[' + j + ']', file);
				})
			});

			// our AJAX identifier
			fd.append('action', 'cvf_upload_files1');

			// uncomment this code if you do not want to associate your uploads to the current page.
			jQuery('.loader_animated').show();
			jQuery.ajax({
				type: 'POST',
				url: '<?php echo admin_url( 'admin-ajax.php' ); ?>',
				data: fd,
				contentType: false,
				processData: false,
				success: function(response){
					jQuery('.upload-response').html(response); // Append Server Response
					jQuery('#defulat_pic').hide();
					jQuery('.upload-response').show();
					jQuery('#defulat_pic').hide();
				}
			});
		});
	});

</script>
<?php
if(is_page('user-information')){
	?>
	<script>
		jQuery(document).ready(function(){
			jQuery('#tabs').tabs().addClass('ui-tabs-vertical ui-helper-clearfix');
		});
		
	</script>
	<script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD7Ci8YotJST7w5Ud1OKLzvHkHyk6PGJPs&libraries=places&callback=initAutocomplete"
         async defer></script>
		 <script>
			jQuery(document).ready(function(){
				var maps = jQuery('#pac-input').wrapAll();
				jQuery('.address_maps label').after(maps);
			});
		 </script>
	<?php
}

get_footer();
?>