<?php get_header(); ?>
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<div id="primary" class="content-area" style="width:50%">
    <main id="main" class="site-main" role="main">
        <?php
        do_action('task_header');
        global $post;
        #step 1. GET CURRENT POST ID
        #$post_ID =$_GET['task_id'];
        $post_ID =$post->ID;
		$post_ID = $_GET['task_id'];
		$get_user_id = $_GET['user_id'];
		#print_r($post_ID);
        #step 2. GET AUTHOR ID BY POST ID
        $post_author = get_post_field( 'post_author', $post_ID );
        $post_title = get_post_field( 'post_name', $post_ID );
       /* echo "<br>POST NAME: ";
			print_r($post_title);
		*/
		/*print_r('POST ID Sender');
		die('sender');*/
        #GET CURRENT USER ID
        $user_id= get_current_user_id();
        $post_interested = get_post_meta($post_ID,'task_offers',true);
		#print_r($post_interested);
		#echo '<br>';

        # step3. GET ALL CHATS BY AUTHOR ID
        #if($user_id == $post_author)
        ### FOR MESSAGE SEND ###
        $html = '';
        $class = '';
        $user_name = '';
        $user_email = '';
        $user_phone = '';
        ###OFFER ACCEPTED Condition###
		if(isset($_POST['accepted']))
		{
			$post_accepted = update_post_meta($post_ID,'offer_accepted',$get_user_id);
			
			$user_accepted = get_user_meta($get_user_id,'offer_accepted',true);
			if(!empty($user_accepted))
			{
				$user_accepted = update_user_meta($get_user_id,'offer_accepted',$user_accepted.'_'.$post_ID);
			}
			else
			{
				$user_accepted = update_user_meta($get_user_id,'offer_accepted',$post_ID);

			}
            #NOTIFICATION#
            $old_notify = get_user_meta($_GET['user_id'],'notify',true);
            $user_index = count($old_notify) - 1;
            # $msg = explode('|',$_POST['message_details']);
            $notify['Type'] = 'Message';
            $notify['read'] = '0';
            $notify['text'] = 'New Message';
            $notify['msg'] = 'OFFER ACCEPTED';
            $notify['m_uid'] = get_current_user_id();
            $notify['t_id'] = $_GET['task_id'];
            $new_notify = $old_notify;
            $new_notify[] = $notify;
            $url= site_url();
            ## START NOTIFICATION SHORTCODE AISHA ##
			$u_id = $_GET['user_id'];
			$noti = $notify['text'];

			$link = $url.'/offer/'.$post_title;
            echo do_shortcode( '[wpun_notification title="Offer ACCEPTED" user_id = "'.$u_id.'" message="'.$noti.'" type = "MESSAGE" link="'.$link.'"]') ;
             //echo do_shortcode( '[wpun_notification title="new MESSAGE" user_id = "98" message="hello ayesha, this is my first msg" type = "MESSAGE" ]') ;
            
            ## END NOTIFICATION SHORTCODE AISHA##

            update_user_meta($_GET['user_id'],'notify',$new_notify);
            #NOTIFICATION#

			#echo 'Your Offer has been Accepted';	
			
			wp_redirect( $url.'/task/'.$post_title );
			exit;	
		} 
		#####OFFER  REJECTED Condition#####
		if(isset($_POST['rejected']))
		{
			echo 'Your Offer has been Rejected';
			$post_interested = get_post_meta($post_ID,'task_offers',true);
			/* echo '<pre>';
			print_r($post_interested);
			echo '</pre>'; */
			$array = removeElementWithValue($post_interested, "3", $get_user_id);
			/* echo '<pre>';
			print_r($array);
			echo '</pre>'; */
			$post_interested = update_post_meta($post_ID,'task_offers',$array);
			/* echo '<pre>';
			print_r($post_interested);
			echo '</pre>';*/
            $u_id = $_GET['user_id'];
            $noti = $notify['text'];

            $link = $url.'/offer/'.$post_title;
            echo do_shortcode( '[wpun_notification title="Offer Rejected :(" user_id = "'.$u_id.'" message="'.$noti.'" type = "MESSAGE" link=""]') ;
		}
        if(!empty($post_interested) && is_array($post_interested) )
		{
			$user_id_in_msg ='';
			$post_accepted = get_post_meta($post_ID,'offer_accepted',true);
			#print_r($post_accepted);
			#print_r($post_accepted);
            foreach ($post_interested as $value)
			{
                $user_id_in_msg = $value[3];
				#print_r($user_id_in_msg );
                $user_msg = $value[0];
				#print_r($get_user_id );
				if($get_user_id == $value[3])
				{
					$user_info = get_userdata($get_user_id);
					$user_name = $user_info->display_name;
					$user_email = $user_info->user_email;
					$user_phone = get_user_meta($get_user_id,'user_phone',true);
					$user_msg = $value[0];
					$offer_date = $value[2];
					$time_ago = humanTiming ($value[2]);
					$profile_link = get_permalink(get_page_by_path('ecour-profile-page')).$get_user_id;

					$user_photo = get_user_meta($get_user_id,'photo',true);
					if(empty($user_photo))
					{
						$user_photo = get_avatar_url($get_user_id);
					}
					$accept_msg ='';
					if($post_accepted == $get_user_id)
					{
						$accept_msg ='You have accept this offer.';
						#echo $accept_msg;
						
					}
					else
					{
						#$task_completed = get_post_meta($post_ID,'task_completed',true);
						$accept_msg = '<form action="" method="POST" > <div class="accept"><input type="submit" class="accept-offer" value="Accept" name="accepted" /> <input type="submit" value="Reject" class="reject-offer" name="rejected" /></div></form>';
						#echo $accept_msg;
					}

					$html = '<div class="row">
					<div class="col-sm-6">
					<div class="offer-msg"> <img src="'.$user_photo.'" width="40"/><div class="user-offer-name">'.$user_name.'</div> <div class="offer-body"> <div class="offer-trip"></div> <p class="user-offer-msg">' .$user_msg . '</p><p class="offer-date">'.$offer_date.'</p>'.$accept_msg.' 
						</div></div>
					</div>
					<div class="col-sm-6">
					<div><a href="'.$profile_link.'">'.$user_name.'</a></div>					
					<div>'.$user_email.'</div>					
					<div>'.$user_phone.'</div>';
					$html .= '<div>';
		            $user_views = get_user_meta($get_user_id,'user_rate_on_profile',true);
		            if(!empty($user_views))
		            {
		                $view_count = count($user_views);
		                $average = 0;
		                $rating_1 = 0;
		                foreach ($user_views as $rating)
		                {
		                    $rating_1 += $rating['user_rating'];
		                    $average = $rating_1 / count($user_views);
		                   /* echo '<br>';*/
							$average  = round($average , 1);
							#print_r($average);
		                }
		                $html .='<div class="average"> '.$average .' &#9733;</div>';
		        		$html .='<div class="reviews-count"> '.(count($user_views).'reviews').'</div>';
					}
			        $html .= '</div>';
			        $html .= '</div>';
				}
            }

	        $stripe_payment = '';
			if($post_accepted == $get_user_id)
			{
				$task_completed = get_post_meta($post_ID,'task_completed',true);
				if(empty($task_completed))
				{
					$stripe_payment = 'Please Wait! Your Task is Being Process.';
				}
				else
				{
					$stripe_payment = do_shortcode ('[accept_stripe_payment button_text="Press when task is delivered" ]');
				}
				
			}
			echo $stripe_payment;
        }
		echo $html;
	  
	  ####FOR REMOVE SPECIFIC VALUE OF MULTI DIMENSIONAL ARRAY########
		function removeElementWithValue($array, $key, $value)
		{
			foreach($array as $subKey => $subArray)
			{
			 if($subArray[$key] == $value)
			 {
				  unset($array[$subKey]);
			 }
			}
			return $array;
		}

        ##count time ago##
        function humanTiming ($time)
        {
            $time = strtotime($time);
            $time = time() - $time;	 # to get the time since that moment
            $time = ($time<1)? 1 : $time;
            $tokens = array (
                31536000 => 'year',
                2592000 => 'month',
                604800 => 'week',
                86400 => 'day',
                3600 => 'hour',
                60 => 'minute',
                1 => 'second',
            );
            foreach ($tokens as $unit => $text)
            {
                if ($time < $unit) continue;
                $numberOfUnits = floor($time / $unit);
                return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'');
            }
        }
  