<?php get_header(); ?>
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

        <?php
        do_action('task_header');
        global $post;
        #step 1. GET CURRENT POST ID
        $post_ID =$_GET['task_id'];

        #step 2. GET AUTHOR ID BY POST ID
        $post_author = get_post_field( 'post_author', $post_ID );

        #GET CURRENT USER ID
        $user_id= get_current_user_id();
        $post_msgs = get_post_meta($post_ID,'message',true);

        # step3. GET ALL CHATS BY AUTHOR ID
        #if($user_id == $post_author)

        ### FOR MESSAGE SEND ###
        $html = '';
        $class = '';



        ### FOR MESSAGE SEND ###
        $user_info = get_userdata($post_author);
        $html .= '<div class="conversation-user">Conversation with '.$user_info->user_login.'</div>';

        $html .= '<div class="conversation-notify">Make certain you make an offer and it is accepted. Once it\'s accepted the item will be insured and you\'ll be paid after delivery.</div>';

        $html .= '<div class="load-msg-btn"><button>LOAD PREVIOUS MESSAGES</button></div>';

        $html .= '<div class="chats">';
        $counter = 0;
        if(!empty($post_msgs)) {
            foreach ($post_msgs as $value)  {
                $user_id_in_msg = $value[3];
                $user_msg = $value[0];

                if($user_id == $value[3])
                    $class = 'msg-right';
                else
                    $class = 'msg-left';

                $user_photo = get_user_meta($value[3],'photo',true);
                if(empty($user_photo))
                {
                    $user_photo = get_avatar_url($value[3]);
                }
                $time_ago = humanTiming ($value[5]);
                //print_r($time_ago);

                $html .= '<div class="chat-msg '.$class.'"> <img src="'.$user_photo.'" width="40"/> <div class="msg-body"> <div class="trip"></div> <p class="user-msg">' .$value[0] . '</p> ' .'<p>'. $time_ago.' ago</p> </div>'. '</div>';
                //$html .= $time_ago;

            }
        }
        $html .= '</div>
               ';

        $html .= '<div class="chat-box">
                     <textarea name="task_msg" class="task_msg" id="task_msg"></textarea> 
                     <input type="button" name="send_msg" class="send_msg" id="send_msg" value="SEND"> 
                     
                     <input type="hidden" name="sender_ID" class="sender_ID" id="sender_ID" value="'.$user_id.'"> 
                     <input type="hidden" name="post_ID" class="post_ID" id="post_ID" value="'.$post_ID.'"> 
                     <input type="hidden" name="user_id" class="user_ID" id="user_ID" value="'.$_GET['user_id'].'"> 
                 <div>';

        // echo $html;



        ##count time ago##
        function humanTiming ($time)
        {
            $time = strtotime($time);
            $time = time() - $time; // to get the time since that moment
            $time = ($time<1)? 1 : $time;
            $tokens = array (
                31536000 => 'year',
                2592000 => 'month',
                604800 => 'week',
                86400 => 'day',
                3600 => 'hour',
                60 => 'minute',
                1 => 'second',
            );
            foreach ($tokens as $unit => $text)
            {
                if ($time < $unit) continue;
                $numberOfUnits = floor($time / $unit);
                return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'');
            }
        }

        $html .= '<div id="map" style="width: 100%;height:200px"></div>
                  
                  <button class="wishlist">&#10084; Save to wishlist</button> 
                  ';

        $html .= '<div class="task-details">
                        <div class="task-item-detail">
                            <div class="task-labels"></div>
                            <div class="task-value">Report task</div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Info</div>
                            <div class="task-value"><p>The item is insured for any damage up to 1000€</p></div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Size</div>
                            <div class="task-value">'.get_post_meta($post_ID, 'size' ,true).'</div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Must be delivered by end of:</div>';

        $html .='<div class="task-value">'.get_post_meta($post_ID, 'delivery_flex', true). ' '.get_post_meta($post_ID,'select_time',true).'</div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Reward:</div>
                            <div class="task-value">'.get_post_meta($post_ID,'payment_amount',true).'Rs<p>Nimber will transfer this amount to your bank account, after delivery is confirmed.</p></div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Picked up from:</div>
                            <div class="task-value">'.get_post_meta($post_ID, 'pic_up', true).'</div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Delivered to:</div>
                            <div class="task-value">'.get_post_meta($post_ID, 'delievery_address', true).'</div>
                        </div>                     
                  </div>';
        echo $html;
        //        echo '<div id="map-canvas" style="border: 2px solid #3872ac;"></div>';

        $pic_up_address = get_post_meta($post_ID,'pic_up',true);
        $delivery_address = get_post_meta($post_ID,'delievery_address',true);

        $pick_up_geo = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyDhdrBLLfR9cHxtYHO5SyC3135TuN1h9vw&address='.urlencode($pic_up_address).'&sensor=false');

        //echo 'lat' . print_r($pick_up_geo);
        //die();


        $pick_up_geo = json_decode($pick_up_geo, true);

        if ($pick_up_geo['status'] = 'OK') {

            $latitude = (float) $pick_up_geo['results'][0]['geometry']['location']['lat'];

            $longitude = (float) $pick_up_geo['results'][0]['geometry']['location']['lng'];
        }

        $delivery_address_geo = file_get_contents('http://maps.googleapis.com/maps/api/geocode/json?address='.urlencode($delivery_address).'&sensor=false');

        $delivery_address_geo = json_decode($delivery_address_geo, true);

        if ($delivery_address_geo['status'] = 'OK') {

            $d_latitude = (float) $delivery_address_geo['results'][0]['geometry']['location']['lat'];

            $d_longitude = (float) $delivery_address_geo['results'][0]['geometry']['location']['lng'];
        }
        ?>
        <script>
            var marker1, marker2;
            var poly, geodesicPoly;

            function initMap() {
                var map = new google.maps.Map(document.getElementById('map'), {
                    zoom: 4,
                    center: {lat: 34, lng: -40.605}
                });

                map.controls[google.maps.ControlPosition.TOP_CENTER].push(
                    document.getElementById('info'));

                marker1 = new google.maps.Marker({
                    map: map,
                    draggable: false,
                    position: {lat: <?php echo $latitude?>, lng: <?php echo $longitude?>}
                });

                marker2 = new google.maps.Marker({
                    map: map,
                    draggable: false,
                    position: {lat: <?php echo $d_latitude?>, lng: <?php echo $d_longitude?>}
                });

                var bounds = new google.maps.LatLngBounds(
                    marker1.getPosition(), marker2.getPosition());
                map.fitBounds(bounds);

                google.maps.event.addListener(marker1, 'position_changed', update);
                google.maps.event.addListener(marker2, 'position_changed', update);

                poly = new google.maps.Polyline({
                    strokeColor: '#FF0000',
                    strokeOpacity: 1.0,
                    strokeWeight: 3,
                    map: map,
                });

                geodesicPoly = new google.maps.Polyline({
                    strokeColor: '#CC0099',
                    strokeOpacity: 1.0,
                    strokeWeight: 3,
                    geodesic: true,
                    map: map
                });

                update();
            }

            function update() {
                var path = [marker1.getPosition(), marker2.getPosition()];
                var heading = '';
                poly.setPath(path);
                geodesicPoly.setPath(path);
                heading = google.maps.geometry.spherical.computeHeading(path[0], path[1]);
                document.getElementById('heading').value = heading;
                document.getElementById('origin').value = path[0].toString();
                document.getElementById('destination').value = path[1].toString();
            }
        </script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCi7_en6OpMbjn7j0A251CVbLQkrHIk2_8&libraries=geometry&callback=initMap"
                async defer></script>


        <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCi7_en6OpMbjn7j0A251CVbLQkrHIk2_8&libraries=geometry&callback=init"
                 async defer></script>-->
    </main><!-- .site-main -->

    <?php //get_sidebar( 'content-bottom' ); ?>

</div><!-- .content-area -->

<?php //get_sidebar(); ?>
<?php get_footer(); ?>
