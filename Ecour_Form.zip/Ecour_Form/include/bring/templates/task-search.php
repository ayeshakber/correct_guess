<?php

get_header(); ?>

<div class="map_canvas2"></div>
<div class="map_canvas3"></div>
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
        <div class="task-search-page">

            <h3>Where are you going?</h3>
            <form action="#" method="post">
                <input type="text" id="geocomplete" name="going_from" value="<?php echo $_POST['going_from'] ?>" placeholder="Going From"/>
                <input type="text" id="geocomplete2" name="going_to" value="<?php echo $_POST['going_to'] ?>" placeholder="Going To"/>
                <div class="add-more-option"><i class="fa fa-car" aria-hidden="true"></i>MORE OPTION</div>
                <input type="hidden" value="" name="parcel_size" id="parcel-capacity">
                <!--<select name="box_size">
                    <option value="">any</option>
                    <option value="Pocket">XS - Pocket</option>
                    <option value="Bag">Small - Bag</option>
                    <option value="Car">M - Car</option>
                    <option value="Big car">L - Big Car</option>
                    <option value="Van">XL - Van</option>
                </select>-->
                <input type="submit" id="task-search" name="task_search" value="Search">
            </form>

            <div class="left-search-control">


                <div class="task-results">

                    <?php
                    global $post;

                    $post_date = $post->post_date;
                    $map_show = 0;
                    $meta_query = array();
                    if(isset($_POST['going_from']))
                    {
                        $meta_query = array(
                            'relation' => 'AND',
                            array(
                                'key' => 'pic_up',
                                'value' => $_POST['going_from'],
                                'compare' => 'LIKE',
                            ),
                            array(
                                'key' => 'delievery_address',
                                'value' => $_POST['going_to'],
                                'compare' => 'LIKE',
                            ),
                            array(
                                'key' => 'size',
                                'value' => $_POST['parcel_size'],
                                'compare' => 'LIKE',
                            ),
                            array(
                                'key' => 'delivery_flex',
                                'value' => $_POST['date'],
                                'compare' => 'LIKE',
                            ),
                        );
                    }
                    $args = array(
                        'post_status' => 'publish',
                        'post_type'   => 'task',
                        'posts_per_page' => -1,
                        'meta_query' => $meta_query
                    );
                    // The Query
                    $the_query = new WP_Query( $args );

                    // The Loop
                    if ( $the_query->have_posts() ) {
                        echo '<div class="task-list">';
                        while ( $the_query->have_posts() ) {

                            $the_query->the_post();

                            $post_author_id = $post->post_author; //author id
                           /* echo "<br>post auhtor id:";
                            print_r($post_author_id);*/

                            $current_id = get_current_user_id(); //current user id
                            /*echo "<br>curent id:";
                            print_r($current_id);*/
                            $price = '';

                            if ($current_id ==$post_author_id ) 
                            {
                                $price = get_post_meta($post->ID,'payable',true);
                            }
                            else
                            {
                                $price = get_post_meta($post->ID,'transporter_paid',true);
                            }
                          /*  echo "<br> PRICE:";
                            print_r($price);
*/
                            /*$price = get_post_meta($post->ID,'payment_amount',true);
                            if(empty($price))
                                $price = get_post_meta($post->ID,'payable',true);*/


                            echo '<div class="task-item">
                                    <div class="task-img">';

                            $select_pst = "SELECT $wpdb->posts.ID from $wpdb->posts where $wpdb->posts.post_parent='".$post->ID."' ORDER BY wp_0fb446804f_posts.`ID` DESC LIMIT 1";
                            $result = $wpdb->get_results($select_pst,object);
                            if(!empty($result)){
                                foreach($result as $keyss){
                                    echo '<img src="'.wp_get_attachment_url($keyss->ID) . '" width="100"/>';
                                }
                            }
                            else{
                                echo '<img src="https://d1xqbpwl1wh09p.cloudfront.net/jobs/default/default-s_150x150@2x.png" width="100"/>';
                            }
                            echo '</div>'.
                                '<div class="task-details"><a href="'.get_permalink().'"><h5>'. get_the_title() .'</h5></a>' .'
                                        <p class="task-from"><span>From</span> ' . get_post_meta($post->ID,'pic_up',true) . '</p>
                                        <p class="task-to"><span>To</span> ' . get_post_meta($post->ID,'delievery_address',true) . '</p>
                                    
                                    </div>
                                        <p class="task-price">£'. $price.' </p>
                                        <p class="task-date">'. humanTiming( get_the_date( 'd-M-Y H:i:s',$post->ID ) ) .'</p>
                                 </div>';
                        }
                        echo '</div>';
                        echo '</div>';
                        /* Restore original Post Data */
                        $map_show = 1;
                        wp_reset_postdata();
                    } else {
                        echo '-- No Task Found --';
                    }
                    ?>
            </div>

                <?php
                if($map_show == 1) {
                    echo '<div class="right-map">
                    <div id="map_wrapper">
                        <div id="map_canvas" style="height:150%" class="mapping"></div>
                    </div>
                </div>';
                }
                ?>


            <script>
                function initialize(post_page) {

                    if(post_page=='')
                        post_page = -1;

                    var map;
                    var bounds = new google.maps.LatLngBounds();
                    var mapOptions = {
                        mapTypeId: 'roadmap'
                    };

                    // Display a map on the page
                    map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);
//                    map.setTilt(45);
                    map.setTilt(10);

                    // Multiple Markers
                    var markers = [
                        <?php
                        $meta_query = array();
                        if(isset($_POST['going_from'])) {
                            $meta_query = array(
                                'relation' => 'AND',
                                array(
                                    'key' => 'pic_up',
                                    'value' => $_POST['going_from'],
                                    'compare' => 'LIKE',
                                ),
                                array(
                                    'key' => 'delievery_address',
                                    'value' => $_POST['going_to'],
                                    'compare' => 'LIKE',
                                ),
                                array(
                                    'key' => 'size',
                                    'value' => $_POST['parcel_size'],
                                    'compare' => 'LIKE',
                                ),
                            );
                        }

                        $args = array(
                            'post_status' => 'publish',
                            'post_type'   => 'task',
                            'posts_per_page' => -1,
                            'meta_query' => $meta_query
                        );
                        // The Query
                        $counter = 0;
                        $the_query = new WP_Query( $args );
                        if ( $the_query->have_posts() ) {
                            while ( $the_query->have_posts() ) {
                                $the_query->the_post();
                                $pick_up = get_post_meta($post->ID,'pic_up',true);

                                $pick_up_address = get_post_meta($post->ID,'pick_lat_long',true);
                                $pick_up_address = explode('_',$pick_up_address);

                                if(!empty($pick_up_address[0]) && !empty($pick_up_address[1]))
                                    echo '["'.get_the_title() . '", ' . $pick_up_address[0] .','.  $pick_up_address[1] . '],';
                                $counter++;
                            }
                            /* Restore original Post Data */
                            wp_reset_postdata();
                        }
                        ?>

                        /* ['London Eye, London', 51.503454,-0.119562],
                         ['Palace of Westminster, London', 51.499633,-0.124755]*/
                    ];

                   /* // Info Window Content
                    var infoWindowContent = [
                        ['<div class="info_content">' +
                        '<h3>London Eye</h3>' +
                        '<p>The London Eye is a giant Ferris wheel situated on the banks of the River Thames. The entire structure is 135 metres (443 ft) tall and the wheel has a diameter of 120 metres (394 ft).</p>' +        '</div>'],
                        ['<div class="info_content">' +
                        '<h3>Palace of Westminster</h3>' +
                        '<p>The Palace of Westminster is the meeting place of the House of Commons and the House of Lords, the two houses of the Parliament of the United Kingdom. Commonly known as the Houses of Parliament after its tenants.</p>' +
                        '</div>']
                    ];

                    // Display multiple markers on a map
                    var infoWindow = new google.maps.InfoWindow(), marker, i;
*/
                    // Loop through our array of markers & place each one on the map
                    for( i = 0; i < markers.length; i++ ) {
                        var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
                        bounds.extend(position);
                        marker = new google.maps.Marker({
                            position: position,
                            map: map,
                            title: markers[i][0]
                        });

                        // Allow each marker to have an info window
                        google.maps.event.addListener(marker, 'click', (function(marker, i) {
                            return function() {
                                infoWindow.setContent(infoWindowContent[i][0]);
                                infoWindow.open(map, marker);
                            }
                        })(marker, i));

                        // Automatically center the map fitting all markers on the screen
                        map.fitBounds(bounds);
                    }

                    // Override our map zoom level once our fitBounds function runs (Make sure it only runs once)
                    var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
                        <?php
                        if(!isset($_POST['going_from'])) {
                            ?> this.setZoom(1);  <?php
                        }
                        ?>

                        google.maps.event.removeListener(boundsListener);
                    });

                }
            </script>
            <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDhdrBLLfR9cHxtYHO5SyC3135TuN1h9vw&libraries=geometry&callback=initialize&libraries=places&sensor=false"
                    async defer></script>
            <?php

            function humanTiming ($time)
            {
                $time = strtotime($time);
                $time = time() - $time; // to get the time since that moment
                $time = ($time<1)? 1 : $time;
                $tokens = array (
                    31536000 => 'year',
                    2592000 => 'month',
                    604800 => 'week',
                    86400 => 'day',
                    3600 => 'hour',
                    60 => 'minute',
                    1 => 'second',
                );
                foreach ($tokens as $unit => $text)
                {
                    if ($time < $unit) continue;
                    $numberOfUnits = floor($time / $unit);
                    return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'');
                }
            }
            ?>
        </div>
    </main><!-- .site-main -->
</div><!-- .content-area -->

<?php //get_sidebar(); ?>
<!--<script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places"></script>-->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script src="<?php echo plugin_dir_url( __FILE__ ) ?>jquery.geocomplete.js"></script>

<script>
    $(function(){

        var options = {
            map: ".map_canvas2"
        };

        $("#geocomplete").geocomplete(options)
            .bind("geocode:result", function(event, result){
                //$.log("Result: " + result.formatted_address);
            })
            .bind("geocode:error", function(event, status){
                //$.log("ERROR: " + status);
            })
            .bind("geocode:multiple", function(event, results){
                //$.log("Multiple: " + results.length + " results found");
            });

        $("#find").click(function(){
            $("#geocomplete").trigger("geocode");
        });

        $("#examples a").click(function(){
            $("#geocomplete").val($(this).text()).trigger("geocode");
            return false;
        });

        $("#geocomplete2").geocomplete(options)
            .bind("geocode:result", function(event, result){
               // $.log("Result: " + result.formatted_address);
            })
            .bind("geocode:error", function(event, status){
               // $.log("ERROR: " + status);
            })
            .bind("geocode:multiple", function(event, results){
               // $.log("Multiple: " + results.length + " results found");
            });

        $("#find").click(function(){
            $("#geocomplete2").trigger("geocode");
        });

        $("#examples a").click(function(){
            $("#geocomplete2").val($(this).text()).trigger("geocode");
            return false;
        });
    });
</script>


<?php get_footer(); ?>
