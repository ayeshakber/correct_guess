<?php

get_header(); ?>

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<div id="primary" class="content-area">
    <main id="main" class="site-main user-task" role="main">
        <?php
        #echo do_shortcode('[task_header]');
        do_action('task_header');
        global $post;
        setup_postdata($post);  # FOR AUTHOR
        $post_description = $post->post_content;
        $post_id = $post->ID;

        $author_ids = $post->post_author;
		$post_title= $post->post_title;
        $user_id = get_current_user_id();
        /*echo "<br>Bringer Side:";
        echo "<br>POST ID:";
        print_r($post_id);
    
        echo "<br>Author ID:";
        print_r($author_ids);
        echo "<br>Current user ID:";
        print_r($user_id);*/
      
        $user_wishlist = array();
		$user_wishlist = get_user_meta($user_id,'wishlist',true);
        $post_accepted = get_post_meta($post_id,'offer_accepted',true);//user id
        $successfull_task = get_post_meta($post_id,'successfull_task',true);//user id
        /*echo "<br>BRINEGR SIDE:TASK SUCESFULL DELIVERED:";
        print_r($successfull_task);
          echo "<br>";*/
      /*  echo "<br>Offer Accepted ID:";
        print_r($post_accepted);*/
        # print_r(  $post_accepted );
        # echo "post acepted user id  <br>";   
		# AISHA #
		//////SHOW HOW MANY OFFER/////
		$post_interested = get_post_meta($post_id,'task_offers',true);
      /*  echo "<br>Post offer ID:";
        print_r($post_interested);*/
		//////SHOW HOW MANY OFFER/////
		# AISHA #
        $wishlist_value = '';
        if(!empty($user_wishlist)) {
            if(in_array( $post_id,$user_wishlist ))
            {
                $wishlist_value ='<button class="wishlist">&#9747; Remove from Wishlist</button>';
            }
            else
            {
                $wishlist_value ='<button class="wishlist">&#10084; Save to Wishlist</button>';
            }
        }
        ###### START CODE FOR ACCETED OFFER##########
        if($author_ids!=$user_id)
        {
             if ($post_accepted==$user_id && is_user_logged_in() && $successfull_task!='1')
             {
                do_action('bringer_sender_chat',get_the_ID(), 1);
             }

             elseif ((!empty($post_accepted)) && $successfull_task!='1') {
                 echo "OOPSSS! This Task has been Expired!";
             }

             elseif($successfull_task=='1')
            {
                echo "This item is Already Delivered!";

            }
            else
             {
                do_action('task_user_header'); 
             }
        } 
       else if(!empty($post_accepted)) 
        {
            echo "OOPSSS! This Task has been Expired!";
        }
        /*else if($successfull_task==1)
        {
            echo "This item is Already Delivered!";

        }*/

        ###### START CODE FOR ACCETED OFFER ##########
		# SHOW OFFERS #
		# AISHA #
        #####EXTRA NEED######
        $extra_need = get_post_meta($post_id,'extra_need',true);
          if(!empty($extra_need))
          {

            $fragile = '';
           if($extra_need['fragile']=='1')
           {
               $fragile = '<span>&#10004;</span>';
           }
           else
           {
               $fragile = '<span>&#8211;</span>';
           }
            $cage = '';
            if($extra_need['cage']=='1')
            {
                $cage = '<span>&#10004;</span>';
            }
            else
            {
                $cage = '<span>&#8211;</span>';
            }

            $cooling = '';
            if($extra_need['cooling']=='1')
            {
                $cooling = '<span>&#10004;</span>';
            }
            else
            {
                $cooling = '<span>&#8211;</span>';
            }

            $wrapping = '';
            if($extra_need['wrapping']=='1')
            {
                $wrapping = '<span>&#10004;</span>';
            }
            else
            {
                $wrapping = '<span>&#8211;</span>';
            }
          }
                ##### REWARD #####
                #$reward = get_post_meta($post->ID,'payment_amount',true);
                $author_post = $post->post_author;
                /*echo "<br>author id:";
                print_r($author_post );*/
                $current_user_id = get_current_user_id();
                 /*echo "<br>current_user_id id:";
                print_r($current_user_id );
*/
                $reward = '';
                if ($current_user_id == $author_post ) 
                {
                     $reward = get_post_meta($post->ID,'payable',true);
                }
                else
                {
                     $reward = get_post_meta($post->ID,'transporter_paid',true);
                }
                 #$def_ins = esc_attr( get_option('change_insurances_color_errors') ); 
                 $def_ins = get_post_meta( $post->ID, 'sender_insurance', true );
				 $total_miless = get_post_meta($post->ID,'total_miles',true);
				 
				 
                  /*echo "<br>reward:";
                print_r($reward);*/
        #####EXTRA NEED######
        $html .= '<div id="map" style="width: 100%;height:300px"></div>'.$wishlist_value;
        $html .= '<div class="task-details">
                        <div class="task-item-detail">
                            <div class="task-labels"></div>
                            <div class="task-value">Report task</div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Info</div>
                            <div class="task-value">
                            <p>Standard insurance covers your item up to £'.$def_ins.'</p>
                            </div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Size</div>
                            <div class="task-value">'.get_post_meta($post->ID, 'size' ,true).'</div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Must be delivered by end of:</div>';

                    $html .='<div class="task-value">'.get_post_meta($post->ID, 'delivery_flex', true). ' '.get_post_meta($post->ID,'select_time',true).'</div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Reward:</div>
                            <div class="task-value">£'.$reward.'<p>Ecour will transfer this amount to your bank account, after delivery is confirmed.</p></div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Description:</div>
                            <div class="task-value"> '.$post_description.'</div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Picked up from:</div>
                            <div class="task-value">'.get_post_meta($post->ID, 'pic_up', true).'</div>
                        </div>
                        
                        <div class="task-item-detail">
                            <div class="task-labels">Delivered to:</div>
                            <div class="task-value">'.get_post_meta($post->ID, 'delievery_address', true).'</div>
                        </div> 
                         
                        <div class="task-item-detail" style="display:none;">
                            <div class="task-labels">Extra Need:
                            <div class="task-value items-need">
                                
                                    <ul class="extra-need" style="list-style-type: none;">
                                        
                                        <li class="fragile" >  <span>Is it fragile:</span>
                                        '.$fragile.'
                                        </li>
                                        
                                       
                                        <li class="cage"> <span>Does it need an animal cage:</span>
                                        '.$cage.'
                                        </li>
                                        
                                        
                                        <li class="cooling"><span>Does it need cooling equipment:</span>
                                        '.$cooling.'
                                        </li>
                                        
                                       
                                        <li class="wrapping"> <span>Need help with wrapping:</span>
                                        '.$wrapping.'
                                        </li>
                                        
                                    </ul>
                                </div>
                           
                            </div>
                        </div> 
                  </div>';
        echo $html;
		
        echo '<div id="map-canvas" style="border: 2px solid #3872ac;"></div>';
        $pic_up_address = get_post_meta($post->ID,'pic_up',true);
        $delivery_address = get_post_meta($post->ID,'delievery_address',true);
        $delivery_address_loc = get_post_meta($post->ID,'deliever_lat_long',true);

        $delivery_address_loc = explode('_',$delivery_address_loc);
        $pick_up_address = get_post_meta($post->ID,'pick_lat_long',true);
        $pick_up_address = explode('_',$pick_up_address);
		
		//if($total_miless<="200"){
			?>
			<script>
			 var marker1, marker2;
            var poly, geodesicPoly;
      function initMap() {
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 7,
          center: {lat: 41.85, lng: -87.65}
        });
		
		 if(map) map.setOptions({ scrollwheel: false });
		 /* var myOptions = { zoom : 3,center: {lat: 30.267153, lng: -97.74306079999997}};
		 
			map.setOptions(myOptions); */

        directionsDisplay.setMap(map);
		calculateAndDisplayRoute(directionsService,directionsDisplay);
      }
	  
	 /*   function run_time(){
		 alert("work");
		  var myOptions = { zoom : 3,center: {lat: <?php echo $pick_up_address[0]?>, <?php echo $delivery_address_loc[1]?>}};
		  map.setOptions(myOptions);
		  return false; 
		  
	  }
	  
	  jQuery(document).ready(function(){
		 setTimeout(function(){
				// run_time(); 
				var myOptions = { zoom : 3,center: {lat: 30.267153, lng: -97.74306079999997}};
map.setOptions(myOptions);
			}, 2000); 
	  });
*/

      function calculateAndDisplayRoute(directionsService, directionsDisplay) {
        directionsService.route({
          origin: '<?php echo $pic_up_address?>',
          destination: '<?php echo $delivery_address?>',
          travelMode: 'DRIVING'
        }, function(response, status) {
          if (status === 'OK') {
			   // if(map) map.setOptions({ scrollwheel: false });
            directionsDisplay.setDirections(response);
          } else {
            //window.alert('Directions request failed due to ' + status);
			/////////////////
			
			var map = new google.maps.Map(document.getElementById('map'), {
                   zoom: 4,
				center: {lat: <?php echo $pick_up_address[0]?>, lng: <?php echo $delivery_address_loc[1]?>}
                });
				
                map.controls[google.maps.ControlPosition.TOP_CENTER].push(
                    document.getElementById('info'));

                if(map) map.setOptions({ scrollwheel: false });
                
				
			
                marker1 = new google.maps.Marker({
                    map: map,
                    draggable: false,
                    position: {lat: <?php echo $pick_up_address[0]?>, lng: <?php echo $pick_up_address[1]?>}
                });
                marker2 = new google.maps.Marker({
                    map: map,
                    draggable: false,
                    position: {lat: <?php echo $delivery_address_loc[0]?>, lng: <?php echo $delivery_address_loc[1]?>}
                });
                var bounds = new google.maps.LatLngBounds(
                    marker1.getPosition(), marker2.getPosition());
                    map.fitBounds(bounds);

                google.maps.event.addListener(marker1, 'position_changed', update);
                google.maps.event.addListener(marker2, 'position_changed', update);
                poly = new google.maps.Polyline({
                    strokeColor: '#FF0000',
                    strokeOpacity: 1.0,
                    strokeWeight: 3,
                    map: map,
                });
                geodesicPoly = new google.maps.Polyline({
                    strokeColor: '#CC0099',
                    strokeOpacity: 1.0,
                    strokeWeight: 3,
                    geodesic: true,
                    map: map
                });
				
                update();
				
				//setTimeout(function() { 
				// alert('done');
				var myOptions = { zoom : 2,center: {lat: <?php echo $pick_up_address[0]?>, lng: <?php echo $pick_up_address[1]?>}};
				map.setOptions(myOptions);
				//}, 1000);
				 
			////////////////
          }
		  
		  
        });
      }
      	
	  function update() {
                var path = [marker1.getPosition(), marker2.getPosition()];
                var heading = '';
                poly.setPath(path);
                geodesicPoly.setPath(path);
                heading = google.maps.geometry.spherical.computeHeading(path[0], path[1]);
                //document.getElementById('heading').value = heading;
                //document.getElementById('origin').value = path[0].toString();
                //document.getElementById('destination').value = path[1].toString();
            }
    </script>
			<?php
		//}
		//else{
		?>
        <script>
		
            // var marker1, marker2;
            // var poly, geodesicPoly;
            // function initMap() {
                // var map = new google.maps.Map(document.getElementById('map'), {
                    // zoom: 4,
                    // center: {lat: 34, lng: -40.605}
                // });
                // map.controls[google.maps.ControlPosition.TOP_CENTER].push(
                    // document.getElementById('info'));

                // if(map) map.setOptions({ scrollwheel: false });
                
                // marker1 = new google.maps.Marker({
                    // map: map,
                    // draggable: false,
                    // position: {lat: <?php echo $pick_up_address[0]?>, lng: <?php echo $pick_up_address[1]?>}
                // });
                // marker2 = new google.maps.Marker({
                    // map: map,
                    // draggable: false,
                    // position: {lat: <?php echo $delivery_address_loc[0]?>, lng: <?php echo $delivery_address_loc[1]?>}
                // });
                // var bounds = new google.maps.LatLngBounds(
                    // marker1.getPosition(), marker2.getPosition());
                    // map.fitBounds(bounds);

                // google.maps.event.addListener(marker1, 'position_changed', update);
                // google.maps.event.addListener(marker2, 'position_changed', update);
                // poly = new google.maps.Polyline({
                    // strokeColor: '#FF0000',
                    // strokeOpacity: 1.0,
                    // strokeWeight: 3,
                    // map: map,
                // });
                // geodesicPoly = new google.maps.Polyline({
                    // strokeColor: '#CC0099',
                    // strokeOpacity: 1.0,
                    // strokeWeight: 3,
                    // geodesic: true,
                    // map: map
                // });
                // update();
            // }
            // function update() {
                // var path = [marker1.getPosition(), marker2.getPosition()];
                // var heading = '';
                // poly.setPath(path);
                // geodesicPoly.setPath(path);
                // heading = google.maps.geometry.spherical.computeHeading(path[0], path[1]);
                // document.getElementById('heading').value = heading;
                // document.getElementById('origin').value = path[0].toString();
                // document.getElementById('destination').value = path[1].toString();
            // }
        </script>
		<?php
		//}
		?>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCi7_en6OpMbjn7j0A251CVbLQkrHIk2_8&libraries=geometry&callback=initMap"
                async defer></script>
       <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCi7_en6OpMbjn7j0A251CVbLQkrHIk2_8&libraries=geometry&callback=init"
                async defer></script>-->
    </main><!-- .site-main -->
    <?php //get_sidebar( 'content-bottom' ); ?>
</div><!-- .content-area -->
<?php //get_sidebar(); ?>
<?php get_footer(); ?>
