<?php

Class Task_View {

    public function __construct() {
        add_filter('template_include', array($this,'etb_task_template'), 99 );
        // MESSAGES & OFFER
        add_action('wp_footer', array($this,'my_action_javascript') );
        add_action('wp_ajax_my_action', array($this,'my_action_callback') );
        add_action('wp_ajax_nopriv_my_action', array($this,'my_action_callback') );
        // TASK SEARCHING
        add_action('wp_footer', array($this,'task_search_javascript') );
        add_action('wp_ajax_task_search', array($this,'task_search_callback') );
        add_action('wp_ajax_nopriv_task_search', array($this,'task_search_callback') );
        /* waseem ajax file upload hooks start */
        add_action('wp_ajax_cvf_upload_files_detail', array($this, 'cvf_upload_files_detail') );
        add_action('wp_ajax_nopriv_cvf_upload_files_detail', array($this, 'cvf_upload_files_detail') ); // Allow front-end submission
        add_action('task_user_header', array($this, 'task_user_header') ); #Allow front-end submission
        add_action('task_details_header', array($this, 'task_details_header'), 10, 1 ); # Allow front-end submission
    }

    public function task_details_header($user_id)
    {
        global $post;
        $post_description = $post->post_content;
        $post_title = $post->post_title;
        $current_user = $user_id;
          /**
         * @Aisha
         * offer reviews
         */
       $post_ID = $post->ID;
        #print_r($post_ID);
        $html = '';
          #######
            $html .= '<div class="user-info">
                    <div class="user-profile-pic">';
            $profile_pic_show = get_user_meta($current_user,'profile_pic',true);
            if(!empty($profile_pic_show))
            {
                $html .='<img src="'.$profile_pic_show.'" width="100">';
            }
            else
            {
                $html .= get_avatar( $post->post_author, '', '', '' );
            }
            $task_info_from_backend = esc_attr( get_option('about_the_send_item') );

            $html .='</div>
            <p>'.$task_info_from_backend .'</p></div>';
            $html .= '<div class="more-info"><p>The more information you have to better</p>
                            <button>+ Add more information</button>
                            <!--<p>
                                <a href="'.get_permalink( get_page_by_path( 'chats' ) ).'?task_id='.$post->ID.'" >View Messages</a>
                            </p>-->
                        </div>';
            /**
            * @Aisha
            * offer reviews
            */
            #echo "INTERESTED USER:";
            $post_interested = get_post_meta($post_ID,'task_offers',true);
             /*echo "<pre>";
            print_r($post_interested);
            echo "</pre>";*/
            /*if (!empty($post_interested)) 
            {
                $post_interested = array_unique($post_interested);
            }
            */


            ##### ALL FOREACH WORK WILL DO HERE #####
            if(!empty($post_interested)) 
            {
                $html .='<div class="offer-info"><p>Other bringers interested in this task</p>';
                $html .= '<div class="user-offers">';
                foreach($post_interested as $value) {
                    $user_id = get_userdata($value[3]);
                    $users_id = $user_id->ID;
                    $name = $user_id->display_name;
                    if (!empty($name) && $name != ' ') {
                        $html .= '<div class="user-offer"><a href="' . get_permalink(get_page_by_path('offer')) . '?task_id=' . $post->ID . '&user_id=' . $users_id . '"><div class="user-name">' . $name . '</div>';

                        //$post_interested = get_user_meta($post_ID,'user_offers',true);

                        $user_views = get_user_meta($users_id, 'user_rate_on_profile', true);

                        if (!empty($user_views)) {
                            $view_count = count($user_views);
                            $average = 0;
                            $rating_1 = 0;
                            foreach ($user_views as $rating) {
                                $rating_1 += $rating['user_rating'];
                                $average = $rating_1 / count($user_views);
                                echo '<br>';
                                $average = round($average, 1);
                            }
                            $html .= '<div class="average"> ' . $average . ' &#9733;</div>';
                            $html .= '<div class="reviews-count"> ' . (count($user_views) . ' reviews') . '</div>';
                            $html .= '<div class="reviews-offer"> OFFER </div>';
                            $html .= '<div class="reviews-date"> ' . $value[2] . '</div>';
                        } else {
                            $html .= '<div class="average"> new <i class="fa fa-user-circle-o" aria-hidden="true"></i> </div>';
                            $html .='<div class="reviews-offer"> OFFER </div>';
                            $html .='<div class="reviews-date"> '.$value[2].'</div>';
                        }
                        $html .= '</a></div>';
                    }
                }
                $html .= '</div>';
                $html .='</div>';
            }
            echo  $html ;
        #########
    }
    
    public function task_user_header() 
    {
        global $post;

        setup_postdata($post);  // FOR AUTHOR

        $post_description = $post->post_content;
        $post_id = $post->ID;
        $author_ids = $post->post_author;
        $post_title= $post->post_title;
    
        $post_interested = get_post_meta($post_id,'task_offers',true);
       /* echo "<br>POST INTERESTED";
        print_r($post_interested);*/

        /*if(!empty($post_interested)) 
        {
            $post_interested = array_unique($post_interested);
        }*/
   
    
        $user_id = get_current_user_id();
        $html = '';
        $html .= '<div class="user-info">
            <div class="user-profile-pic">';

            $profile_pic = get_user_meta($author_ids,'profile_pic',true);
            if(!empty($profile_pic))
            {
                $html .='<img src="'.$profile_pic.'" width="100">';
            }
            else
            {
                $html .= get_avatar( $post->post_author, '', '', '');
           }

            $html .='</div><a href="' . get_permalink(get_page_by_path('ecour-profile-page')) . $post->post_author.'">'. get_the_author() . '</a>
            <p>'.$post_description.' </p>
            <p>' .'  <button class="send-message">Send a message</button> ' .
                            ' <button class="offer-help">Offer Help to '.get_the_author().'</button> ' .
                    '</p></div>';
            // AISHA//
            //////SHO
        //W OFFERS/////////
            if(!empty($post_interested)) {
           $html .='<div class="offer-info"><p>Other bringers interested in this task</p>';
           $html .= '<div class="user-offers">';
                foreach($post_interested as $value)
                {
                    #echo 'OFFER IN LOOP';
                    #print_r($value[3]);
                    $user_id = get_userdata($value[3]);
                     $users_id = $user_id->ID;
                    $name = $user_id->display_name;
                      #print_r($name);
                    echo 'A';
                    ///if(!empty($name) && $name != ' ') {
                        $html .= '<div class="user-offer"><div class="user-name"><a href="' . get_permalink(get_page_by_path('ecour-profile-page')) .  $users_id.'">'. $name . '</a></div>';
                        $user_views = get_user_meta($users_id,'user_rate_on_profile',true);
                            if(!empty($user_views))
                            {
                                $view_count = count($user_views);
                                $average = 0;
                                $rating_1 = 0;
                                foreach ($user_views as $rating)
                                {
                                    $rating_1 += $rating['user_rating'];
                                    $average = $rating_1 / count($user_views);echo '<br>';
                                    $average = round($average,1);
                                }
                                $html .= '<div class="average"> '.$average .' &#9733;</div>';
                                $html .='<div class="reviews-count"> '.(count($user_views).' reviews').'</div>';
                                $html .='<div class="reviews-offer"> OFFER </div>';
                                $html .='<div class="reviews-date"> '.$value[2].'</div>';
                                #$html .= '</div>';
                            } else {
                                $html .= '<div class="average"> new <i class="fa fa-user-circle-o" aria-hidden="true"></i> </div>';
                                $html .='<div class="reviews-offer"> OFFER </div>';
                                $html .='<div class="reviews-date"> '.$value[2].'</div>';
                            }
                         $html .= '</div>';
                    //}
                }
            }
            $html .= '</div>'; 
            echo $html;
    }

    public function etb_task_template( $template ) {
        global $post;
        $user_id = get_current_user_id();
        if ( get_post_type(get_the_ID()) == 'task' && $post->post_author != $user_id) { // CUSTOM TEMPLATE PAGE FOR TASK & IS NOT POST AUTHOR
            $new_template =  dirname(__FILE__) . "/templates/task-details.php" ;
            if ( '' != $new_template ) {
                return $new_template ;
            }
        } else if(get_post_type(get_the_ID()) == 'task' && $post->post_author == $user_id) {
            $new_template =  dirname(__FILE__) . "/templates/task-user-details.php" ;
            if ( '' != $new_template ) {
                return $new_template ;
            }
        } else if(is_page('task-search')) {
            $new_template =  dirname(__FILE__) . "/templates/task-search.php" ;
            if ( '' != $new_template ) {
                return $new_template ;
            }
        }
        return $template;
    }

    /* accept & reject offer work start */
    public function accept_reject_offer()
    {
        ?>
        <script>
            jQuery(document).ready(function(){
                jQuery('.offer_accept').click(function(){
                    var offer_accept_transport_id = jQuery(this).attr('id');
                    var offer_accept_transport_post_id = jQuery(this).attr('data-tranporter');
/*                    alert(offer_accept_transport_id);
                    alert(offer_accept_transport_post_id);*/
                    jQuery.ajax({
                        url : '<?php echo admin_url('admin-ajax.php'); ?>',
                        type : 'post',
                        data : {
                            action : 'offer_reject',
                            offer_accept_transport_id : offer_accept_transport_id,
                            offer_accept_transport_post_id : offer_accept_transport_post_id
                        },
                        success : function( data ) {
                            //console.log(data);
                            // jQuery("#shoe_color").html(data);
                            /* jQuery('.shoe-shape').html(data);
                             jQuery('.choose-shoe-color-container').css('display','none'); */
                        },
                        error: function(errorThrown){
//                            alert(errorThrown);
                            console.log(errorThrown);
                        }
                    });
                });
            });
        </script>
        <?php
    }

    /* public function offer_reject() {
            echo "work";
    } */
    /* accept & reject offer work end */
    public function my_action_javascript() {
        global $post;
        if(get_post_type(get_the_ID()) == 'task') {
            ?>
            <script type="text/javascript" >
                jQuery(document).ready(function($) {
                    var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
                    // Save to Wishlist
                    jQuery('.wishlist').click(function() {
                        var postid = <?php echo get_the_ID(); ?>;
                        var data = {
                            'action': 'my_action',
                            'postid' : postid,
                            'request' : 'wishlist'
                        };
                        $.post(ajaxurl, data, function(response) {

                            alerty.alert(response, {
                                title: 'Wishlist',
                                time: 3000,
                                okLabel: 'OK'
                            }, function(){/*alert('callback')*/})
                        });
                    });

                    //////////////////////////////////////
                    // Send a message
                    jQuery('.send-message').click(function() {
                        var postid = <?php echo get_the_ID(); ?>;

                        setTimeout(function () {
                            var msg_date =   jQuery( ".alerty-message input" ).attr('placeholder');

                            if(msg_date == 'Choose Date')
                            {
                                jQuery( ".date-field" ).blur();
                                jQuery( ".date-field" ).datepicker()
                            }

                        },500);

                        alerty.confirm('Enter Your Message <p><textarea class="e-message"></textarea></p><!-- When can you deliver it? (Optional) --> <p><input type="text" class="date-field" style="display:none" placeholder="Choose Date"/> <input type="text" style="width:40%;display:none" class="price-field" placeholder="Price"/></p>', {
                            title: 'Send message to sender',
                            cancelLabel: 'Cancel', okLabel: 'Send'
                        }, function(value){
                            d = new Date();
                            //d.toLocaleString();
                            //d.toLocaleDateString();
                            //d.toLocaleTimeString();
                            var data = {
                                'action': 'my_action',
                                'postid' : postid,
                                'request' : 'send_message',
                                'message_details' : value,
                                'author_id' : <?php echo $post->post_author;?>,
                                'date_time' : d.toLocaleString()
                            };
                            $.post(ajaxurl, data, function(response) {
                                //alert(response);
                                alerty.alert('Your message has been sent <span style="color:green">&#10003;</span>',{title: 'Successful',okLabel: 'OK'});});
                        },function() {
                            // alerty.alert('cancel <span style="color:green">&#10003;</span>',{title: 'Successful',okLabel: 'OK'});
                        });
                    });
                    // });
                    ////////////////////////////////////////////

                    // Send offer
                    jQuery('.offer-help').click(function() {
                        var postid = <?php echo get_the_ID(); ?>;

                        setTimeout(function () {
                            var msg_date =   jQuery( ".alerty-message input" ).attr('placeholder');

                            if(msg_date == 'Choose Offer Date')
                            {
                                jQuery( ".date-field" ).blur();
                                jQuery( ".date-field" ).datepicker()
                            }

                        },500);

                        alerty.confirm('When you can deliver it?<p><input type="text" class="date-field" placeholder="Choose Offer Date"/> <input type="text" style="width:40%;display:none" class="price-field" placeholder="Price"/></p> <p><textarea class="e-message"></textarea></p>', {
                            title: 'Send offer to sender',
                            cancelLabel: 'Cancel', okLabel: 'Send offer'
                        }, function(value){
                            var data = {
                                'action': 'my_action',
                                'postid' : postid,
                                'request' : 'send_offer',
                                'message_details' : value,
                                'author_id' : <?php echo $post->post_author;?>
                            };
                            $.post(ajaxurl, data, function(response) {
                                alerty.alert('Your message has been sent <span style="color:green">&#10003;</span>',{title: 'Successful',okLabel: 'OK'});});
                        },function() {
                            // alerty.alert('cancel <span style="color:green">&#10003;</span>',{title: 'Successful',okLabel: 'OK'});
                        });
                    });
                //});

                // Delete Task
                jQuery('.delete-taks').click(function() {
                    // alerty.confirm(content, opts, onOk, onCancel)
                    var postid =  <?php echo get_the_ID(); ?>;
                    // alerty.confirm(content, opts, onOk, onCancel)
                    alerty.confirm(
                        'Are you sure?',
                        {title: 'Notes', cancelLabel: 'Cancel', okLabel: 'Confirm'},
                        function(){
                            var data = {
                                'action': 'my_action',
                                'postid' : postid,
                                'request' : 'delete_task',
                            };
                            $.post(ajaxurl, data, function(response) {
                                alerty.toasts('Task Deleted', {place: 'top'});
                            })
//                            alerty.toasts('Task Deleted', {place: 'top'});
                        },
                        function() {
//                            alerty.toasts('this is cancel callback')
                        }
                    );
                });
                // edit Task
                jQuery('.update_pickup_address').click(function() {
                    var postid =  <?php echo get_the_ID(); ?>;
                    var address_dield = jQuery('#autocomplete').val();
                    var this_val = jQuery(this);
                    var data = {
                        'action': 'my_action',
                        'postid' : postid,
                        'request' : 'update_address',
                        'meta_key' : 'pic_up',
                        'meta_value' : address_dield,
                    };
                    $.post(ajaxurl, data, function(response)
                    {
                        this_val.parent().fadeOut();
                        this_val.parent().parent().find('.task-value .task-item-value').html(response);
                    })
                });

                jQuery('.update_delivery_address').click(function() {
                    var postid =  <?php echo get_the_ID(); ?>;
                    var address_dield = jQuery('#autocomplete2').val();
                    var this_val = jQuery(this);
                    var data = {
                        'action': 'my_action',
                        'postid' : postid,
                        'request' : 'update_address',
                        'meta_key' : 'delievery_address',
                        'meta_value' : address_dield,
                    };
                    $.post(ajaxurl, data, function(response)
                    {
                        this_val.parent().fadeOut();
                        this_val.parent().parent().find('.task-value .task-item-value').html(response);
                    })
                });

                jQuery('.edit-btn').click(function(e)
                {
                    // alerty.confirm(content, opts, onOk, onCancel)

                    var postid =  <?php echo get_the_ID(); ?>;
                    setTimeout(function () {
                        var reward_date =   jQuery( ".alerty-prompt input" ).attr('placeholder');
                        if(reward_date == 'delivery_flex')
                        {
                            jQuery( ".alerty-prompt input" ).blur();
                            jQuery( ".alerty-prompt input" ).datepicker()
                        }
                    },500);

                    var edit_type = jQuery(this).find('span').html();
                    var field_value = jQuery(this).find('span:nth-child(2)').html();

                    ///FOR PICK UP GOOGLE FIELD///
                    if(edit_type=='pic_up' )
                    {
                        setTimeout(function ()
                        {
                            //$('.alerty-prompt input').attr('id', 'autocomplete');
                            //$('.alerty-prompt input').attr('onFocus', 'geolocate()');
                            var address_filed = jQuery('.address-field').html();
                           // jQuery('.address-field').html('');
                           // jQuery('.alerty-content').html(address_filed);

                            jQuery( ".address-field" ).slideToggle( "slow", function() {

                            });
                            //Start map field//
                            /* var placeSearch, autocomplete;
                             function initAutocomplete()
                             {
                             autocomplete = new google.maps.places.Autocomplete(
                             /!** @type {!HTMLInputElement} *!/(document.getElementById('autocomplete')),
                             {types: ['geocode']});
                             autocomplete.addListener('place_changed', fillInAddress);
                             }

                             function geolocate()
                             {
                             if (navigator.geolocation)
                             {
                             navigator.geolocation.getCurrentPosition(function(position) {
                             var geolocation = {
                             lat: position.coords.latitude,
                             lng: position.coords.longitude
                             };
                             var circle = new google.maps.Circle({
                             center: geolocation,
                             radius: position.coords.accuracy
                             });
                             autocomplete.setBounds(circle.getBounds());
                             });
                             }
                             } *///Start map field//

                        },1000);

                        setTimeout(function ()
                        {
                            //Start map field//
                            var placeSearch, autocomplete;
                            function initAutocomplete()
                            {
                                autocomplete = new google.maps.places.Autocomplete(
                                    /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
                                    {types: ['geocode']});
                                autocomplete.addListener('place_changed', fillInAddress);
                            }

                            function geolocate()
                            {
                                if (navigator.geolocation)
                                {
                                    navigator.geolocation.getCurrentPosition(function(position) {
                                        var geolocation = {
                                            lat: position.coords.latitude,
                                            lng: position.coords.longitude
                                        };
                                        var circle = new google.maps.Circle({
                                            center: geolocation,
                                            radius: position.coords.accuracy
                                        });
                                        autocomplete.setBounds(circle.getBounds());
                                    });
                                }
                            } //Start map field//
                        },1000);

                        /*alerty.prompt('Modify Your Task',
                            {
                                inputType: 'text',
                                inputPlaceholder: edit_type,
                                inputValue: field_value,
                                cancelLabel: 'Cancel',
                                okLabel: 'Save'
                            },
                            function (value) {
                                var data = {
                                    'action': 'my_action',
                                    'postid': postid,
                                    'request': 'edit_task',
                                    'meta_key': edit_type,
                                    'meta_value': value,
                                };
                                $.post(ajaxurl, data, function (response) {
                                    jQuery('#' + edit_type + ' .edit-btn span:nth-child(2)').html(response);
                                    jQuery('#' + edit_type + ' .task-item-value').html(response);
                                    alerty.toasts('Update successfully', {place: 'top'});
                                })
                            }, function () {
                                /!* alert('cancel callback')*!/
                            })
*/
                    } else if(edit_type=='delievery_address') {
                        jQuery( ".address-field-delivery" ).slideToggle( "slow", function() {

                        });
                    }
                    else if(edit_type=='extra_need')  ///FOR EXTRA NEED (EXTRA FIELD)//
                    {
                        setTimeout(function ()
                        {
                            jQuery('.n-extra_need_active').val('1');
                        },1000);
                        <?php
                        global $post;
                        $post_ID = $post->ID;
                        $extra_need = get_post_meta($post_ID,'extra_need',true);
                        if( $extra_need !='')
                        {
                            $fragile = '';
                            if($extra_need['fragile']=='1')
                            {
                                $fragile = 'checked';
                            }
                            $cage = '';
                            if($extra_need['cage']=='1')
                            {
                                $cage = 'checked';
                            }
                            $cooling = '';
                            if($extra_need['cooling']=='1')
                            {
                                $cooling = 'checked';
                            }
                            $wrapping = '';
                            if($extra_need['wrapping']=='1')
                            {
                                $wrapping = 'checked';
                            }
                        }
                        ?>
                        alerty.confirm('Do you have any special needs?<p><div><input type="checkbox" class="n-need_fragile" id="n-need_fragile" value="" <?php echo $fragile;?>/><label for="n-need_fragile"><span></span>Is it fragile</label></div> <div><input type="checkbox" id="n-need_cage" class="n-need_cage" value="0" <?php echo $cage;?>/><label for="n-need_cage"><span></span>Does it need an animal cage</label></div> <div><input type="checkbox" id="n-need_cooling" class="n-need_cooling" value="" <?php echo $cooling;?>/><label for="n-need_cooling"><span></span>Does it need cooling equipment</label></div><div><input type="checkbox" id="n-need_wrapping" class="n-need_wrapping" value="" <?php echo $wrapping;?>/><label for="n-need_wrapping"><span></span>Need help with wrapping</label></div><div><input type="hidden" name="n-extra_need_active" class="n-extra_need_active" id="n-extra_need_active" value="0"/></div></p>',
                            {
                                title: 'Extra Needs',
                                cancelLabel: 'Cancel', okLabel: 'Save'
                            },
                            function(value)
                            {
                                var data = {
                                    'action': 'my_action',
                                    'postid' : postid,
                                    'request' : 'edit_task',
                                    'meta_key' : edit_type,
                                    'meta_value' : value,
                                };
                                $.post(ajaxurl, data, function(response)
                                {
//                                    alert(response);
                                    jQuery('#'+edit_type+ ' .edit-btn span:nth-child(2)').html(response);
                                    jQuery('#'+edit_type+ ' .task-item-value').html('<span style="color:green">Updated &#10003</span>');
                                    alerty.toasts('Update successfully', {place: 'top'});
                                })
                            }, function(){ /*alert(response)*/ })
                    }
                    else if(edit_type == 'size') {
                        setTimeout(function ()
                        {
                            jQuery('.n-parcel_size').val('1');
                            var size_val = '<?php echo get_post_meta(get_the_ID(),'size',true);?>';
                            jQuery('.n-size').each(function() {
                                if(jQuery(this).val() == size_val) {
                                    jQuery(this).prop('checked',true);
                                }
                            });
                        },1000);

                        alerty.confirm('<p><div><input type="radio" name="n-size" class="n-size" id="n-walking" value="Pocket"/><label for="n-walking"><span></span>Walking</label></div> <div><input type="radio" id="n-Bag" name="n-size" class="n-size" value="Bag"/><label for="n-Bag"><span></span>Bag</label></div> <div><input type="radio" name="n-size" id="n-Car" class="n-size" value="Car"/><label for="n-Car"><span></span>Car</label></div><div><input type="radio" id="n-Big_car" name="n-size" class="n-size" value="Big car" /><label for="n-Big_car"><span></span>Big car</label></div><div><input type="hidden" name="n-size" class="n-size" id="n-Van" value="Van"/> <input type="hidden" class="n-parcel_size" value = "0" /></div></p>',
                        {
                            title: 'Extra Needs',
                            cancelLabel: 'Cancel', okLabel: 'Send offer'
                        },
                        function(value)
                        {
							//alert(value);
                            var data = {
                                'action': 'my_action',
                                'postid' : postid,
                                'request' : 'edit_task',
                                'meta_key' : edit_type,
                                'meta_value' : value,
                            };
                            $.post(ajaxurl, data, function(response)
                            {
                                //alert(response);
                                jQuery('#'+edit_type+ ' .edit-btn span:nth-child(2)').html(response);
                                jQuery('#'+edit_type+ ' .task-item-value').html(response);
                                alerty.toasts('Update successfully', {place: 'top'});
                            })
                        }, function(){ /*alert(response)*/ })
                    }
                    else
                    {
                        alerty.prompt('Modify Your Task',
                            {inputType: 'text', inputPlaceholder: edit_type, inputValue: field_value, cancelLabel: 'Cancel', okLabel: 'Save'},
                            function(value1){
                                var data = {
                                    'action': 'my_action',
                                    'postid' : postid,
                                    'request' : 'edit_task',
                                    'meta_key' : edit_type,
                                    'meta_value' : value1,
                                };
                                $.post(ajaxurl, data, function(response) {
                                    jQuery('#'+edit_type+ ' .edit-btn span:nth-child(2)').html(response);
                                    jQuery('#'+edit_type+ ' .task-item-value').html(response);
                                    alerty.toasts('Update successfully', {place: 'top'});
                                })
                            }, function(){ /* alert('cancel callback')*/ })
                    }
                });
                });
            </script> <?php
        }
    }
   #### AJAX REQUEST & RESPONSE
    function my_action_callback()
    {
        $request = $_POST['request']; #CHECK REQUEST
        $user_id = get_current_user_id();
        $post__id= $_POST['postid'];
        /////////////////////////////
        $result='';
        if($request == 'wishlist') { #WISHLIST PROCESS
            $postid =  $_POST['postid'];
            $wishlist_id = get_user_meta($user_id,'wishlist',true);


            if(($key = array_search($postid, $wishlist_id)) )
            {
                unset($wishlist_id[$key]);
                update_user_meta($user_id,'wishlist',$wishlist_id);
                echo ' X Removed From Wishlist';
                die();
            }
            else
            {
                if(!empty($wishlist_id))
                {
                    $wishlist_id[] = $postid;
                    update_user_meta($user_id,'wishlist',$wishlist_id);
                }
                else
                {
                    $wishlist_id = array();
                    $wishlist_id[] = $postid;
                    update_user_meta($user_id,'wishlist',$wishlist_id);
                }
                echo  'Task has beed added on wishlist &#10084';
                die();
            }

        } ///////////////////////////
        else if($request == 'send_message') { #SEND MESSAGE PROCESSS
            $author_id = $_POST['author_id'];
            $message_details = $_POST['message_details'];
            $old_message_details = get_post_meta($post__id,'message',true);
            #NOTIFY
            $notify = array();
            if(!empty($old_message_details)) {
                $message_details = explode('|',$message_details);
                $message_details[] = $user_id;
                $message_details[] = $_POST['postid'];
                $message_details[] = $_POST['date_time'];
                $new_message_details = $old_message_details;
                $new_message_details[] = $message_details;
           
                ### NOTIFICATION ###
                 ## START NOTIFICATION SHORTCODE AISHA ##
                ####  http://ecour.startupbug.net/chats/?task_id=500&user_id=96


            ## END NOTIFICATION SHORTCODE AISHA##
              /*  $old_notify = get_user_meta($author_id,'notify',true);
                $msg = explode('|',$_POST['message_details']);
                $notify['Type'] = 'Message';
                $notify['read'] = '0';
                $notify['text'] = 'New Message';
                $notify['msg'] = $msg[0];
                $notify['m_uid'] = $user_id;
                $notify['t_id'] = $post__id;
                $new_notify = $old_notify;
                $new_notify[] = $notify;
                update_user_meta($author_id,'notify',$new_notify);*/
                ###NOTIFICATION ###

                update_post_meta($post__id,'message',$new_message_details);

                $link=site_url().'/chats/?task_id='.$_POST['postid'].'&user_id='.$user_id;
                echo do_shortcode( '[wpun_notification title="new MESSAGE" user_id = "'.$author_id.'" message="'.$message_details.'" type = "MESSAGE" link="'.$link.'" ]') ;
                die();
               // echo print_r(get_post_meta($post__id,'message',true));
            } 
            else 
            {
                $message_details = explode('|',$message_details);
                $message_details[] = $user_id;
                $message_details[] = $_POST['postid'];
                $message_details[] = $_POST['date_time'];
                $new_message_details[] = $message_details;
                update_post_meta($post__id,'message',$new_message_details);

                ## NOTIFICATION ##
                $old_notify = get_user_meta($author_id,'notify',true);
                $msg = explode('|',$_POST['message_details']);
                $notify['Type'] = 'Message';
                $notify['read'] = '0';
                $notify['text'] = 'New Message';
                $notify['msg'] = $msg[0];
                $notify['m_uid'] = $user_id;
                $notify['t_id'] = $post__id;

                $new_notify = $old_notify;
                $new_notify[] = $notify;

                update_user_meta($author_id,'notify',$new_notify);
                ##NOTIFICATION ##
                $link=site_url().'/chats/?task_id='.$_POST['postid'].'&user_id='.$user_id;

                echo do_shortcode( '[wpun_notification title="new MESSAGE" user_id = "'.$author_id.'" message="'.$message_details.'" type = "MESSAGE" link="'.$link.'" ]') ;
                die();
                //echo print_r(get_post_meta($post__id,'message',true));
            }
        } else if($request == 'send_offer') { # SEND OFFER PROCESSS AISHA CHECK OFFER FOR TESTING
            $postid =  $_POST['postid'];
            $author_id = $_POST['author_id'];
            $message_details = $_POST['message_details'];
           # $old_message_details = get_user_meta($author_id,'user_offers',true);
            $old_message_details = get_post_meta($postid,'task_offers',true);
            if(!empty($old_message_details)) {
                $message_details = explode('|',$message_details);
                $message_details[] = $user_id;
                $new_message_details = $old_message_details;
                $new_message_details[] = $message_details;
                update_user_meta($author_id,'user_offers',$new_message_details);
                update_post_meta($postid,'task_offers',$new_message_details); // UPDATE OFFERS IN POST META
                $user_ids = get_post_meta($postid,'interested',true);
                if(!empty($user_ids))
                    update_post_meta($postid,'interested',$user_ids.'_'.$user_id); // UPDATE USER ID'S
                else
                    update_post_meta($postid,'interested',$user_id); // UPDATE USER ID'S

                // NOTIFICATION //

                ## START NOTIFICATION SHORTCODE AISHA ##
                ####  http://ecour.startupbug.net/chats/?task_id=500&user_id=96
                $link = site_url().'/offer/?task_id='.$postid.'&user_id='.$user_id;

                echo do_shortcode( '[wpun_notification title="new OFFER" user_id = "'.$author_id.'" message="'.$message_details.'" type = "MESSAGE" link="'.$link.'" ]') ;
                die();
                ## END NOTIFICATION SHORTCODE AISHA##

                /*$old_notify = get_user_meta($author_id,'notify',true);
                $msg = explode('|',$_POST['message_details']);
                $notify['Type'] = 'Offer';
                $notify['read'] = '0';
                $notify['text'] = 'New Offer';
                $notify['msg'] = $msg[0];
                $notify['m_uid'] = $user_id;
                $notify['t_id'] = $post__id;

                $new_notify = $old_notify;
                $new_notify[] = $notify;

                update_user_meta($author_id,'notify',$new_notify);*/
                // NOTIFICATION //

                echo print_r(get_user_meta($author_id,'user_offers',true));
            } else {
                $message_details = explode('|',$message_details);
                $message_details[] = $user_id;
                $new_message_details[] = $message_details;
                update_user_meta($author_id,'user_offers',$new_message_details);
                update_post_meta($postid,'interested',$user_id);  // UPDATE USER ID
                echo print_r(get_user_meta($author_id,'user_offers',true));
                update_post_meta($postid,'task_offers',$new_message_details);  // UPDATE OFFERS IN POST META

                // NOTIFICATION //
                $old_notify = get_user_meta($author_id,'notify',true);
                $msg = explode('|',$_POST['message_details']);
                $notify['Type'] = 'Offer';
                $notify['read'] = '0';
                $notify['text'] = 'New Offer';
                $notify['msg'] = $msg[0];
                $notify['m_uid'] = $user_id;
                $notify['t_id'] = $post__id;

                $new_notify = $old_notify;
                $new_notify[] = $notify;

                $link = site_url().'/offer/?task_id='.$postid.'&user_id='.$user_id;

                update_user_meta($author_id,'notify',$new_notify);

                echo do_shortcode( '[wpun_notification title="new OFFER" user_id = "'.$author_id.'" message="'.$message_details.'" type = "MESSAGE" link="'.$link.'" ]') ;
                die();
                // NOTIFICATION //
            }
        } else if($request == 'delete_task') { // SEND OFFER PROCESSS
            $postid =  $_POST['postid'];
            wp_update_post(array(
                'ID'    =>  $postid,
                'post_status'   =>  'draft'
            ));
        } else if($request == 'edit_task') // EDIT TASK PROCESS
        {
            $postid =  $_POST['postid'];
            $meta_key =  $_POST['meta_key'];
            $meta_value =  $_POST['meta_value'];

            ### EXTRA NEED ###
            if($meta_key=='extra_need')
            {
                //$user_id = get_current_user_id();
                $need_info =  explode('|',$_POST['meta_value']);
                $fragile = $need_info[0];
                $cage = $need_info[1];
                $cooling = $need_info[2];
                $wrapping = $need_info[3];
                $data = 'fragile:' . $fragile;
                $data .= 'cage:' . $cage;
                $data .= 'cooling:' . $cooling;
                $data .= 'wrapping:' . $wrapping;

                //echo $data;
                print_r($data);
                $need_info = array(
                    'fragile'=>$fragile,
                    'cage'=>$cage,
                    'cooling'=>$cooling,
                    'wrapping'=>$wrapping,
                );
                $need_info = update_post_meta($postid, $meta_key,$need_info);
                echo $meta_value;
                die();
            }

            ## DESCRIPTION ##
            if($meta_key =='post_desc')
            {
                $my_post = array( 'ID' => $postid, 'post_content' => $meta_value);
                wp_update_post( $my_post );
                echo $meta_value;
                 die();

            }

            if($meta_key =='size'){
                $parcel_size = $_POST['meta_value'];

                $need_info = update_post_meta($postid, $meta_key,$parcel_size);
                echo $parcel_size;
                die();
            } else{



                update_post_meta($postid,$meta_key, $meta_value);
                $edit_value = get_post_meta($postid, $meta_key,true);
                echo $meta_value;
            }
        } else if($request == 'update_address') {
            $postid = $_POST['postid'];
            $meta_key = $_POST['meta_key'];
            $meta_value = $_POST['meta_value'];
            echo $meta_value;
            update_post_meta($postid,$meta_key, $meta_value);
        }
        die(); // this is required to terminate immediately and return a proper response
    }

    public function task_search_javascript() {
        global $post;
        if(get_permalink(get_page_by_path('task-search'))) {
            ?>
            <script type="text/javascript" >

                /* Make this document ready function to work on click where you want */
                jQuery(document).ready(function($) {

                    /* In front end of WordPress we have to define ajaxurl */
                    var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

                    jQuery('#task-search').click(function() {
                        jQuery('.task-results').html('<img class="loader-gif" src="https://charts3.equitystory.com/clients/gerresheimer/css/images/loading.gif" />');
                    });
                    jQuery('#task-search1').click(function() {
                        jQuery('.task-results').html('<img class="loader-gif" src="https://charts3.equitystory.com/clients/gerresheimer/css/images/loading.gif" />');
                        var from_ddress = jQuery('#geocomplete').val();
                        var to_ddress = jQuery('#geocomplete2').val();
                        var data = {
                            'action': 'task_search',
                            'request' : 'task_search',
                            'from_address' : from_ddress,
                            'to_address' : to_ddress

                        };
                        $.post(ajaxurl, data, function(response) {
                            //setTimeout(function() {jQuery('.task-results').html(response);} , 2000);
                            console.log('R' + response);
                            die();
                            exit;
                            var temp = new Array();
                            temp = response.split("|");
                            var location = '';
                            for(var i = 0 ; i < temp.length; i++) {
                                if(i == 0 || i == temp.length - 1)
                                    continue;

                                var temp1 = new Array();
                                temp1 = temp[i].split("_");
                                location += '["New Name '+i+'", '+temp1[0]+','+temp1[1]+']';
                                if(i < temp.length - 1)
                                    location += ',';
                                /*for(var u=0;u < temp1.length; u++) {
                                 }*/
                            }

                            console.log(location);

                            var map;
                            var bounds = new google.maps.LatLngBounds();
                            var mapOptions = {
                                mapTypeId: 'roadmap'
                            };

                            // Display a map on the page
                            map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);
                            map.setTilt(45);

                            // Multiple Markers
                            var markers = [
                                location
                            ];

                            /* // Info Window Content
                             var infoWindowContent = [
                             ['<div class="info_content">' +
                             '<h3>London Eye</h3>' +
                             '<p>The London Eye is a giant Ferris wheel situated on the banks of the River Thames. The entire structure is 135 metres (443 ft) tall and the wheel has a diameter of 120 metres (394 ft).</p>' +        '</div>'],
                             ['<div class="info_content">' +
                             '<h3>Palace of Westminster</h3>' +
                             '<p>The Palace of Westminster is the meeting place of the House of Commons and the House of Lords, the two houses of the Parliament of the United Kingdom. Commonly known as the Houses of Parliament after its tenants.</p>' +
                             '</div>']
                             ];

                             // Display multiple markers on a map
                             var infoWindow = new google.maps.InfoWindow(), marker, i;
                             */
                            // Loop through our array of markers & place each one on the map
                            for( i = 0; i < markers.length; i++ ) {
                                var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
                                bounds.extend(position);
                                marker = new google.maps.Marker({
                                    position: position,
                                    map: map,
                                    title: markers[i][0]
                                });

                                // Allow each marker to have an info window
                                google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                    return function() {
                                        infoWindow.setContent(infoWindowContent[i][0]);
                                        infoWindow.open(map, marker);
                                    }
                                })(marker, i));

                                // Automatically center the map fitting all markers on the screen
                                map.fitBounds(bounds);
                            }

                            // Override our map zoom level once our fitBounds function runs (Make sure it only runs once)
                            var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
                                //this.setZoom(3);
                                google.maps.event.removeListener(boundsListener);
                            });


                        });
                    });

                    jQuery(document).on('click','.add-more-option', function()
                    {
                        // alerty.confirm(content, opts, onOk, onCancel)
                        setTimeout(function () {
                            var pick_specific_date =   jQuery( ".tast-moer-options .date" ).attr('placeholder');
                            if(pick_specific_date == 'pick_specific_date')
                            {
                                jQuery( ".date" ).blur();
                                jQuery( ".date" ).datepicker({minDate: new Date()});
                            }
                        },500);

                        alerty.confirm(
                            '<div class="tast-moer-options"><h3></h3> <input type="radio" id="regular" value="regular">' +
                            '<label for="regular"><span></span><div class="border-left">Regular</div></label>' +
                            '<input type="radio" id="specific_date" value="specific-date"><label for="specific_date"><span></span><div class="border-left">On a specific Date</div></label><input type="text" class="date" id="date" valu="" name="date" placeholder="pick_specific_date"/>' +
                            '<p> <div class="task-option" id="Pocket">' +
                            '<i class="fa fa-blind" aria-hidden="true"></i>Walking' +
                            '</div> ' +
                            '<div class="task-option" id="Bag"><i class="fa fa-bicycle" aria-hidden="true"></i>Bike</div>' +
                            ' <div class="task-option" id="Car"><i class="fa fa-car" aria-hidden="true"></i>Car</div>' +
                            ' <div class="task-option" id="Big car"><i class="fa fa-bus" aria-hidden="true"></i>Big Car</div> ' +
                            '<div class="task-option" id="Van"><i class="fa fa-bus" aria-hidden="true"></i>Van</div>' +
                            ' </p> </div>',
                            {title: '<i class="fa fa-calendar-check-o" aria-hidden="true"></i> This task happens', cancelLabel: 'Cancel', okLabel: 'Save'},
                            function(){

                            },
                            function() {

                            }
                        );

                        jQuery('.date').hide();
                        jQuery('#specific_date').on('click',function()
                        {
                            jQuery('.date').show();
                        });

                        jQuery('.task-option').click(function(e) {
                            jQuery('.task-option').removeClass('select');
                            jQuery(this).addClass('select');
                            var task_val = jQuery(this).attr('id');
                            jQuery('#parcel-capacity').val(task_val);
                        });

                    });

                });
            </script> <?php
        }
    }

    function task_search_callback() {
        global $post;
        $post_description = $post->post_content;
        $from_address = $_POST['from_address'];
        $to_address = $_POST['to_address'];
        if($_POST['request'] == 'task_search') {
            $args = array(
                'post_status' => 'published',
                'post_type' => 'task',
                'posts_per_page' => -1,
                'meta_query' => array(
                    'relation' => 'OR',
                    array(
                        'key' => 'pic_up',
                        'value' => $from_address,
                        'compare' => 'LIKE',
                    ),
                    array(
                        'key' => 'delievery_address',
                        'value' => $to_address,
                        'compare' => 'LIKE',
                    ),
                ),
            );
            // The Query
            $the_query = new WP_Query($args);
            $html = ''; $pointers = '';
            // The Loop
            if ($the_query->have_posts()) {
                $html .= '<div class="task-list">';
                while ($the_query->have_posts()) {

                    $pick_up_address_val = get_post_meta($post->ID, 'pic_up', true);
                    $pointers .= $this->get_lat_long($pick_up_address_val) . '_';

                    $price = get_post_meta($post->ID, 'payment_amount', true);
                    if (!empty($price))
                        $price = get_post_meta($post->ID, 'payment_amount', true);
                    else
                        $price = get_post_meta($post->ID, 'payable', true);
                    $the_query->the_post();
                    $html .= '<div class="task-item">
                                        <div class="task-img"><img src="https://d1xqbpwl1wh09p.cloudfront.net/jobs/default/default-s_150x150@2x.png" width="80"></div>' .
                        '<div class="task-details"><a href="' . get_permalink() . '"><h5>' . get_the_title() . '</h5></a>' . '
                                            <p class="task-from"><span>From</span> ' . get_post_meta($post->ID, 'pic_up', true) . '</p>
                                            <p class="task-to"><span>To</span> ' . get_post_meta($post->ID, 'delievery_address', true) . '</p>
                                            <p class="task-price">' . $price . ' £</p>
                                            <p class="task-date">' . get_the_date('d-M-Y', $post->ID) . '</p>
                                        </div>
                                     </div>';
                }
                $html .= '</div>';
                $html .= '</div>';
                /* Restore original Post Data */
                wp_reset_postdata();
            } else {
                $html .= 'NO TASK FOUND';
            }
//            echo $html;
            //$pick_up_add = get_post_meta($post->ID, 'pic_up', true);
//            print_r($pointers);
            $pointers = explode('_',$pointers);
            $location_point = '';
            for($i = 0; $i< count($pointers);$i+2) {
                $long = $i + 1;
                $location_point .= '["Name '.$i."', '$pointers[$i]', '$pointers[$long]'],";
            }
            echo $html;
        }
        die();
    }

    function get_lat_long($address) {
        ///aisha
        $address = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyDhdrBLLfR9cHxtYHO5SyC3135TuN1h9vw&address='.urlencode($address).'&sensor=false');

        $address = json_decode($address, true);

        if ($address['status'] = 'OK') {

            $latitude = (float) $address['results'][0]['geometry']['location']['lat'];

            $longitude = (float) $address['results'][0]['geometry']['location']['lng'];
        }

        return $latitude . '_'.$longitude;
    }


    /* waseem files upload function code */
    function cvf_upload_files_detail(){

        $parent_post_id = isset( $_POST['post_id'] ) ? $_POST['post_id'] : 0;  // The parent ID of our attachments
        $valid_formats = array("jpg", "png", "gif", "bmp", "jpeg"); // Supported file types
        $max_file_size = 1024 * 500; // in kb
        $max_image_upload = 10; // Define how many images can be uploaded to the current post
        $wp_upload_dir = wp_upload_dir();
        $path = $wp_upload_dir['path'] . '/';
        $count = 0;

        $attachments = get_posts( array(
            'post_type'         => 'attachment',
            'posts_per_page'    => -1,
            'post_parent'       => $parent_post_id,
            'exclude'           => get_post_thumbnail_id() // Exclude post thumbnail to the attachment count
        ) );

        // Image upload handler
        if( $_SERVER['REQUEST_METHOD'] == "POST" ){

            // Check if user is trying to upload more than the allowed number of images for the current post
            if( ( count( $attachments ) + count( $_FILES['files']['name'] ) ) > $max_image_upload ) {
                $upload_message[] = "Sorry you can only upload " . $max_image_upload . " images for each Ad";
            } else {

                foreach ( $_FILES['files']['name'] as $f => $name ) {
                    $extension = pathinfo( $name, PATHINFO_EXTENSION );
                    // Generate a randon code for each file name
                    $new_filename = $this->cvf_td_generate_random_codes_detail( 20 )  . '.' . $extension;

                    if ( $_FILES['files']['error'][$f] == 4 ) {
                        continue;
                    }

                    if ( $_FILES['files']['error'][$f] == 0 ) {
                        // Check if image size is larger than the allowed file size
                        /* if ( $_FILES['files']['size'][$f] > $max_file_size ) {
                            $upload_message[] = "$name is too large!.";
                            continue;

                            // Check if the file being uploaded is in the allowed file types
                        } else */
						if( ! in_array( strtolower( $extension ), $valid_formats ) ){
                            $upload_message[] = "$name is not a valid format";
                            continue;

                        } else{
                            // If no errors, upload the file...
                            if( move_uploaded_file( $_FILES["files"]["tmp_name"][$f], $path.$new_filename ) ) {

                                $count++;
                                $filename = $path.$new_filename;
                                $filetype = wp_check_filetype( basename( $filename ), null );
                                $wp_upload_dir = wp_upload_dir();
                                $attachment = array(
                                    'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ),
                                    'post_mime_type' => $filetype['type'],
                                    'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
                                    'post_content'   => '',
                                    'post_status'    => 'inherit'
                                );
                                // Insert attachment to the database
                                $attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );
                                set_post_thumbnail($parent_post_id, $attach_id );
                                require_once( ABSPATH . 'wp-admin/includes/image.php' );

                                // Generate meta data
                                $attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
                                wp_update_attachment_metadata( $attach_id, $attach_data );
                            }
                        }
                    }
                }
            }
        }
        // Loop through each error then output it to the screen
        if ( isset( $upload_message ) ) :
            foreach ( $upload_message as $msg ){
                printf( __('<p class="bg-danger">%s</p>', 'wp-trade'), $msg );
            }
        endif;
        // If no error, show success message
        if( $count != 0 ){
            // echo "Successfull featured image change";
            /* global $wpdb;
           $select_pst = "SELECT $wpdb->posts.ID from $wpdb->posts where $wpdb->posts.post_parent='".$parent_post_id."'";
           $result = $wpdb->get_results($select_pst,object);
           foreach($result as $kys){
               ?>
               <img src="<?php echo wp_get_attachment_url($kys->ID); ?>"/>
               <?php
           } */
            if (has_post_thumbnail( $parent_post_id ) ){
                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $parent_post_id ), 'single-post-thumbnail' );
                echo $image[0];
            }
        }
        exit();
    }
// Random code generator used for file names.
    function cvf_td_generate_random_codes_detail($length=10) {

        $string = '';
        $characters = "23456789ABCDEFHJKLMNPRTVWXYZabcdefghijklmnopqrstuvwxyz";

        for ($p = 0; $p < $length; $p++) {
            $string .= $characters[mt_rand(0, strlen($characters)-1)];
        }

        return $string;

    }
}