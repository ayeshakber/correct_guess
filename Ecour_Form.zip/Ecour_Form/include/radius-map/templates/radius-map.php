<?php

get_header(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
        <?php

        $args = array(
            'post_status' => 'publish',
            'post_type'   => 'task',
            'posts_per_page' => -1,
        );
        // The Query

        $location_pointers = '';

        $the_query = new WP_Query( $args );
        if ( $the_query->have_posts() ) {
            while ( $the_query->have_posts() ) {
                $the_query->the_post();
                $pick_up_address = get_post_meta($post->ID,'pick_lat_long',true);
                $pick_up_address = explode('_',$pick_up_address);
                if(!empty($pick_up_address[0]))
                    $location_pointers .= '{type: "", name: "'.get_the_title().'", lat: '.$pick_up_address[0].', lng: '.$pick_up_address[1].'},';
            }
            /* Restore original Post Data */
            wp_reset_postdata();
        }
        ?>
        <script>
            var map = null;
            var radius_circle = null;
            var markers_on_map = [];
            var geocoder = null;
            var infowindow = null;

            //all_locations is just a sample, you will probably load those from database
            var all_locations = [
                <?php echo $location_pointers;?>
            ];

            //initialize map on document ready
            $(document).ready(function(){
                var latlng = new google.maps.LatLng(40.723080, -73.984340); //you can use any location as center on map startup
                var myOptions = {
                    zoom: 1,
                    center: latlng,
                    mapTypeControl: true,
                    mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
                    navigationControl: true,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
                geocoder = new google.maps.Geocoder();
                google.maps.event.addListener(map, 'click', function(){
                    if(infowindow){
                        infowindow.setMap(null);
                        infowindow = null;
                    }
                });
            });

            function showCloseLocations() {
                var i;
                var radius_km =  $('#radius_km').val();
                /*radius_km_f = radius_km / 2;
                radius_km_s = radius_km_f / 2;
                radius_km = radius_km_f + radius_km_s;
                alert(radius_km);*/
                var address = $('#address').val();

                //remove all radii and markers from map before displaying new ones
                if (radius_circle) {
                    radius_circle.setMap(null);
                    radius_circle = null;

                }
                for (i = 0; i < markers_on_map.length; i++) {
                    if (markers_on_map[i]) {
                        markers_on_map[i].setMap(null);
                        markers_on_map[i] = null;
                    }
                }

                if (geocoder) {
                    geocoder.geocode({'address': address}, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (status != google.maps.GeocoderStatus.ZERO_RESULTS) {
                                var address_lat_lng = results[0].geometry.location;
                                radius_circle = new google.maps.Circle({
                                    center: address_lat_lng,
                                    radius: radius_km * 1000,
                                    clickable: false,
                                    map: map
                                });
                                if (radius_circle) map.fitBounds(radius_circle.getBounds());
                                var markers_lat_long1 = 0;
                                for (var j = 0; j < all_locations.length; j++) {
                                    (function (location) {
                                        var marker_lat_lng = new google.maps.LatLng(location.lat, location.lng);
                                        var distance_from_location = google.maps.geometry.spherical.computeDistanceBetween(address_lat_lng, marker_lat_lng); //distance in meters between your location and the marker

                                        if (distance_from_location <= radius_km * 1000) {
                                            markers_lat_long1 += marker_lat_lng+'|';
                                            var new_marker = new google.maps.Marker({
                                                position: marker_lat_lng,
                                                map: map,
                                                title: location.name
                                            });      								google.maps.event.addListener(new_marker, 'click', function () {
                                                if(infowindow){
                                                    infowindow.setMap(null);
                                                    infowindow = null;
                                                }
                                                infowindow = new google.maps.InfoWindow(
                                                    { content: '<div style="color:red">'+location.name +'</div>' + " is " + distance_from_location + " meters from my location",
                                                        size: new google.maps.Size(150,50),
                                                        pixelOffset: new google.maps.Size(0, -30)
                                                        , position: marker_lat_lng, map: map});
                                            });
                                            markers_on_map.push(new_marker);
                                        }
                                    })(all_locations[j]);
                                }
//                                update_table(markers_lat_long);
                                console.log('EE'+markers_lat_long1);
                                jQuery('#markers').val(markers_lat_long1);
                            } else {
                                alert("No results found while geocoding!");
                            }
                        } else {
                            alert("Geocode was not successful: " + status);
                        }
                    });
                }
            }


            var placeSearch, autocomplete;
            var componentForm = {
                street_number: 'short_name',
                route: 'long_name',
                locality: 'long_name',
                administrative_area_level_1: 'short_name',
                country: 'long_name',
                postal_code: 'short_name'
            };

            function initAutocomplete() {
                // Create the autocomplete object, restricting the search to geographical
                // location types.
                autocomplete = new google.maps.places.Autocomplete(
                    /** @type {!HTMLInputElement} */(document.getElementById('address')),
                    {types: ['geocode']});
            }

            // Bias the autocomplete object to the user's geographical location,
            // as supplied by the browser's 'navigator.geolocation' object.
            function geolocate() {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(function(position) {
                        var geolocation = {
                            lat: position.coords.latitude,
                            lng: position.coords.longitude
                        };
                        var circle = new google.maps.Circle({
                            center: geolocation,
                            radius: position.coords.accuracy
                        });
                        autocomplete.setBounds(circle.getBounds());
                    });
                }
            }
        </script>

        <input id="address" value="Karachi, Sindh, Pakistan" placeholder="Input Address"/>
        <input type="hidden" id="markers" value="" />
        <select id="radius_km">
            <option value=1>1km</option>
            <option value=2>2km</option>
            <option value=5>5km</option>
            <option value=30>30km</option>
            <option value=60>60km</option>
            <option value=100>100km</option>
            <option value=1000>1000km</option>
        </select>
        <button id="update_map" onClick="showCloseLocations()">Show Locations In Radius</button>
        <div id="map_canvas"  style="width:100%; height:300px;"></div>
        <div class="task-results">
        <?php

         /* $args = array(
            'post_status' => 'publish',
            'post_type'   => 'task',
            'posts_per_page' => 6,
        ); */
        // The Query
			// $the_query = new WP_Query( $args );
			$temp = $wp_query; 
		  $wp_query = null; 
		  $wp_query = new WP_Query(); 
		   $wp_query->query('showposts=6&post_status=publish&post_type=task'.'&paged='.$paged); 
        // The Loop
        if ( $wp_query->have_posts() ) {
            echo '<div class="task-list">';
             while ($wp_query->have_posts()) {
                $price = get_post_meta($post->ID, 'payment_amount', true);
                if (!empty($price))
                    $price = get_post_meta($post->ID, 'payment_amount', true);
                else
                    $price = get_post_meta($post->ID, 'payable', true);
                $wp_query->the_post();
           echo '<div class="task-item">
                                    <div class="task-img"><img src="https://d1xqbpwl1wh09p.cloudfront.net/jobs/default/default-s_150x150@2x.png" width="80"></div>' .
                    '<div class="task-details"><a href="' . get_permalink() . '"><h5>' . get_the_title() . '</h5></a>' . '
                                        <p class="task-from"><span>From</span> ' . get_post_meta($post->ID, 'pic_up', true) . '</p>
                                        <p class="task-to"><span>To</span> ' . get_post_meta($post->ID, 'delievery_address', true) . '</p>
                                    
                                    </div>
                                        <p class="task-price">' . $price . ' Rs</p>
                                        <p class="task-date">' . humanTiming(get_the_date('d-M-Y H:i:s', $post->ID)) . '</p>
                                 </div>';
            } 
         } 
		/* $temp = $wp_query; 
  $wp_query = null; 
  $wp_query = new WP_Query(); 
  $wp_query->query('showposts=6&post_type=task'.'&paged='.$paged); 

  while ($wp_query->have_posts()) : $wp_query->the_post(); 
$price = get_post_meta($post->ID, 'payment_amount', true);
                if (!empty($price))
                    $price = get_post_meta($post->ID, 'payment_amount', true);
                else
                    $price = get_post_meta($post->ID, 'payable', true);
                $the_query->the_post();
                echo '<div class="task-item">
                                    <div class="task-img"><img src="https://d1xqbpwl1wh09p.cloudfront.net/jobs/default/default-s_150x150@2x.png" width="80"></div>' .
                    '<div class="task-details"><a href="' . get_permalink() . '"><h5>' . get_the_title() . '</h5></a>' . '
                                        <p class="task-from"><span>From</span> ' . get_post_meta($post->ID, 'pic_up', true) . '</p>
                                        <p class="task-to"><span>To</span> ' . get_post_meta($post->ID, 'delievery_address', true) . '</p>
                                    
                                    </div>
                                        <p class="task-price">' . $price . ' Rs</p>
                                        <p class="task-date">' . humanTiming(get_the_date('d-M-Y H:i:s', $post->ID)) . '</p>
                                 </div>';
           
								 endwhile; */ ?>

<nav>
    <?php previous_posts_link('&laquo; Newer') ?>
    <?php next_posts_link('Older &raquo;') ?>
</nav>

<?php 
  $wp_query = null; 
  $wp_query = $temp;  // Reset

        function humanTiming ($time)
        {
            $time = strtotime($time);
            $time = time() - $time; // to get the time since that moment
            $time = ($time<1)? 1 : $time;
            $tokens = array (
                31536000 => 'year',
                2592000 => 'month',
                604800 => 'week',
                86400 => 'day',
                3600 => 'hour',
                60 => 'minute',
                1 => 'second',
            );
            foreach ($tokens as $unit => $text)
            {
                if ($time < $unit) continue;
                $numberOfUnits = floor($time / $unit);
                return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'');
            }
        }
        ?>
    </div>
    <script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete"
            async defer></script>
    <script type="text/javascript" src="http://www.google.com/jsapi"></script>
      <script type="text/javascript">
            //google.load("maps", "3",{other_params:"sensor=false&libraries=geometry"});
        </script>
    </main><!-- .site-main -->
    <?php //get_sidebar( 'content-bottom' ); ?>

</div><!-- .content-area -->

<?php //get_sidebar(); ?>
<?php get_footer(); ?>
