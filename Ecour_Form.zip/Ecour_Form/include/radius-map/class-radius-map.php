<?php

Class Radius_Map {
	
	public function __construct() {
        add_filter( 'template_include', array($this,'etb_radius_map'), 99 );

        add_action( 'wp_footer', array($this,'radius_map_javascript') );
        add_action( 'wp_ajax_radius_map', array($this,'radius_map_callback') );
        add_action( 'wp_ajax_nopriv_radius_map', array($this,'radius_map_callback') );
	}

	public function etb_radius_map($template) {
        global $post;

        if(is_page('radius-map')) {
            $new_template =  dirname(__FILE__) . "/templates/radius-map.php" ;
            if ( '' != $new_template ) {
                return $new_template ;
            }
        }
        return $template;
    }

    function radius_map_javascript() { ?>
        <script type="text/javascript" >

            /* Make this document ready function to work on click where you want */
            jQuery(document).ready(function($) {

                var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

                jQuery('#update_map').click(function() {

                    var address = jQuery('#address').val();
                    setTimeout(function() {
                        var markers = jQuery('#markers').val();
                            alert(markers);
                        var data = {
                            'action': 'radius_map',
                            'address': markers,
                        };

                        $.post(ajaxurl, data, function(response) {
                            alert(response);
//                            jQuery('.task-results').html(response);
                        });

                    },1000);

                });
            });
        </script> <?php
    }

    function radius_map_callback() {
        global $post;

        $address = $_POST['address'];
        $address = explode('|',$address);

        $address_lat = explode(',',$address);
        /*$address_lat = array();
        $address_lat_num = '';
        for($i=0;$i<count($address);$i++){
            $address_lat = explode(',',$address[$i]);
            $address_lat_num .= str_replace('(','',$address_lat[0]) . '|';
        }*/

        echo 'ZXC2'.print_r($address_lat);
        die();
        $args = array(
            'post_status' => 'publish',
            'post_type'   => 'task',
            'posts_per_page' => -1,

            /*'meta_query' => array(
                'relation' => 'OR',
                    array(
                    'key' => 'pic_up',
                    'value' => $address,
                    'compare' => '=',
                ),
            )*/

            'meta_query' => array(
                'relation' => 'OR',
                    array(
                    'key' => 'pick_lat_long',
                    'value' => $address,
                    'compare' => '=',
                ),
            )
        );
        // The Query
        $the_query = new WP_Query( $args );
        $html = '';
        // The Loop
        if ( $the_query->have_posts() ) {
            $html .= '<div class="task-list">';
            while ($the_query->have_posts()) {
                $price = get_post_meta($post->ID, 'payment_amount', true);
                if (!empty($price))
                    $price = get_post_meta($post->ID, 'payment_amount', true);
                else
                    $price = get_post_meta($post->ID, 'payable', true);
                $the_query->the_post();
                $html .= '<div class="task-item">
                                    <div class="task-img"><img src="https://d1xqbpwl1wh09p.cloudfront.net/jobs/default/default-s_150x150@2x.png" width="80"></div>' .
                    '<div class="task-details"><a href="' . get_permalink() . '"><h5>' . get_the_title() . '</h5></a>' . '
                                        <p class="task-from"><span>From</span> ' . get_post_meta($post->ID, 'pic_up', true) . '</p>
                                        <p class="task-to"><span>To</span> ' . get_post_meta($post->ID, 'delievery_address', true) . '</p>
                                    
                                    </div>
                                        <p class="task-price">' . $price . ' Rs</p>
                                        <p class="task-date">' . $this->humanTiming(get_the_date('d-M-Y H:i:s', $post->ID)) . '</p>
                                 </div>';
            }
        }


        echo $html;
        die();
    }

    function humanTiming ($time)
    {
        $time = strtotime($time);
        $time = time() - $time; // to get the time since that moment
        $time = ($time<1)? 1 : $time;
        $tokens = array (
            31536000 => 'year',
            2592000 => 'month',
            604800 => 'week',
            86400 => 'day',
            3600 => 'hour',
            60 => 'minute',
            1 => 'second',
        );
        foreach ($tokens as $unit => $text)
        {
            if ($time < $unit) continue;
            $numberOfUnits = floor($time / $unit);
            return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'');
        }
    }
}