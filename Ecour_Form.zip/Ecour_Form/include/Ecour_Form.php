<?php
//include("fb_config.php");
//include("includes/functions.php");

class Ecour_Form
{
    function __construct()
    {
        add_action('init',array($this,'eregister'));    //IMAGE UPLOAD
        add_shortcode('ecour_form', array($this, 'sign_up_form'));  //DONE
        ##ECOUR LOGIN FUNCTION CALL
        add_shortcode('ecour_login',array($this,'ecour_login'));
        add_action('login_with_email_address', array($this, 'login_with_email_address'));
    }
    #START STRIPE ACCOUNT API
    function account_check()
    {
        if (!empty($_POST['strip_api']))
        {
            $res = array();
            # $publishableKey = 'pk_test_ktBe4SXg14zROMbZxbiDaxOi'; #### STRIPE MY API KEY ####
            # $secretKey = 'sk_test_B3eZEv3hzysWDbUxzyVtyRuF';    #### STRIPE MY SECRET KEY ####
            $res['secretKey']= $_POST['strip_api'];
            $url = 'https://api.stripe.com/v1/charges?key='.$res['secretKey'];
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $res['auth'] = curl_exec($curl);
            if($res['auth'])
            {
                $json = json_decode($res['auth']);
                print_r($res['json_result']);
                if(!empty($json->error->message))
                {
                    $res['json_result'] =  '<b>INVALID</b>';
                }
                else
                {
                    $res['json_result'] = '<b>VALID</b>';
                }
            }
            print_r(json_encode($res));
            die();
        }
    }   #end func
    #END STRIPE ACCOUNT API
    #START REGISTRATION FORM
    function eregister()
    {
        $res = array();
        if(isset($_POST["aisha"]))
        {
            ### START condition for Facebook user  ###
            $res['123'] = 'aisa';
            $res['display_name'] =$_POST['my_name'];
            $res['email'] = $_POST['email'];
            $res['user_name'] = str_replace(' ','_', $res['display_name']);
            $res['full_name'] = explode(' ',$res['display_name']);
            $res['name_count'] = count($res['full_name']);
            $res['f_name'] = $res['full_name'][0];
            $res['l_name'] = $res['full_name'][1];
            ### FACEBOOK USERS GET DATA BY EMAIL ###
            #$res['fb_user_email'] = get_user_by('user_email',$res['email']);
            ### FACEBOOK USERS GET DATA BY EMAIL ###
            ##ERROR MSG DISPLAY##
            $args = array(
                'role'=> 'subscriber',
                'fields'  => 'all',
            );
            $res['all_user'] =  get_users( $args );
            $all_user_email='';
            $all_user_name='';
            foreach ( $res['all_user'] as $value)
            {
                $all_user_email[] = $value->user_email;
                $all_user_name[] = $value->user_login;
            }
            $res['my_all_email']= $all_user_email;
            $res['my_all_username']= $all_user_name;
            ##FOR UNIQUE USER NAME
            if (in_array($res['user_name'] , $res['my_all_username']))
            {
                $res['username_match'] = "Username is Already Exist.";
            }
            ##FOR UNIQUE EMAIL
            if (in_array($res['email'] , $res['my_all_email']))
            {
                $res['email_match'] = "Email Address Already Exist.";
                $res['fb_user_email'] = get_user_by('user_email',$res['email']);

            }
            $res['password'] = $_POST['password'];
            $res['phone'] = $_POST['phone'];
            $res['location'] = $_POST['location'];
            $res['agree'] = $_POST['agree'];
            $res['strip_api'] = $_POST['strip_api'];
            $hash = md5(rand(1000,5000));	//for unique registartion key for user
            #USER CREATING ARRAY
            $res['ecour_user'] = array(
                'user_login' => $res['user_name'],
                'user_email' => $res['email'],
                'user_pass' => $res['password'],
                'display_name' => $res['display_name'],
                'role' => 'subscriber',
            );
            #USER INSERT FUNCTION
            $res['user_id'] = wp_insert_user($res['ecour_user']);
            #CHECK ERROR
            if (!is_wp_error($res['user_id']))
            {
                #UPDATE USER INFORMATION
                $res['user_location'] = update_user_meta($res['user_id'], 'user_location', $res['location']);
                $res['user_phone'] = update_user_meta($res['user_id'], 'user_phone', $res['phone']);
                $res['terms_agree'] = update_user_meta($res['user_id'], 'terms_agree', $res['agree']);
                $res['stripe_secret_key'] = update_user_meta($res['user_id'], 'stripe_secret_key', $res['strip_api']);
                $res['account_hash_key'] = update_user_meta($res['user_id'], 'account_hash_key', $hash);
                $res['f_name'] = update_user_meta($res['user_id'], 'first_name', $res['f_name']);
                $res['l_name'] = update_user_meta($res['user_id'], 'last_name',  $res['l_name']);

                #START PROFILE IMAGE UPLOAD
                $uplod_dir = wp_upload_dir();
                $path = $uplod_dir['path'];

                $res['sourcePath'] = $_FILES['photo']['tmp_name']; // Storing source path of the file in a variable
                $res['targetPath'] = $path . '/' . $_FILES['photo']['name']; // Target path where file is to be stored
                $res['success'] = move_uploaded_file($res['sourcePath'], $res['targetPath']); // Moving Uploaded file
                if ($res['success'])
                {
                    $res['upload_message'] = 'IMAGE UPLOADED Successfully';
                    $res['pro_meta_key'] = update_user_meta($res['user_id'],'profile_pic', $uplod_dir['url'].'/'.$_FILES['photo']['name']);
                }
                #END PROFILE IMAGE UPLOAD
                $res['user_created'] = '<h3><i>USER CREATED SUCCESSFULLY!<br> CHECK YOUR EMAIL TO RECEIVED WELL COME EMAIL FROM OUR TEAM.</i></h3>';
                ##### WELCOME EMAIL #######
                $to = $res['email'];
                $subject = "Welcome to Ecour";
                $message = '
                    <html align="center">
                    <head>
                    <title>Welcome to Ecour</title>
                    </head>
                    <body>
                    <h1>Welcome to Ecour :)</h1>
                    <p>With Ecour you can send anything anywhere - with decent, helpful people who will be going that way, anyway. You can finally bring home that chair you inherited from grandma, or the skis that remained in your shed last year. How else would you pick them up in an easy, safe and cost-effective way? </p><br>
<p>Wanna send or bring something? Use the buttons <below>2cb cb cb cb cb cb cb cb cb cb cb cb cb cb cb cb </below> to do it</p>
<p>All bringers are registered with their name, email address and credit card information. It provides that extra security and helps us to assure and simplify the service at the same time.</p>   
               <p>Please click this link to activate your account:'.get_permalink(172).'?verify=1&user_id='.$res['user_id'].'&email='.$res['email'].'&hash='.$hash.'</p>
                    </body>
                    </html>
                    ';
                // Always set content-type when sending HTML email
                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                // More headers
                $headers .= 'From: <webmaster@example.com>' . "\r\n";
                $headers .= 'Cc: ayesha.aimviz@gmail.com' . "\r\n";
                $res['email_sent'] = mail($to, $subject, $message, $headers);
                ##### WELCOME EMAIL #######
            }
            print_r(json_encode($res));
            die();
        }
        if($_GET['verify']==1)
        {
            $u_id = $_GET['user_id'];
            $res['verify'] = update_user_meta($u_id, 'email_verify', '1');
        }
    }
    #END REGISTRATION FORM
    function sign_up_form() //DONE
    {
        ?>
        <style>
         /*   #map {
                height: 100%;
            }
            .controls {
                margin-top: 10px;
                border: 1px solid transparent;
                border-radius: 2px 0 0 2px;
                box-sizing: border-box;
                -moz-box-sizing: border-box;
                height: 32px;
                outline: none;
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
            }
            #pac-input {
                background-color: #fff;
                font-family: Roboto;
                font-size: 15px;
                font-weight: 300;
                margin-left: 12px;
                padding: 0 11px 0 13px;
                text-overflow: ellipsis;
                width: 300px;
            }
            #pac-input:focus {
                border-color: #4d90fe;
            }
            .pac-container {
                font-family: Roboto;
            }
            #type-selector {
                color: #fff;
                background-color: #4d90fe;
                padding: 5px 11px 0px 11px;
            }
            #type-selector label {
                font-family: Roboto;
                font-size: 13px;
                font-weight: 300;
            }
            #target {
                width: 345px;
            }*/
        </style>
        <!-- FB REGISTRATION -->
        <?php
        global $facebook,$fbPermissions,$homeurl_singup;
        $user_id= get_current_user_id();
        $user_profile = $facebook->api('/me?fields=id,first_name,last_name,email,gender,locale,picture');
        $user = new Users();
        $user_data = $user->checkUser('facebook',$user_profile['id'],$user_profile['first_name'],$user_profile['last_name'],$user_profile['email'],$user_profile['gender'],$user_profile['locale'],$user_profile['picture']['data']['url']);
        #var_dump($user_profile);
        #echo '<br>';
        $fb_id = $user_profile ["id"];
        $first_name = $user_profile ["first_name"];
        $last_name = $user_profile ["last_name"];
        $email = $user_profile ["email"];
        $gender = $user_profile ["gender"];
        $picture = $user_profile ["picture"]["data"]["url"];
        $password = md5(rand(1000,5000));
        if(empty($user_profile['id']))
        {
            $loginUrl = $facebook->getLoginUrl(array('redirect_uri'=>'http://110.37.221.34:7777/blog/wordpress/ecour-forms/','scope'=>$fbPermissions));
            $output = '<a href="'.$loginUrl.'"><img src="'.plugin_dir_url( __FILE__ ) .'/images/fb_signup.png"></a>';
        }
        else
        {
            $fb_user_info = array(
                'user_login'=>$first_name.'_'.$last_name,
                'user_email'=> $email,
                'user_pass'=> $password,
                'role' => 'subscriber'
            );
            $fb_user_id = wp_insert_user($fb_user_info);
            #print_r($fb_user_id->errors);
            $fb_id = update_user_meta($fb_user_id,'fb_id',$fb_id);
            $first_name = update_user_meta($fb_user_id,'first_name',$first_name);
            $last_name = update_user_meta($fb_user_id,'last_name', $last_name);
            $fb_verify = update_user_meta($fb_user_id,'fb_verify','true');
            $fb_email = update_user_meta($fb_user_id,'fb_email','true');
            $fb_photo = update_user_meta($fb_user_id,'photo',$picture);
            if ( empty( $fb_user_id->errors ) )
            {
                echo '<h3 style="color:red">You are connected with Facebook.<br>  Please Fill All Required Fields to Completed Registration.</h3>';
            }
            else
            {
                #print_r($fb_user_id);
                echo '<h3>This Facebook User is Already Connected To Our Site, Please Go to Facebook and Logout Your Account and Try Another One.<br>Then Go Back On This Page And Again Sign Up To Our Site.</h3>';
                ### END FB SESSSION EXPIRE###
               $loginUrl = $facebook->getLoginUrl(array('redirect_uri'=>'http://110.37.221.34:7777/blog/wordpress/ecour-forms/','scope'=>$fbPermissions));
                $output = '<a href="'.$loginUrl.'"><img src="'.plugin_dir_url( __FILE__ ) .'/images/fb_signup.png"></a>';
            }

        }
        echo $output;
        $get_fb_id ='';
        $u_info ='';
        $email ='';
        $first_name ='';
        $last_name ='';
        $fb_photo ='';
        $user_pass ='';
        if(!empty($fb_user_id))
        {
            $u_info = get_userdata($fb_user_id);
            $email = $u_info->user_email;
            $user_pass = $u_info->user_pass;
            $get_fb_id = get_user_meta($fb_user_id,'fb_id',true);
            $first_name = get_user_meta($fb_user_id,'first_name',true);
            $last_name = get_user_meta($fb_user_id,'last_name',true);
            $fb_photo = get_user_meta($fb_user_id,'photo',true);
        }
        ?>
        <!-- FB REGISTRATION -->
        <form action="" method="POST" enctype="multipart/form-data" name="ecour_form" id="ecour_form">
            <h2>Ecour Registration Form</h2>
            <label>Name*</label>
            <input type="text" name="my_name" id="my_name" class="my_name" value="<?php if(($first_name!='') && ($last_name!='')){ echo $first_name.' '.$last_name;}else{echo '';}?>" required/><br><br>
            <div id="username_match_msg" style="color:deeppink"></div>

            <label>Email*</label>
            <input type="text" name="email" id="email" class="email" value="<?php if($email!=''){ echo $email;}else{echo '';}?>" required/><br><br>
            <div id="email_match_msg" style="color:deeppink"></div>

            <label>Password*</label>
            <input type="password" name="password" id="password" class="password" <?php if($user_pass!=''){ echo 'disabled' ;}else{echo 'required';}?>  /><br><br>

            <label>Mobile Number*</label>
            <input type="text" name="phone" id="phone" class="phone" required/><br><br>

            <div class="row">
                <div class="col-sm-6" id="image_upload">
                    <label>Upload a Photo*</label>
                    <input type="file" name="photo" id="photo" class="photo" required/><br><br>
                </div>
                <div class="col-sm-4" id="image_preview">
                    <img id="drag_img" src="<?php if($fb_photo!='') {echo $fb_photo; }else { echo '';} ?>" alt="" />
                </div>
            </div>
            <input id="geocomplete" type="text" placeholder="Type in an address" size="90" />
            <div class="map_canvas" style="height: 500px;"></div>
            <!--   MAP LOCATION    -->

            <label>Connect / Setup Strip Account* </label>
            <div class="row">
                <div class="col-sm-6">
                    <?php //echo do_shortcode('[accept_stripe_payment button_text="Connect to your Existing Strip Account" ]'); ?>
                    <input type="button" name="existing_account" id="existing_account" class="existing_account" value="Connect to your existing strip account" required/><br><br>
                    <div id="strip_acoount_detail" class="strip_acoount_detail">
                        <input type="text" name="strip_api" id="strip_api" class="strip_api" value="" placeholder="Enter youe Strip Account API Key" required/><br>
                        <input type="button" name="strip_api_submit" id="strip_api_submit" class="strip_api_submit" value="Check" /><br>
                        <div id="strip_loader" style="display:none;">
                            <img src="http://110.37.221.34:7777/blog/wordpress/wp-content/uploads/2016/09/ajax-loader.gif "/>
                        </div>
                        <div>
                            <input type="hidden" name="stripe_val" id="stripe_val" class="stripe_val" value="">
                        </div>
                        <div id="strip_api_msg" style="color:blue"></div>
                    </div><br>
                </div>
                <div class="col-sm-6">
                    <a href="https://stripe.com/">
                        <input type="button" value="Setup a new strip account" required/>
                    </a>
                </div><br><br>
            </div>
            <input type="checkbox" name="agree" id="agree" class="agree" value="1" required/>
            <label>Agree to The Terms And Conditions*</label><br><br>
            <input type="submit" name="aisha" value="Create Account" class="aisha" id="aisha"/>
        </form>
        <div id="all_field_correct" class="all_field_correct" style="color:red"></div>
        <div id="create_loader" style="display:none;">
            <img src="http://110.37.221.34:7777/blog/wordpress/wp-content/uploads/2016/09/ajax-loader.gif "/>
        </div>
        <div id="photo_status" style="color:green"> </div>
        <div id="success_msg" style="color:red"></div>
        <div id="login_link">
            <p>Now You can login to your Account.</p>
            <a href="<?php echo site_url().'/ecour-login/'; ?>">Login</a>
        </div>
        <style>
            #map{
                height:50px;
            }
        </style>
        <?php
    }   #END function
    #########START LOGIN FUNCTION#####
    function ecour_login()
    {
        ?>
        <form class="ecour_login_form" id="ecour_login_form" name="ecour_login_form" method="POST" accept-charset="utf-8">
            <label>Email:</label>
            <input type="email" name="ecou_user_email" id="ecou_user_email" required="required"> </br>

            <label>Password:</label>
            <input type="password" name="ecour_user_pass" id="ecour_user_pass" required="required"> </br>

            <input type="checkbox" name="remember_me" id="remember_me">remember me </br>
            <input type="submit" name="submit_login" value="LOG IN">
        </form>
        <?php
        if (isset($_POST['submit_login']))
        {
            $user_email = wp_strip_all_tags($_POST['ecou_user_email']);
            $user_email = $this->login_with_email_address($_POST['ecou_user_email']);
            $user_pas = wp_strip_all_tags($_POST['ecour_user_pass']);
            echo "Your Email: ";
            echo "<br>";
            print_r($_POST['ecou_user_email']);
            echo "<br>";
            echo "Your Password: ";
            print_r($_POST['ecour_user_pass']);
            echo "<br>";
            $creds = array();
            $creds['user_login']=$user_email;
            $creds['user_password']=$user_pas;
            $creds['remember_me'] = 'true';
            $user = wp_signon($creds ,false);
            if (is_wp_error($user))
            {
                echo $user->get_error_message();
            }
            else
            {
                wp_redirect(site_url());
                exit;
            }
        }
    }	//end LOGIN function
    function login_with_email_address($username)
    {
        $user = get_user_by($username);
        if(!empty($user->user_login))
            $username = $user->user_login;
        return $username;
    }
    ######### END LOGIN FUNCTION #####
    function email_sent($user_id,$message,$subject)
    {
        $to_email = $user_id->user_email;
        $hash = md5(rand(1000,5000));	//for unique registartion for register user
        $message = '
          <html align="center">
             <head>
              <title>Welcome to Ecour</title>
             </head>
             <body>
               <h1>Welcome to Ecour :)</h1>
               <p>With Ecour you can send anything anywhere - with decent, helpful people who will be going that way, anyway. You can finally bring home that chair you inherited from grandma, or the skis that remained in your shed last year. How else would you pick them up in an easy, safe and cost-effective way? </p><br>
               <p>Wanna send or bring something? Use the buttons <below>2cb cb cb cb cb cb cb cb cb cb cb cb cb cb cb cb </below> to do it</p>
               <p>All bringers are registered with their name, email address and credit card information. It provides that extra security and helps us to assure and simplify the service at the same time.</p>   
               <p>Please click this link to activate your account:' . get_permalink(172) . '?verify=1&user_id=' . $user_id . '&email=' . $to_email . '&hash=' . $hash . '</p>
            </body>
          </html>
          ';
        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        // More headers
        $headers .= 'From: <webmaster@example.com>' . "\r\n";
        $headers .= 'Cc: ayesha.aimviz@gmail.com' . "\r\n";
        mail($to_email, $subject, $message, $headers);
    }
}   #END OF CLASS
///FACEBOOK CONNECTIONS START HERE
///FACEBOOK CONNECTIONS END HERE
?>