jQuery(document).ready(function(){
	//jQuery('.single-task .user-task').append('<div class="chatcontent"></div>');
//	 var box1 = jQuery('.single-task .chats').wrapAll();
//	 var box2 = jQuery('.single-task .chat-box').wrapAll();
//	jQuery('.chatcontent').append(box1);
//	jQuery('.chatcontent').append(box2);
//	var chat_user_show = jQuery('.single-task .chat_user_show').wrapAll();
//     jQuery(chat_user_show ).insertAfter('.single-task .chatcontent');
//	
	
	jQuery('.banck_ac').click(function(){
		jQuery('.country_main').show();
	});
	jQuery('.ctns_btns').click(function(){
		jQuery('.continue_banck_account_detail').show();
		jQuery('.country_main').hide();
	});
	jQuery('.btn-bank-type-close').click(function(){
		jQuery('.continue_banck_account_detail').hide();
	});
	jQuery('.btn-bank-type-close-btns').click(function(){
		jQuery('.country_main').hide();
	});
	jQuery('#routing_ac_holder_no').blur(function(){
		jQuery('#bank_account_save').removeAttr('disabled');
	});

	// Task Scrolling
	jQuery('.item-excerpt a, .more-info button').click(function() {
		jQuery('html, body').animate({scrollTop: '850px'}, 800)
	});
});