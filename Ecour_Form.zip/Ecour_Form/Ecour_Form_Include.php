<?php
ob_start();
/**
 * @package Ecour_Form
 * @version 4.4
 */
/*
Plugin Name: Ecour_Form
Plugin URI: https://wordpress.org/plugins/Ecour_Form/
Description: Youtube_Post can manage multiple youtube link, plus you can customize the link and the mail contents flexibly with simple markup.
Version: 4.4
Author:Ayesha Akber
Author URI: http://localhost/
*/
/*
@parameter: $url
@output : array|object|string
@author: Ayesha Akber
*/

#### INCLUDE ECOUR FORM FOR SIGN UP #####
/*include('include/Ecour_Form.php');
$ecour = new Ecour_Form(); #CLASS OBJECT*/

define('PLUGIN_URL',plugin_dir_path( __FILE__ ));   //F:/xzamp/htdocs till plugin folder
define('PLUGIN_HTTP_URL',plugin_dir_url( __FILE__ ));   //hhtps:www.google.com till plugin folder
/*echo PLUGIN_HTTP_URL;
die();*/
/*echo PLUGIN_URL."facebook/fb_config.php";
die();*/
//echo plugin_dir_path( __FILE__ );
//die();

include('Registration/register.php');
$register =  new Ecour_Register();

include('include/notifications/class-notification.php');
$notification =  new Notification();

include('include/user_profile_update/class-update-user-profile.php');
$update_user_profile =  new update_user_profile();

include('include/bring/class-task-view.php');
$task_view = new Task_View();

include('include/chats/class_chats_view.php');
$user_msg = new class_chats_view();

include('include/radius-map/class-radius-map.php');
$radius_map = new Radius_Map();

#### INCLUDE PROFILE PAGE VIEW #####
include('include/class-profile-view.php');
$profile_view = new Profile_View(); #CLASS OBJECT
/////////
//

add_action('wp_footer','admin_ajax_link',1);

function admin_ajax_link() { ?>
        <script type="text/javascript" >
            jQuery(document).ready(function($) {
                    var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
                    localStorage.setItem("ajax_url", ajaxurl);
            });
        </script>
    <?php
}


    add_action('wp_enqueue_scripts','ecour_js');
    ###########################
    ###########################
    function ecour_js()     //DONE
    {
        if( get_the_ID()==133)
        {
            # MAP SRIPT #
           /* wp_enqueue_script('my-locations2', 'http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places', array('jquery'));
             wp_enqueue_script('gogole-api', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', array('jquery'));
            wp_enqueue_script('geocomplete', plugin_dir_url( __FILE__ ).'js/jquery.geocomplete.js', array('jquery'));*/
            # MAP SRIPT #

           // add_action('wp_footer',array($this,'geo_ecour'));
            # MAP SCRIPT #
          //  wp_enqueue_script('my-locations2', 'http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places', array('jquery'));
           // wp_enqueue_script('gogole-api', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', array('jquery'));
            // wp_enqueue_script('geocomplete', plugin_dir_url( __FILE__ ).'js/jquery.geocomplete.js');
            # MAP SCRIPT #
           // wp_enqueue_script('my-location', plugin_dir_url( __FILE__ ).'js/ecour.js', '','',true);
        }
        #include CSS file
        //wp_enqueue_script('my-locations1', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js', array('jquery'));
        //wp_enqueue_script('jquery-popup', 'http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js');

        wp_enqueue_style('ecoure-form-css', plugin_dir_url(__FILE__)  . 'css/style.css' );
        wp_enqueue_style('popupbox-css', plugin_dir_url(__FILE__)  . 'css/alerty.css' );
        wp_enqueue_style('basestyle-css', plugin_dir_url(__FILE__)  . 'css/bastyle.css' );
        //wp_enqueue_style('popupbox-', plugin_dir_url(__FILE__)  . 'css/remodal-default-theme.css' );
        wp_enqueue_script('popup-box-model', plugin_dir_url( __FILE__ ).'js/alerty.js' );
        wp_enqueue_script('ecour-script', plugin_dir_url( __FILE__ ).'js/script.js' );

        #bootstrap
        wp_enqueue_style('my-css', 'http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css');
        wp_enqueue_script('my-locations3', 'http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array('jquery'));

        #bootstrap

        #use for define global variable
        #call js file
        //wp_localize_script('my-location', 'ajax_call_ecour', array('ajaxurl_ecour' => admin_url('admin-ajax.php')));

    }

    function geo_ecour()
    {
        ?>
        <script>
        $(function(){
            var options = {
            map: ".map_canvas"
            };

            jQuery("#geocomplete").geocomplete(options)
            .bind("geocode:result", function(event, result){
                $.log("Result: " + result.formatted_address);
            })
            .bind("geocode:error", function(event, status){
                $.log("ERROR: " + status);
            })
            .bind("geocode:multiple", function(event, results){
                $.log("Multiple: " + results.length + " results found");
            });
        });
        </script>
    <?php
    }
    ###########################
    ###########################

#FB INCLUDE
//include_once("include/config.php");
//include_once("include/includes/functions.php");
#$loginUrl = $facebook->getLoginUrl(array('redirect_uri'=>$homeurl,'scope'=>$fbPermissions));
#echo $loginurl;
#die();

add_action('task_header','task_header');

function task_header() {
        global $post;
        $post_description = $post->post_content;
        if(isset($_GET['task_id']))
            $post_id = $_GET['task_id'];
        else
            $post_id = $post->ID;

		$post_title= get_the_title($post_id);

        setup_postdata($post);  // FOR AUTHOR

		global $wpdb;
        $html = '';
        $html .= '<div class="header-wrap">';
		$select_pst = "SELECT $wpdb->posts.ID from $wpdb->posts where $wpdb->posts.post_parent='".$post_id."' ORDER BY wp_0fb446804f_posts.`ID` DESC LIMIT 1";
		$result = $wpdb->get_results($select_pst,object);
		if(!empty($result)){
            foreach($result as $keyss){

            $html .= '<div class="task-profile-pic">
                    <img src="'.wp_get_attachment_url($keyss->ID) . '" width="100"/>
                    </div>
                    <div class="taskthings"><h3><a href="'.get_permalink($post_id).'">'. $post_title.'</a></h3></div>
                ';
            }
        }
        else{
            $html .= '<div class="task-profile-pic">
                <img src="https://d1xqbpwl1wh09p.cloudfront.net/jobs/default/default-s_150x150@2x.png" width="100"/>
                </div>
                <div class="taskthings"><h3><a href="'.get_permalink($post_id).'">'. $post_title.'</a></h3></div>
            ';
        }
		$locations = get_post_meta($post_id,'pic_up',true) . ' &#8594; ' . get_post_meta($post_id,'delievery_address',true);
        $price = get_post_meta($post_id,'payable',true);

        $total_miles = get_post_meta($post_id,'total_miles',true);
        $total_miles = '('. $total_miles.' Miles)';
        #var_dump($price);
        if(!empty($price))
        {
            #$author = get_the_author($post_id);
            $author=$post->post_author;
            /*echo "POST AUTHOR ID: ";
            echo $author;*/
            #$price = get_post_meta($post_id,'payable',true);
             #$price = (round( $price));  #round values
            #printf( "%6.2f",$price);
            #$price = get_post_meta($post_id,'transporter_paid',true);
            #$insurance_pay = get_post_meta($post_id,'insurance_pay',true);
            #$insurance_pay = get_post_meta($post_id,'insurance_cost',true);
			#$insurance_pay = get_post_meta($post_id,'insurance_cost_2',true);
           # $insurance_pay ='';
            $price ='';
            $insurance_pay = '';
            $trans_paid='';
            $task_header_msg = '';

            if (get_current_user_id() == $author ) 
            {
                $price = get_post_meta($post_id,'payable',true);
                $price = round($price , 2, PHP_ROUND_HALF_UP);
                $insurance_pay = get_post_meta($post_id,'insurance_cost',true);
                $insurance_pay = 'Sender pays the £'.$insurance_pay.' Insurance and service fee ';

                $trans_paid = get_post_meta($post_id,'transporter_paid',true);
                #$trans_paid = round($trans_paid , 2, PHP_ROUND_HALF_UP);
                $trans_paid = 'The transporter will receive £'. $trans_paid;
                 $task_header_msg = 'Sending this will cost:';

            }
            else
            {
                $price = get_post_meta($post_id,'transporter_paid',true);
                #$price = round($price , 2, PHP_ROUND_HALF_UP);
                $insurance_pay = '';
                $task_header_msg = 'Deliver it and make:';
            }

        
			$html .= '<div class="overview-info">
                    <div class="item">
                        <div class="item-image"></div>
                        <div class="item-title"></div>
                        <div class="item-locations">'.$locations.' '.$total_miles.'</div>
                    </div>
                     
                    <div class="item-delivery">
                        <h3 style="text-align: right;">'.$task_header_msg.'</h3>
						<div class="item-price">£'.$price .'</div> 
                        <div class="item-price-trans_paid">'.$trans_paid.'</div>
                        <div class="item-excerpt">Fits in a '.get_post_meta($post_id,'size',true).'  <p><a href="#"> ↓ See more details</a></p></div>
						
                    </div>
                </div>';
		}
        else
        {
            $price = get_post_meta($post_id,'payment_amount',true);
		
            $html .= '<div class="overview-info">
                    <div class="item">
                        <div class="item-image"></div>
                        <div class="item-title"></div>
                        <div class="item-locations">'.$locations.' '.$total_miles.'</div>
                    </div>
                    
                    <div class="item-delivery">
                        <h3>'.$task_header_msg.'</h3>
						<div class="item-price">£'.$price.'</div> 
                        <div class="item-excerpt">Fits in a '.get_post_meta($post_id,'size',true).'  <p><a href="#"> ↓ See more details</a></p></div> 
                    </div>
                </div>';
		}
    $html .= '</div>';

    echo $html;
}
?>


