<?php
$servername = "localhost";
$username = "root";
$password = "mac@123";
$dbname = "angluar_blog";
$conn = new mysqli($servername, $username, $password, $dbname);
/*$conn = new PDO("mysql:host=localhost;dbname=angluar_blog", $username, $password);

try {
   $conn = new PDO("mysql:host=localhost;dbname=angluar_blog", $username, $password);
   #set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    #echo "Connected successfully"; 
    }
catch(PDOException $e)
    {
    #echo "Connection failed: " . $e->getMessage();
    }*/

?>
