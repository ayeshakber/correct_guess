<?php
include("db_conn.php");
$data = json_decode(file_get_contents("php://input"));
$username = $data->username;
$password = sha1($data->password);

$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
//$sql = "SELECT * FROM users WHERE id =1";
$result = $conn->query($sql);
 //$data = array() ;
$row = $result->fetch_assoc();
 //$data = $row;

/*if ($result->num_rows > 0) {
    // output data of each row
     $data = array() ;
    while($row) {
        $data[] = $row;
    }
} else {
    echo "0 results";
}*/
echo json_encode($row);
$conn->close();
?>