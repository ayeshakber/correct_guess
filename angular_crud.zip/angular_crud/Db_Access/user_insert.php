<?php 
include("db_conn.php");
$data = json_decode(file_get_contents("php://input"));
$password = $data->password;
$password1 = sha1($password);

$sql = "INSERT INTO users (full_name,username, email, password, designation,area, contact_no) 
VALUES ('$data->full_name', '$data->username', '$data->email', '$password1', '$data->designation','$data->area', '$data->contact_no')";
$qry = $conn->query($sql);
echo json_encode($data);
$conn->close();

?>