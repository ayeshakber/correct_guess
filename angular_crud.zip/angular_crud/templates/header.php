<nav class="navbar navbar-default">
<div class="container-fluid" id="main-container">
	<div class="head-link">
   
    <div class="navbar-headr">
     
      <a class="navbar-brand" href="#/">Customer Services</a>
    </div>
    
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
      
        <li><a href="#/about_us">About Us</a></li>
        <li><a href="#/contact_us">Contact Us</a></li>
     
        <li class=""><a href="#/login">Login<span class="sr-only">(current)</span></a></li>
       <!--  <li><a href="">Logout</a></li> -->
        
        <!--  <li><a href="#/logout" ng-show="$scope.isUserLoggedIn"> Logout </label></li> -->
   		   <!-- <li><a href="#/login" ng-show="!$scope.isUserLoggedIn"> Login </label>  </li> -->

        <li> <a href="#/register">Registration</a></li>

      </ul>
      <form class="navbar-form navbar-left">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search...." ng-model="search">
        </div>
      </form>
    </div><!-- /.navbar-collapse -->
</div>	<!-- both in header -->
</div><!-- /.container-fluid -->
</nav>