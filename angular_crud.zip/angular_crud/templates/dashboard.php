<?php
	echo "<h4>Welcome to Dashboard</h4>";
?>
<div class="my-info" ng-init="showUser()">
	<div>
	  <h4>Information </h4>
	</div>
	<div class="panel-body">
		<table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp" style="margin-bottom:10px">
		  <thead>
		    <tr>
		      <th>Name</th>
		      <th>Username</th>
		      <th>Password</th>
		      <th>Email</th>
		      <th>Designation</th>
		      <th>Area</th>
		      <th>Contact no</th>
		      <th>Employee ID:</th>
		    </tr>
		  </thead>
		  <tbody>
		    <tr>
		      <td>{{user.full_name}}</td>
		      <td>{{user.username}}</td>
		      <td>{{user.password}}</td>
		      <td>{{user.email}}</td>
		      <td>{{user.designation}}</td>
		      <td>{{user.area}}</td>
		      <td>{{user.contact_no}}</td>
		      <td>{{user.id}}</td>
		    </tr>
		  </tbody>
		</table>
		<button><a href="" class="emp-close">Edit</a></button>
    </div>
</div>