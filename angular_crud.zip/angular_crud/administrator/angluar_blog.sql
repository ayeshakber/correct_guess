-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2017 at 02:44 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `angluar_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
`id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created_at`) VALUES
(1, 'post title1', 'this is a post title 1 details body text', '2012-12-09 16:01:36'),
(2, 'post title 2', 'this is a post title 2 details body text', '2012-12-09 16:01:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(8) NOT NULL,
  `full_name` varchar(125) DEFAULT NULL,
  `username` varchar(125) DEFAULT NULL,
  `email` varchar(125) DEFAULT NULL,
  `password` varchar(125) DEFAULT NULL,
  `designation` varchar(125) DEFAULT NULL,
  `area` varchar(255) DEFAULT NULL,
  `contact_no` int(16) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `username`, `email`, `password`, `designation`, `area`, `contact_no`, `created`, `updated`, `status`) VALUES
(1, 'Ayesha Admin', 'admin', 'ayesha@gmail.com', 'admin', 'Php Developer-Admin', 'Canada', 2147483647, '2017-03-01 12:09:30', '2017-03-01 12:09:30', NULL),
(5, 'Abc', 'abc', 'abc232@hotmail.com', '', 'Nothing', 'nipa', 34345345, '2017-03-06 07:37:43', '2017-03-06 07:37:43', NULL),
(10, 'ds desii', 'desi', 'waseemahmedtunio@gmail.com', '', 'ww', 'edse', 34234, '2017-03-06 10:30:40', '2017-03-06 10:30:40', NULL),
(12, 'Ad fab', 'ad', 'admin@hotmail.com', '', 'u r not admin', 'white space', 2147483647, '2017-03-06 10:36:02', '2017-03-06 10:36:02', NULL),
(13, 'Farhamn', 'far', 'far@gmail.com', '', 'dnfs', 'mdfo903480', 2147483647, '2017-03-06 11:56:43', '2017-03-06 11:56:43', NULL),
(14, 'nothingggggg', 'no', 'nooooooo@yahoo.com', '', 'sdnj', 'asd', 1461, '2017-03-06 11:56:52', '2017-03-06 11:56:52', NULL),
(16, 'amna khan', 'khan', 'amna@yahoo.com', '', 'MVC dev', '12', 1245, '2017-03-07 06:20:19', '2017-03-07 06:20:19', NULL),
(18, 'Memoni', 'mem', 'khan@yahoo.com', '', 'Free', 'area', 35262632, '2017-03-07 06:35:22', '2017-03-07 06:35:22', NULL),
(19, 'ali khan 12', 'ali_ali', 'ali@gmail.com', '', 'aliali', 'alialqq', 3423423, '2017-03-07 06:36:20', '2017-03-07 06:36:20', NULL),
(21, 'John khan123', 'johny', 'johny@hotmail.com', '', 'Bosssy', 'US', 0, '2017-03-07 12:53:35', '2017-03-07 12:53:35', NULL),
(22, 'aaaaaaaaaaadddddd', 'asa', 'zainai@gmail.com', '', 'sdasd', 'dsfasd', 3423423, '2017-03-07 13:16:45', '2017-03-07 13:16:45', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(8) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
