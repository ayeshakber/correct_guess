<?php 
$data = json_decode(file_get_contents("php://input"));
$servername = "localhost";
$username = "root";
$password = "mac@123";
$dbname = "angluar_blog";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$sql = "UPDATE users SET 
full_name ='$data->full_name', username ='$data->username', email ='$data->email', password ='$data->password',
designation ='$data->designation', area ='$data->area', 
contact_no ='$data->contact_no' WHERE id = $data->id ";

$qry = $conn->query($sql);
$conn->close();
?>
