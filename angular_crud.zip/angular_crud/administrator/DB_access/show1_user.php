<?php
$data = json_decode(file_get_contents("php://input"));
$servername = "localhost";
$username = "root";
$password = "mac@123";
$dbname = "angluar_blog";
$conn = new mysqli($servername, $username, $password, $dbname);

$sql = "SELECT * FROM users WHERE id = '$data->id'";
//$sql = "SELECT * FROM users WHERE id =1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
     $data = array() ;
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
} else {
    echo "0 results";
}
echo json_encode($data);
$conn->close();
?>