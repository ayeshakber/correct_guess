<?php
$data = json_decode(file_get_contents("php://input"));
$servername = "localhost";
$username = "root";
$password = "mac@123";
$dbname = "angluar_blog";
$conn = new mysqli($servername, $username, $password, $dbname);

$sql = "DELETE FROM users WHERE id = $data->id ";
$result = $conn->query($sql);
$conn->close();
?>