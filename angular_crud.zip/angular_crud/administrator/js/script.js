var myApp = angular.module("myApp_admin", ["ui.router"]);

myApp.config(function($stateProvider){
	$stateProvider
	.state("adminlogin",{
		url: "/",
		templateUrl: "admin_login.html",
		controller:"empController"
	})
	.state("employees",{
		url: "/employees",
		templateUrl: "templates/show_user.html",
		controller:"empController"
	})
	.state("empcreate",{
		url: "/employees/create",
		templateUrl: "templates/create_user.html",
		controller:"empController"
	})
	.state("empedit",{
		url: "/employees/:id/edit",
		templateUrl: "templates/update_user.html",
		controller:"empController"
	})
	.state("empshow",{
		url: "/employees/:id/show",
		templateUrl: "templates/show1_user.html",
		controller:"empController"
	});


	/*.when('/', {
		templateUrl:'admin_login.html',
		controller:'empController'
	})
	.when('/employees', {
		resolve:{
			"check": function($location,$rootScope){
				if (!$rootScope.loggedIn){
					$location.path('/');
				}
			}
		},
		templateUrl:'templates/show_user.html',
		controller:'empController'
	})
	.when('/employees/create', {
		resolve:{
			"check": function($location,$rootScope){
				if (!$rootScope.loggedIn){
					$location.path('/');
				}
			}
		},
		templateUrl:'templates/create_user.html',
		controller:'empController'
	})
	.when('/employees/:id/edit', {
		templateUrl:'templates/update_user.html',
		controller:'empController'
	})
	.when('/employees/:id/show', {
		templateUrl:'templates/show1_user.html',
		controller:'empController'
	})
	.otherwise({
		redirectTo: '/'
	});*/
	
});


