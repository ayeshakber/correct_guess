myApp.controller('serviceController', function($scope, $http, $state)
{	
	//site url 
	var url = window.location.origin
	//variables
	//Sign up user
	$scope.signUpInfo = {
		full_name: undefined,
		username: undefined,
		password: undefined,
		email: undefined,
		designation: undefined,
		area: undefined,
		contact_no: undefined
	}
	//Login user
	$scope.loginInfo = {
		username: undefined,
		password: undefined
	}

	//contact user
	$scope.contactInfo = {
		contact_name: undefined,
		contact_email: undefined,
		contact_subj: undefined,
		contact_msg: undefined,
		msg_success: '<h3>Your Message has been Send.</h3>'
	}

	//functions
	//Sign up user
	$scope.signUserUp = function(){
		var data = {
			full_name: $scope.signUpInfo.full_name,
			username: $scope.signUpInfo.username,
			password: $scope.signUpInfo.password,
			email: $scope.signUpInfo.email,
			designation: $scope.signUpInfo.designation,
			area: $scope.signUpInfo.area,
			contact_no: $scope.signUpInfo.contact_no,
		}
		$http.post("Db_Access/user_insert.php", data).success(function(response){
			console.log(response);
			//window.location.href = url+'/blog/angular_crud/#/dashboard/';
			localStorage.setItem("user",JSON.stringify({user: response}));
			$state.go("dashboard");
		}).error(function(error){
			console.log(error);
		});
	};

	//Login user
	$scope.loginUser = function(){
		var data = {
			username: $scope.loginInfo.username,
			password: $scope.loginInfo.password,
		}
		$http.post("Db_Access/user_login.php", data).success(function(response){
			console.log(response);
			localStorage.setItem("user",JSON.stringify({user: response.username}));
			$state.go("dashboard");
		}).error(function(error){
			console.log(error);
		});
	};
	//Contact user
	$scope.userContact = function(){
		var data = {
			contact_name: $scope.contactInfo.contact_name,
			contact_email: $scope.contactInfo.contact_email,
			contact_subj: $scope.contactInfo.contact_subj,
			contact_msg: $scope.contactInfo.contact_msg,
			msg_success: $scope.contactInfo.msg_success,
		}
		$http.post("Db_Access/contact_user.php", data).success(function(response){
			console.log(response);
			//$scope.contactInfo.push(msg_success);
			//jQuery('.response').html(response);
			$state.go("home");
		}).error(function(error){
			console.log(error);
		});
	};

	//register users
	/*$scope.addUser = function(info){
		$http.post('Db_Access/user_insert.php', info).then(function(response){
			window.location.href = url+'/blog/angular_crud/#/dashboard/';
		});
	};*/

	//User login 
	/*$scope.login = function(){
		var uname = $scope.username;
		var password = $scope.password;
		
		if ($scope.username == 'shyfa' && $scope.password == 'shyfa123') 
		{
			$rootScope.loggedIn = true;
			$location.path('/dashboard');
		}
		else
		{
			alert('Wrong Login Credential!');
			$location.path('/login');
		}
	};*/


	//login specific user 
	/*$scope.loginUser = function(){
		var id = $routeParams.id;
		var username = $routeParams.username;
		var password = $routeParams.password;
		$http.post('Db_Access/user_show.php',{'id':id,'username':username,'password':password}).then(function(response){
			var emp  = response.data;
			$scope.user = emp[0];
		});
	};*/

	//update employees
	/*$scope.updateEmployee = function(info){
		$http.post('Db_Access/update_user.php', info).then(function(response){

			window.location.href = url+'/blog/angular_crud/administrator/#/employees';
		});
	};*/
});
