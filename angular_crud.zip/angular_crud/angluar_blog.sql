-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2017 at 05:45 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `angluar_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE IF NOT EXISTS `admin_user` (
`id` int(8) NOT NULL,
  `username` varchar(125) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`id`, `username`, `password`, `created`, `updated`, `status`) VALUES
(1, 'admin', 'admin', '2017-03-13 08:33:13', '2017-03-13 08:33:13', 1),
(2, 'noname', 'noname', '2017-03-15 07:02:07', '2017-03-15 07:02:07', 0),
(3, 'noname', 'noname', '2017-03-15 07:02:26', '2017-03-15 07:02:26', 0),
(4, 'aaaaaaaaaaaaaaa', 'aaaaaaaaaaaaa', '2017-03-15 07:42:08', '2017-03-15 07:42:08', 0),
(5, 'asaaaa', 'aaa', '2017-03-15 07:45:30', '2017-03-15 07:45:30', 0),
(6, 'aishaa', 'aishaaaaaaa', '2017-03-15 07:46:21', '2017-03-15 07:46:21', 0),
(7, 'sasda', 'sas', '2017-03-15 08:31:36', '2017-03-15 08:31:36', 0),
(8, 'asassssss', 'aas', '2017-03-15 08:53:35', '2017-03-15 08:53:35', 0),
(9, 'sas', 'asda', '2017-03-15 11:28:23', '2017-03-15 11:28:23', 0),
(10, 'aaaaaaaaaaaaaaaaaaaaaaaaaaa', 'asawewewe', '2017-03-15 12:47:27', '2017-03-15 12:47:27', 0),
(11, 'abc', 'abc', '2017-03-16 04:55:49', '2017-03-16 04:55:49', 0);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
`id` int(8) NOT NULL,
  `contact_name` varchar(125) NOT NULL,
  `contact_email` varchar(125) NOT NULL,
  `contact_subj` varchar(125) NOT NULL,
  `contact_msg` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `contact_name`, `contact_email`, `contact_subj`, `contact_msg`, `created`, `updated`, `status`) VALUES
(1, '', '', '', '', '2017-03-16 06:46:44', '2017-03-16 06:46:44', 0),
(2, '', '', '', '', '2017-03-16 06:49:18', '2017-03-16 06:49:18', 0),
(3, 'asda', 'a@gmail.com', 'dfgd', 'dgdgg', '2017-03-16 06:53:49', '2017-03-16 06:53:49', 0),
(4, 'aasasd', 'aaaaaaaaaaaa@hotmail.com', 'helloo', 'this is my firast angular app', '2017-03-16 06:54:55', '2017-03-16 06:54:55', 0),
(5, 'sdfs', 'ayesha.aimviz@gmail.com', 'fgyhg', 'yhgyg', '2017-03-16 06:55:46', '2017-03-16 06:55:46', 0),
(6, 'asda', 'asas@gmail.com', 'hgh', 'yuty', '2017-03-17 06:12:00', '2017-03-17 06:12:00', 0),
(7, 'asa', 'a@yshoo.com', 'gh', 'gfhfgh', '2017-03-17 06:21:38', '2017-03-17 06:21:38', 0),
(8, 'vvvvvvvv', 'vvvvvvvvvvvvvvvv@gmail.com', 'vvvvvv', 'vvvvvvvvvvvvvvvvv', '2017-03-17 06:22:41', '2017-03-17 06:22:41', 0),
(9, 'bnbnbnb', 'bnbnb@yahoo.com', 'hhyhy', 'rfd dfgdfb', '2017-03-17 06:23:16', '2017-03-17 06:23:16', 0),
(10, 'asdas', 'lklk@gmail.com', 'hfh', 'fghfy', '2017-03-17 06:24:19', '2017-03-17 06:24:19', 0),
(11, 'aaaaayeshh Akber', 'ayesha.aimviz@gmail.com', 'AIMVIZ', 'This is my Message....', '2017-03-17 11:44:38', '2017-03-17 11:44:38', 0),
(12, 'aaaaayeshh Akber', 'ayesha.aimviz@gmail.com', 'AIMVIZ', 'This is my Message....', '2017-03-17 11:44:48', '2017-03-17 11:44:48', 0),
(13, 'asdasd', 'ayesha.aimviz@gmail.com', 'dkfs', 'emfol olsmopc f erfer5f46 sf fdf', '2017-03-17 13:00:36', '2017-03-17 13:00:36', 0),
(14, 'asdasd', 'ayesha.aimviz@gmail.com', 'dkfs', 'emfol olsmopc f erfer5f46 sf fdf', '2017-03-17 13:00:52', '2017-03-17 13:00:52', 0),
(15, 'asdasd', 'ayesha.aimviz@gmail.com', 'dkfs', 'emfol olsmopc f erfer5f46 sf fdf', '2017-03-17 13:00:53', '2017-03-17 13:00:53', 0),
(16, 'asdasd', 'ayesha.aimviz@gmail.com', 'dkfs', 'emfol olsmopc f erfer5f46 sf fdf', '2017-03-17 13:00:53', '2017-03-17 13:00:53', 0),
(17, 'asdasd', 'ayesha.aimviz@gmail.com', 'dkfs', 'emfol olsmopc f erfer5f46 sf fdf', '2017-03-17 13:00:54', '2017-03-17 13:00:54', 0),
(18, 'ftfg', 'ayesha.aimviz@gmail.com', 'sdmnsfk', 'kmdfkosdf', '2017-03-17 13:04:39', '2017-03-17 13:04:39', 0),
(19, 'ftfg', 'ayesha.aimviz@gmail.com', 'sdmnsfk', 'kmdfkosdf', '2017-03-17 13:05:12', '2017-03-17 13:05:12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
`id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created_at`) VALUES
(1, 'post title1', 'this is a post title 1 details body text', '2012-12-09 16:01:36'),
(2, 'post title 2', 'this is a post title 2 details body text', '2012-12-09 16:01:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(8) NOT NULL,
  `full_name` varchar(125) DEFAULT NULL,
  `username` varchar(125) DEFAULT NULL,
  `email` varchar(125) DEFAULT NULL,
  `password` varchar(125) DEFAULT NULL,
  `designation` varchar(125) DEFAULT NULL,
  `area` varchar(255) DEFAULT NULL,
  `contact_no` int(16) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `username`, `email`, `password`, `designation`, `area`, `contact_no`, `created`, `updated`, `status`) VALUES
(1, 'Ayesha Admin', 'admin', 'ayesha@gmail.com', 'admin', 'Php Developer-Admin', 'Canada', 2147483647, '2017-03-01 12:09:30', '2017-03-01 12:09:30', NULL),
(5, 'Abc', 'abc', 'abc232@hotmail.com', '', 'Nothing', 'nipa', 34345345, '2017-03-06 07:37:43', '2017-03-06 07:37:43', NULL),
(10, 'ds desii', 'desi', 'waseemahmedtunio@gmail.com', '', 'ww', 'edse', 34234, '2017-03-06 10:30:40', '2017-03-06 10:30:40', NULL),
(13, 'Farhamn', 'far', 'far@gmail.com', '', 'dnfs', 'mdfo903480', 2147483647, '2017-03-06 11:56:43', '2017-03-06 11:56:43', NULL),
(16, 'amna khan', 'khan', 'amna@yahoo.com', '', 'MVC dev', '12', 1245, '2017-03-07 06:20:19', '2017-03-07 06:20:19', NULL),
(18, 'Memoni', 'mem', 'khan@yahoo.com', '', 'Free', 'area', 35262632, '2017-03-07 06:35:22', '2017-03-07 06:35:22', NULL),
(19, 'ali khan 12', 'ali_ali', 'ali@gmail.com', '', 'aliali', 'alialqq', 3423423, '2017-03-07 06:36:20', '2017-03-07 06:36:20', NULL),
(21, 'John khan123', 'johny', 'johny@hotmail.com', '', 'Bosssy', 'US', 0, '2017-03-07 12:53:35', '2017-03-07 12:53:35', NULL),
(23, 'Madiha n', 'madhoooo', 'madiha.aimviz@gmail.com', '', 'Designer', 'UBL', 232323434, '2017-03-08 05:19:52', '2017-03-08 05:19:52', NULL),
(24, 'Shyfa', 'shyfa', 'shyfa@gmail.com', 'shyfa123', 'Client', 'gter', 2334, '2017-03-08 09:01:34', '2017-03-08 09:01:34', NULL),
(25, 'asdas', 'hnsdf', 'afnj@gmail.com', 'dhnfske', 'erdrt', 'rtr', 554645, '2017-03-08 09:02:39', '2017-03-08 09:02:39', NULL),
(26, 'Maaaaaz', 'mazudin', 'maz@gmail.com', 'maaz', 'no', 'no', 46856, '2017-03-08 13:07:19', '2017-03-08 13:07:19', NULL),
(27, 'Sameen', 'sameen', 'sameen@yahoo.com', 'sameen', 'SQA', 'North', 54645, '2017-03-09 05:30:15', '2017-03-09 05:30:15', NULL),
(28, '', '', '', '', '', '', 0, '2017-03-15 06:38:55', '2017-03-15 06:38:55', NULL),
(29, '', '', '', '', '', '', 0, '2017-03-15 06:40:29', '2017-03-15 06:40:29', NULL),
(30, '', '', '', '', '', '', 0, '2017-03-15 06:41:10', '2017-03-15 06:41:10', NULL),
(31, '', '', '', '', '', '', 0, '2017-03-15 06:48:00', '2017-03-15 06:48:00', NULL),
(32, 'aaa', 'asas', 'asda@gmail.com', 'asdas', 'asdasd', 'asdas', 34234234, '2017-03-15 08:14:45', '2017-03-15 08:14:45', NULL),
(33, 'Atif Aslam', 'atif', 'atif@gmail.com', 'atif', 'Singer', 'Dubai', 20202, '2017-03-15 08:23:59', '2017-03-15 08:23:59', NULL),
(34, 'madi', 'madi', 'madi@hotmail.com', 'madi', 'madi', 'madi', 446564, '2017-03-15 08:28:17', '2017-03-15 08:28:17', NULL),
(35, 'df', 'sdfsdf', 'aaas@gmail.com', 'sdf', 'dsdf', 'asdas', 343434, '2017-03-15 08:33:24', '2017-03-15 08:33:24', NULL),
(36, 'faryhan', 'harhan', 'af@gmail.com', 'faran', 'dfskd', 'kemdf', 64596, '2017-03-15 08:50:17', '2017-03-15 08:50:17', NULL),
(37, 'asda', 'asdasd', 'asdas@yahoo.com', 'asdasda', 'thdftgyh', 'trt', 456456747, '2017-03-15 11:28:45', '2017-03-15 11:28:45', NULL),
(38, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaa@gmail.com', 'aaaaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaa1', 2147483647, '2017-03-15 12:56:42', '2017-03-15 12:56:42', NULL),
(39, 'maaazi', 'mazia', 'mazia@yahoo.com', 'mazia', 'php', 'php', 16545, '2017-03-16 07:00:57', '2017-03-16 07:00:57', NULL),
(40, 'maamak', 'mdaksd', 'mksdj@gmail.com', 'masdkmskdma', 'asnk', 'msldm', 4552, '2017-03-16 07:02:58', '2017-03-16 07:02:58', NULL),
(41, 'czczczc', 'czczczc', 'czczc@yahoo.com', 'zczczc', 'dhksdf', 'sdfsk', 4545, '2017-03-16 07:05:00', '2017-03-16 07:05:00', NULL),
(42, 'xxxxx', 'xxxxxxxxxxx', 'xxx@yahoo.com', 'sha1(xasasdasdasds)', 'bsj', 'hd', 546456, '2017-03-17 10:41:10', '2017-03-17 10:41:10', NULL),
(43, 'rwewe', 'wew', '33njknj@yahoo.com', '00921af0bebfe492bbcc7e7b38115b06217fe849', 'kfso', 'qkoqwopdp', 496465, '2017-03-17 10:47:38', '2017-03-17 10:47:38', NULL),
(44, 'test', 'test', 'test@gmail.com', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 'msdlk', 'msdof', 45645, '2017-03-17 10:48:34', '2017-03-17 10:48:34', NULL),
(45, 'amnaa', 'amna', 'amna@gmail.com', '18e286c464deb5d706e606f566725e784c9a00e7', 'amna', 'amna', 454865, '2017-03-18 05:40:58', '2017-03-18 05:40:58', NULL),
(46, 'sas', 'sad', 'sad@hotmail.com', 'b4914600112ba18af7798b6c1a1363728ae1d96f', 'sas', 'sas', 212, '2017-03-18 05:44:01', '2017-03-18 05:44:01', NULL),
(47, 'asa', 'sasa', 'asa@gmail.com', '65417b70a1a7bd08a6189f4d309d90979cbe7b56', 'sasdas', 'asa', 323, '2017-03-18 06:50:16', '2017-03-18 06:50:16', NULL),
(48, 'sas', 'sasas', 'aashvh@gmail.com', '65417b70a1a7bd08a6189f4d309d90979cbe7b56', 'nkasdn', 'dk', 46465, '2017-03-18 06:52:19', '2017-03-18 06:52:19', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_user`
--
ALTER TABLE `admin_user`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_user`
--
ALTER TABLE `admin_user`
MODIFY `id` int(8) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
MODIFY `id` int(8) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(8) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
