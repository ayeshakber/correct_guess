		
	<?php 
		include('header.php');
	?>
	<div class="content">
		<h1>this is home page</h1>
		
	</div>
	<?php 
		include('footer.php');
	?>
