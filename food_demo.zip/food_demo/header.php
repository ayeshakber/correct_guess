<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>My Fast Food Factory </title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="js/script.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="main-body">
  <header>
    <div class="header-inc"> 
        <nav class="navbar navbar-default">
        <div class="container-fluid" id="main-container">
        	<div class="head-link">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-headr">
              <img src="images/logo4.jpg" alt="">
              <a class="navbar-brand" href="#/">Fast Foods Factory</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav navbar-right">
              
              <form class="navbar-form navbar-left">
                <div class="form-group">
                  <input type="text" class="form-control" placeholder="Search...." ng-model="search">
                </div>
              </form>
                <li><a href="about_us.php">About Us</a></li>
                <li><a href="contact_us.php">Contact Us</a></li>
                <li class=""><a href="login.php">Login</a></li>

                <li> <a href="register.php">Registration</a></li>

              </ul>
            </div><!-- /.navbar-collapse -->
        </div>	<!-- both in header -->
        </div><!-- /.container-fluid -->
        </nav>
     </div>
   </header>  