<?php
/**
 * Created by Sublime3.
 * User: Ayesha
 * Date: 20/03/2017
 * Time: 11:46 AM
 */
class Registration_class
{
    function __construct()
    {
    	  ##TEMP INCLUDES##
        add_filter('template_include', array($this, 'sign_up'));
        add_filter('template_include', array($this, 'sign_in'));
        add_filter('template_include', array($this, 'my_profile'));
        add_filter('template_include', array($this, 'progress_report'));
        add_filter('template_include', array($this, 'report_email'));
        ## REGISTER FORM SUBMISSION##
        add_action('wp_head', array($this, 'e_submit_javascript'));
        add_action('wp_ajax_e_submit', array($this, 'e_submit_callback'));
        add_action('wp_ajax_nopriv_e_submit', array($this, 'e_submit_callback'));
        ## LOGIN FORM SUBMISSION##
        add_action('wp_head', array($this, 'e_login_javascript'));
        add_action('wp_ajax_e_login', array($this, 'e_login_callback'));
        add_action('wp_ajax_nopriv_e_login', array($this, 'e_login_callback'));

        ## UPDATE PROFILE FORM SUBMISSION##
        add_action('wp_head', array($this, 'update_profile_javascript'));
        add_action('wp_ajax_update_profile', array($this, 'update_profile_callback'));
        add_action('wp_ajax_nopriv_update_profile', array($this, 'update_profile_callback'));
        add_action('wp_head',array($this, 'paid_user_login'));
        /** Step 2. */
         add_action('admin_menu',array($this, 'my_ocampo_menu'));
         //add_action( 'admin_menu', 'my_ocampo_menu' );

       //add_action('wp_head',array($this, 'user_course_validation'));
        /*waseem work start*/
        //admin menu
        /*waseem work end*/
    }
    /*function user_course_validation()
    {
      $post_id = get_the_ID();
      $user_id = get_current_user_id();
      $user_type = get_user_meta($user_id,'user_type',true);  //premium
      $user_status = get_user_meta($user_id,'user_status',true);  //paid
      //course_370_access_from
      $course_access_meta = 'course_'.$post_id.'_access_from';
      $course_access_value = rand(1,10000000000);
      ?>
      <script>
      jQuery(document).ready(function ()
      {
        var p_id = '<?php echo $post_id; ?>';
         //var div = 'learndash_post_'+p_id;
         //var cond = jQuery(div+'form').attr('name');
          jQuery('.learndash_paypal_button #btn-join').on('click',function(e)
          {
            e.preventDefault();
            alert('course working....');
            <?php
            if($user_type=='premium' && $user_status=='paid')
            {
              $course_taken = update_user_meta($user_id,$course_access_meta,$course_access_value);
              $url = $_SERVER['REQUEST_URI'];
              echo $_SERVER['REQUEST_URI'];
              wp_redirect( $url );
              exit;
            }
            ?>
          });
      });

      </script>
      <?php
    }*/

      /** Step 1. */
    function my_ocampo_menu() 
    {
      add_menu_page( 'Ocampo Options', 'Ocampo Menu', 'read', 'ocampo-option', 'my_ocampo_options');

      add_submenu_page ('ocampo-option', 'Ocampo SubMenu', 'Ocampo SubMenu',  'read','ocampo-submenu-options', 'function_name_of_submenu' );

      /*add_submenu_page ('order-flow-option', 'Dynamic Dropdown', 'Dynamic Dropdown',  'read','order-flow-dropdown', 'dynamic_dropdown' );*/
    }
    /** Step 3. */
    #region
    function my_ocampo_options()
    {
      $html = '<pthis is admin menu></p>';
      echo $html;
    }


    function paid_user_login()
    {
      if (isset($_GET['status']) && isset($_GET['user_id']) && $_GET['status']=='success')
      {
          $user_id = $_GET['user_id'];
          $user_info = get_userdata( $user_id );
          if(!session_id())
          {
            session_start();
           #echo $_SESSION["password"];
            $user_name = $user_info->user_login;
            $user_pass = $user_info->user_pass;
            $creds = array();
            $creds['user_login'] = $user_name;
            $creds['user_password'] = $_SESSION["password"];
            $creds['remember'] = true;
            $user = wp_signon( $creds, false );
            if(is_wp_error($user))
            {
              echo $user->get_error_message();
            }
            else
            {
                $user_status = update_user_meta($user_id, 'user_status', 'paid');
                $profile = site_url().'/my-profile/';
                wp_redirect( $profile );
                exit;
            }
          }
      }
    } //func end

    ##SIGN UP
    function sign_up($template)
    {
        if (is_page('my-registration')) {
            $user_template = dirname(__FILE__) . "/templates/sign_up.php";
            return $user_template;
        }
        return $template;
    }
    ##LOGIN
    function sign_in($template)
    {
        if (is_page('my-login')) {
            $user_template = dirname(__FILE__) . "/templates/login.php";
            return $user_template;
        }
        return $template;
    }
    ##PROFILE
    function my_profile($template)
    {
        if (is_page('my-profile')) {
            $user_template = dirname(__FILE__) . "/templates/profile.php";
            return $user_template;
        }
        return $template;
    }
    ##PROGRESS REPORT
    function progress_report($template)
    {
        if (is_page('progress-report')) {
            $user_template = dirname(__FILE__) . "/templates/report.php";
            return $user_template;
        }
        return $template;
    }

    function report_email($template)
    {
        if (is_page('report-email')) {
            $user_template = dirname(__FILE__) . "/templates/report_email.php";
            return $user_template;
        }
        return $template;
    }

    function update_profile_javascript()
    {
      ?>
        <script type="text/javascript">
            /* Make this document ready function to work on click where you want */
            jQuery(document).ready(function ()
            {
              jQuery('.create_loader2').hide();
              var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
              jQuery('#edit_info').on('click', function (e)
              {
                  //alert("Updating");
                  /*You can get this value from some hidden field or div*/
                  jQuery('.create_loader2').show();
                  e.preventDefault();
                  var url = '<?php echo site_url(); ?>';
                  url = url+'/my-profile/';
                  var edit_name = jQuery('#edit_name').val();
                  var edit_qualification = jQuery('#edit_qualification').val();
                  var edit_institute = jQuery('#edit_institute').val();
                  var edit_dob = jQuery('#edit_dob').val();
                  var edit_phone = jQuery('#edit_phone').val();
                  var edit_address = jQuery('#edit_address').val();
                  //var current_password = jQuery('#current_password').val();
                  //var new_password = jQuery('#new_password').val();
                  var data = {
                      'action': 'update_profile',
                      'edit_name': edit_name,
                      'edit_qualification': edit_qualification,
                      'edit_institute': edit_institute,
                      'edit_dob': edit_dob,
                      'edit_phone': edit_phone,
                      'edit_address': edit_address,
                      //'current_password': current_password,
                      //'new_password': new_password,
                  };
                  $.post(ajaxurl, data, function (response)
                  {
                      //alert(response);
                      jQuery('.create_loader2').hide(); //check stripe api
                      jQuery('.update_response').show();
                      jQuery('.update_response').html(response);
                      var classname = jQuery('.update_response span').attr('class');
                      console.log(classname);
                      if(classname == "scs_msg")
                      {
                       setTimeout(function()
                        {
                          window.location.href = url;
                        }, 2000);
                      }
                  }); //ajax end
              });	//on click end
            }); //jquery end
          </script>
      <?php
    }
    function update_profile_callback()
    {
      $user_id = get_current_user_id();
      $new_ful_name = $_POST['edit_name'];
      $edit_qualification = $_POST['edit_qualification'];
      $edit_institute = $_POST['edit_institute'];
      $edit_dob = $_POST['edit_dob'];
      $edit_phone = $_POST['edit_phone'];
      $edit_address =$_POST['edit_address'];
      //$current_password =$_POST['current_password'];
      //$new_password =$_POST['new_password'];
      //echo $new_ful_name;
      //die();
      $update_user_info = array(
        'ID' => $user_id,
        'display_name' => $new_ful_name,
      //'user_pass' => $new_password
      );
      $update_user = wp_update_user($update_user_info);
      $msg = '';
      if ( is_wp_error( $update_user ) )
      {
          #error
      	  $msg = '<span class="err_msg">Error</span>';
      }
      else
      {
      	#Success!
        $new_qualification = update_user_meta($user_id, 'qualification', $edit_qualification);
        $new_institute = update_user_meta($user_id, 'institute', $edit_institute);
        $new_dob = update_user_meta($user_id, 'dob', $edit_dob);
        $new_phone = update_user_meta($user_id, 'phone', $edit_phone);
        $new_address = update_user_meta($user_id, 'address', $edit_address);
        $msg = '<span class="scs_msg" style="color:green;">Profile Update Successfully!</span>';
      }
        // $my_post = array(
        // 'post_title'    => 'My post',
        // 'post_content'  => 'This is my learning post.',
        // 'post_status'   => 'publish',
        // 'post_type'   => 'testimonials',
        // 'post_author'   => $user_id,
        // );
        // $post_id = wp_insert_post($my_post);
      echo $msg;
      die();
    } #profile calback end

    function e_login_javascript()
    {
      ?>
        <script type="text/javascript">
            /*Make this document ready function to work on click where you want*/
            jQuery(document).ready(function ()
            {
                jQuery('.create_loader1').hide();
                var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
                jQuery('#e_login').on('click', function (e)
                {
                    //alert("login working");
                    /* You can get this value from some hidden field or div */
                    jQuery('.create_loader1').show();
                    e.preventDefault();
                    var url = '<?php echo site_url(); ?>';
                    url = url+'/my-profile/';
                    var user_status = '<?php echo $_GET['status']; ?>';
                    var paid_user_id = '<?php echo $_GET['user_id']; ?>';
                    //console.log(url);
    		            //var email=jQuery('#login_email').val();
    		            var user_name = jQuery('#login_user').val();
    		            var user_pwd = jQuery('#login_pwd').val();
                    var data = {
                        'action': 'e_login',
                        'user_name': user_name,
                        'user_pwd': user_pwd,
                        'user_status': user_status,
                        'paid_user_id': paid_user_id,
                    };
                    $.post(ajaxurl, data, function (response)
                    {
                    	 //alert(response);
                       console.log(url);
                        jQuery('.create_loader1').hide(); //check stripe api
                        jQuery('.login_response').show();
                        jQuery('.login_response').html(response);
                         var classname = jQuery('.login_response span').attr('class');
                         console.log(classname);
                         if(classname == "success")
                         {
                           setTimeout(function()
                           {
                             window.location.href = url;
                           }, 1000);
                         }
                    });
                });	//e sub end
            });
        </script>
      <?php
    }
    function e_login_callback()
    {
  		 $user_name = $_POST['user_name'];
  		 $user_pwd = $_POST['user_pwd'];
      //  $status = $_GET['status'];
      //  $u_id = $_GET['user_id'];
      //  if ($status=='success')
      //  {
      //    $user_status = update_user_meta($u_id, 'user_status', 'paid');
      //  }
       #login array
       $creds = array();
       $creds['user_login']=$user_name;
       $creds['user_password']=$user_pwd;
       $creds['remember_me'] = 'true';
       #user sign on func
       $user = wp_signon($creds ,false);
       $user_msg = '';
       ///my-login/?status=success&user_id=22
       if (is_wp_error($user))
       {
           #$user_msg = $user->get_error_message();
           $user_msg = '<span class="error">'.$user->get_error_message().'</span>';
           echo $user_msg ;
           die();
       }
       else
       {
          #$user_msg = site_url();
          $user_msg = '<span class="success"></span>';
         echo $user_msg ;
         die();
       }
    } #login callback func

    function e_submit_javascript()
    {
    	?>
        <script type="text/javascript">
            /* Make this document ready function to work on click where you want */
            jQuery(document).ready(function ()
            {
            	jQuery('.create_loader').hide();
            	/* In front end of WordPress we have to define ajaxurl */
                var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
                function IsEmail(email) {
                    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                    return regex.test(email);
                }
                jQuery('#phone').keydown(function(e) {
                  if (e.shiftKey || e.ctrlKey || e.altKey) {
                  e.preventDefault();
                    jQuery('.response').hide();
                  } else {
                  var key = e.keyCode;
                  if (!((key == 8) || (key == 46) || (key >= 35 && key <= 40) || (key >= 48 && key <= 57) || (key >= 96 && key <= 105))) 
                  {
                  e.preventDefault();
                     jQuery('.response').show();
                     jQuery('.response').html('Please enter numeric value!');
                  }
                  }
                });
                jQuery('#e_sub').on('click', function (e)
                {
                    /* You can get this value from some hidden field or div */
                    
                    e.preventDefault();
                   
                    var url = '<?php echo site_url(); ?>';
                    url = url+'/my-login/';
                    var full_name = jQuery('#full_name').val();
    		            var email = jQuery('#email').val();
    		            var username = jQuery('#username').val();
    		            var pwd = jQuery('#pwd').val();
    		            var qualification = jQuery('#qualification').val();
    		            var institute = jQuery('#institute').val();
    		            var dob = jQuery('#dob').val();
    		            var phone = jQuery('#phone').val();
    		            var address = jQuery('#address').val();
                    var user_type = jQuery('#user_type').val();
                    var user_package = document.getElementById("user_package").value;
                    
    
                    if(full_name=="" || email=="" || username=="" || pwd=="" || qualification=="" || institute=="" || dob=="" || phone=="" || address==""){
                         jQuery('.response').show();
                        jQuery('.response').html('Please Fill all the fields');
                    }
                    else if (IsEmail(jQuery('#email').val())==false) {
                      jQuery('.response').show();
                        jQuery('.response').html('Please enter valid email address..');
                    }
                    else if(user_type=="premium" && user_package=="choose"){
                        jQuery('.response').show();
                        jQuery('.response').html('Please any other package');
                    }
                    else if(jQuery("#pwd").val().length<'8'){
                      jQuery('.response').show();
                      jQuery('.response').html('Password should be greater then 8 character or number...');
                    }
                    else{
                      //alert("wrks");
                        var data = {
                          'action': 'e_submit',
                          'full_name': full_name,
                          'email': email,
                          'username': username,
                          'pwd': pwd,
                          'qualification': qualification,
                          'institute': institute,
                          'dob': dob,
                          'phone': phone,
                          'address': address,
                          'user_type' : user_type,
                          'user_package' : user_package,
                      };
                      jQuery('.create_loader').show();
                      $.post(ajaxurl, data, function (response)
                      {
                          jQuery('.create_loader').hide(); //check stripe api
                          jQuery('.response').show();
                          jQuery('.response').html(response);
                          var callback = jQuery('.response h4').attr('class');
                          console.log(user_package);
                          if (callback == 'user_done')
                          {
                            setTimeout(function()
                            {
                               window.location.href = url;
                            },3000);
                          }
                      });
                    }
                });	//e sub end
            });	//end jQuery
        </script>
        <?php
    }
    function e_submit_callback()
    {
      $full_name = $_POST["full_name"];
  		$email = $_POST['email'];
  		$username = $_POST['username'];
  		$pwd = $_POST['pwd'];
  		$qualification = $_POST['qualification'];
  		$institute = $_POST['institute'];
  		$dob = $_POST['dob'];
  		$phone = $_POST['phone'];
  		$address = $_POST['address'];
      $user_type = $_POST['user_type'];
      $user_packager = $_POST['user_package'];
      //die();
  		 $hash1 =md5(rand(100, 500));
  		 #check username & email Already exist
		   $args = array(
                'role' => '',
                'fields' => 'all',
            );
        $all_user = get_users($args);
        $all_user_email = '';
        $all_user_name = '';
        foreach ($all_user as $value)
        {
            $all_user_email[] = $value->user_email;
            $all_user_name[] = $value->user_login;
        }
          ##FOR UNIQUE USERNAME
        	$user_created='';
  		    if (in_array($email, $all_user_email))
  			  {
  				  $user_created = '<h4 class="user_err">Email Address Already Exist.</h4>';
  				  echo $user_created;
  				die();
  			  }
  			  if (in_array($username, $all_user_name))
  			  {
  				  $user_created = '<h4 class="user_err">Username is Already Exist.</h4>';
  				  echo $user_created;
  				  die();
  			  }
			    $e_learning_user = array(
              'user_login' => $username,
              'user_email' => $email,
              'user_pass' => $pwd,
              'display_name' => $full_name,
              'role' => 'subscriber',
          );
			      #USER INSERT FUNCTION
            $user_id = wp_insert_user($e_learning_user);
             #CHECK ERROR
            if (!is_wp_error($user_id))
            {
            	 #UPDATE USER INFORMATION
                $qualification = update_user_meta($user_id, 'qualification', $qualification);
                $institute = update_user_meta($user_id, 'institute', $institute);
                $dob = update_user_meta($user_id, 'dob', $dob);
                $phone = update_user_meta($user_id, 'phone', $phone);
                $address = update_user_meta($user_id, 'address', $address);

                if($user_type=="premium")
                {
                  $user_types = update_user_meta($user_id, 'user_type', $user_type);
                  $user_package = update_user_meta($user_id, 'subscription_type', $user_packager);
                  $user_status = update_user_meta($user_id, 'user_status', "pending");
                  $args = array(
                      'post_type' => 'package'
                      );
                  $query = new WP_Query( $args );
                  if($query->have_posts())
                  {
                      while ( $query->have_posts() )
                      {
                        $query->the_post();

                        $post_ids = $query->posts[0]->ID;
                        //Monthly
                       $amount = get_post_meta($post_ids,$user_packager,true);


                        if(!empty($amount))
                        {
                          if(!session_id()) {
                            session_start();
                            $_SESSION["password"] = $pwd;
                          }

                          ?>
                        	<form action='https://www.sandbox.paypal.com/cgi-bin/webscr' method='post' style='display: none'>
              							<input type='hidden' name='cmd' value='_xclick'>
              							<input type='hidden' name='return' value='<?php echo site_url(); ?>/my-login/?status=success&user_id=<?php echo $user_id ; ?>'>
              							<input type='hidden' name='cancel_return' value='<?php echo site_url(); ?>/?status=cancel&user_id=<?php echo $user_id ; ?>'>
              							<input type='hidden' name='notify_url' value='<?php echo site_url(); ?>/my-login/?status=success&user_id=<?php echo $user_id ; ?>'>
              							<input type='text' name='amount' id='amount_payment' placeholder='amount' value='<?php echo $amount ; ?>'>
              							<input type='hidden' name='business' id='business' placeholder='Business' value='maazuddin.aimviz-facilitator@gmail.com'>
              							<input type='hidden' name='item_name' id='item_name' placeholder='Item Name' value='abc'>
              							<input type='hidden' name='on0' id='itemID' placeholder='Item Name' value='postID'>
              							<input type='hidden' name='os0' id='item_ID' placeholder='Item ID' value='12'>
              							<input type='hidden' name='quantity' id='quantity' placeholder='quantity' value='1'>
              							<input type='hidden' name='currency_code' value='USD'>
              							<!-- Saved buttons display an appropriate button image. -->
              							<input type='submit' id='payment' value='Pay with PayPal!'>
              							<input type='image' name='submit'
              							src='https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif'
              							alt='PayPal - The safer, easier way to pay online'>
              							<img alt='' width='1' height='1'
              							src='https://www.paypalobjects.com/en_US/i/scr/pixel.gif' >
            							</form>
            							<script>
            								jQuery(document).ready(function()
                            {
            									jQuery("#payment").trigger("click");
            								});
            							</script>
                        	<?php
                        }
                        else
                        {
                          echo "Sorry";
                        }
                      }
                    wp_reset_postdata();
                  }
                  $user_created = '<h4 class="user_dones" style="color:green;">Registration Successfully! Please Check your Email.</h4>';
                }
                else
                {
                  $user_types = update_user_meta($user_id, 'user_type', $user_type);
                  $user_created = '<h4 class="user_done" style="color:green;">Registration Successfully! Please Check your Email.</h4>';
                }

	              ##### WELCOME EMAIL #######
    	          $to = $email;
        				$subject = "Welcome to E-Learning";
        				$message = "
        				<html>
          				<head>
          				<title>HTML email</title>
          				</head>
        				<body>
        				    <h1>Welcome to E-Learning :)</h1>
        	           <p>The delivery of a learning, training or education program by electronic means. E-learning involves the use of a computer or electronic device (e.g. a mobile phone) in some way to provide training, educational or learning material </p><br>
        	          <h4>What are the benefits?</h4>
        	          <p>There are several benefits to e-learning whether you choose to use it on its own, or to enhance your existing in house training. We have listed a few below, but for more information on how your business can save time and money, you can call today and speak to one of our Ilkley based support team</p>
        	          <p>Visit our Website: ".site_url()."
        				</body>
        				</html>";
        				#Always set content-type when sending HTML email
        				$headers = "MIME-Version: 1.0" . "\r\n";
        				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        				#More headers
        				$headers .= 'From: <webmaster@example.com>' . "\r\n";
        				$headers .= 'Cc: ayesha.aimviz@gmail.com' . "\r\n";
        				mail($to,$subject,$message,$headers);
    	          ##### WELCOME EMAIL #######
              echo $user_created ;
              die();
			}	#if not error
    }#func end
}
?>
