<?php get_header(); ?>
<section id="content" role="main">
	<?php
	if(!is_user_logged_in())
  {
	?>
	<div class="login_div">
		<h1 class="entry-title">Login</h1>
		<form action="" method="POST" enctype="multipart/form-data" name="e_learn_login" id="e_learn_login">
		 <div class="form-group">
			 <label for="login_user">UserName:</label>
			 <input type="text" class="form-control" id="login_user" placeholder="Enter Username">
		 </div>
		 <div class="form-group">
			 <label for="login_pwd">Password:</label>
			 <input type="password" class="form-control" id="login_pwd" placeholder="Enter Password">
		 </div>
		 <input type="submit" name="submit" class="btn btn-default" value="Login" id="e_login">
		 <div class="login_response" style="display:none; color: red;"></div>
		 <div class="create_loader1" style="display:none;">
			 <img src="<?php echo PLUGIN_HTTP_URL.'images/ajax-loader.gif' ?>">
		 </div>
 	</form>
	</div>
	<?php
	}
	else {
		//echo "<h4>You are Logged in. Go to <a href=".site_url()."> Home page</a></h4>";
		?>
			<script>
			  window.location.href="/my-profile/";
			</script>
		<?php
	}
	?>
</section>

<?php get_footer(); ?>
