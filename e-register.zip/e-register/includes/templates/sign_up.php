<?php get_header(); ?>
<section id="content" role="main">
	<?php
	$user_id = get_current_user_id();
	if($user_id!="0")
	  {
	  	?>
			<script>
			  window.location.href="/my-profile/";
			</script>
		<?php
	  }
	?>
	<div class="sign_up_div">
		<h1 class="entry-title">Registration</h1>
		<form action="" method="POST" enctype="multipart/form-data" name="e_learn_form" id="e_learn_form">
			<div class="form-group">
				<label for="user_type">User Type:</label>
				<select name="user_type" id="user_type">
					<option value="free">Free</option>
					<option value="premium">Premium</option>
				</select>
			</div>
			<div class="form-group">
				<label for="User_Package">Package Type:</label>
				<select name="User_Package" id="user_package">
					<option value="choose">Choose</option>
         			<option value="Weekly">Weekly</option>
         			<option value="Monthly">Monthly</option>
         			<option value="Yearly">Yearly</option>
				</select>
			</div>
			<div class="form-group">
		      <label for="full_name">Full Name:</label>
		      <input type="full_name" class="form-control" id="full_name" placeholder="Enter Full Name" name="full_name">
		    </div>

		    <div class="form-group">
		      <label for="email">Email:</label>
		      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
		     <!--  <div class="exist_email" style="display:none;"></div> -->
		    </div>

		    <div class="form-group">
		      <label for="username">Username:</label>
		      <input type="text" class="form-control" id="username" placeholder="Enter Your Username" name="username">
		      <!-- <div class="exist_username" style="display:none;"></div> -->
		    </div>

		    <div class="form-group">
		      <label for="pwd">Password:</label>
		      <input type="password" class="form-control" id="pwd" placeholder="Enter Password" name="pwd" pattern=".{6,}" title="Six or more characters">
		    </div>

		    <div class="form-group">
		      <label for="qualification">Qualificatuion:</label>
		      <input type="text" class="form-control" id="qualification" placeholder="Enter Qualification" name="qualification">
		    </div>

		    <div class="form-group">
		      <label for="institute">Institute:</label>
		      <input type="text" class="form-control" id="institute" placeholder="Enter Your Intitute Name" name="institute">
		    </div>

		    <div class="form-group">
		      <label for="dob">Date of Birth:</label>
		      <input type="date" class="form-control" id="dob" name="dob" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])/(0[1-9]|1[012])/[0-9]{4}" placeholder="DD/MM/YYYY" title="You will have to Enter Your Birthday in this pattern(25/12/2000)">
		    </div>

		    <div class="form-group">
		      <label for="phone">Phone No:</label>
		      <input type="text" class="form-control" id="phone" placeholder="Enter Your Contact No" name="phone" min="1">
		    </div>

		    <div class="form-group">
		      <label for="address">Complete Address:</label>
		      <input type="text" class="form-control" id="address" placeholder="Enter Your Complete Address" name="address">
		    </div>

		  <input type="submit" name="submit" class="btn btn-default" value="Submit" id="e_sub">
		 	  <div class="response" style="display:none; color: red;"></div>
		    <div class="create_loader" style="display:none;">
		    	<img src="<?php echo PLUGIN_HTTP_URL.'images/ajax-loader.gif' ?>">
		    </div>
	  </form>
	</div>


</section>

<?php get_footer(); ?>
