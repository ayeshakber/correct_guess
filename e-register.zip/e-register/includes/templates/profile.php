<?php get_header();
$user_id = get_current_user_id();
if($user_id=='0'){

?>
<script>
  window.location.href="/my-login/";
</script>
<?php
}
require(PLUGIN_URL."mpdf60/mpdf.php");
?>

<section id="content" role="main">
  <style>
    /* Style the tab */
    div.tab {
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
    }
    /* Style the buttons inside the tab */
    div.tab button {
        background-color: inherit;
        float: left;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 16px;
        transition: 0.3s;
    }
    /* Change background color of buttons on hover */
    div.tab button:hover {
        background-color: #ddd;
    }
    /* Create an active/current tablink class */
    div.tab button.active {
        background-color: #ccc;
    }
    /*Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #ccc;
        border-top: none;
    }
  </style>
  <script>
  function openTabs(evt, tabName)
  {
    // Declare all variables
    var i, tabcontent, tablinks;
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
 }
  </script>
  <?php
  $user_id = get_current_user_id();
  #GET USER INFORMATION
  $user_info = get_userdata( $user_id );
  //print_r($user_info);
  $ful_name = $user_info->display_name;
  $user_email = $user_info->user_email;
  $user_name = $user_info->user_login;
  $user_pass = $user_info->user_pass;
  $user_joining = $user_info->user_registered;
  $user_joining = explode(' ',$user_joining);
  #print_r($user_joining);
  $qualification = get_user_meta($user_id, 'qualification', true);
  $institute = get_user_meta($user_id, 'institute', true);
  $dob = get_user_meta($user_id, 'dob', true);
  $phone = get_user_meta($user_id, 'phone', true);
  $address = get_user_meta($user_id, 'address', true);
  $redirect = site_url();
  $logout =  wp_logout_url( $redirect );
  ?>
  <div class="my_profile">
    <h1 class="entry-title">My Profile</h1>
    <div class="tab">
      <button class="tablinks active" onclick="openTabs(event, 'View')">View</button>
      <button class="tablinks" onclick="openTabs(event, 'Edit')">Edit</button>
      <button class="tablinks" onclick="openTabs(event, 'Reports')">Reports</button>
    </div>
    <div id="View" class="tabcontent" style="display:block;">
      <h3>My Information</h3>
  			 <div class="my_name">
  		      <label for="my_name">Full Name:</label>
            <span><?php echo $ful_name; ?></span>
  		    </div>
  		    <div class="my_email">
  		      <label for="my_email">Email:</label>
            <span><?php echo $user_email; ?></span>
  		    </div>
  		    <div class="my_username">
  		      <label for="my_username">Username:</label>
            <span><?php echo $user_name; ?></span>
  		    </div>
  		    <div class="my_qualification">
  		      <label for="my_qualification">Qualificatuion:</label>
            <span><?php echo $qualification; ?></span>
  		    </div>
  		    <div class="my_institute">
  		      <label for="my_institute">Institute:</label>
            <span><?php echo $institute; ?></span>
  		    </div>
  		    <div class="my_dob">
  		      <label for="my_dob">Date of Birth:</label>
            <span><?php echo $dob; ?></span>
  		    </div>
  		    <div class="my_phone">
  		      <label for="my_phone">Phone No:</label>
            <span><?php echo $phone; ?></span>
  		    </div>
  		    <div class="my_address">
  		      <label for="my_address">Address:</label>
            <span><?php echo $address; ?></span>
  		    </div>
          <div class="my_joining">
           <label for="my_joining">Date of Joining:</label>
           <span><?php echo $user_joining[0]; ?></span>
         </div>
    </div>
    <div id="Edit" class="tabcontent">
      <h3>Edit My Info</h3>
      <!-- <p> EDIT YOUR PROFILE </p> -->
      <form action="" method="POST" enctype="multipart/form-data" name="update_form" id="update_form">
  			  <div class="form-group">
  		      <label for="edit_name">Update Full Name:</label>
  		      <input type="full_name" class="form-control" id="edit_name" name="edit_name" value="<?php echo $ful_name; ?>">
  		    </div>
  		    <div class="form-group">
  		      <label for="edit_email">Email:</label>
  		      <input type="email" class="form-control" id="edit_email" name="edit_email" value="<?php echo $user_email; ?>"  disabled="disabled">
  		    </div>
  		    <div class="form-group">
  		      <label for="edit_username">Username:</label>
  		      <input type="text" class="form-control" id="edit_username" name="edit_username" value="<?php echo $user_name; ?>"  disabled="disabled">
  		    </div>
  		    <div class="form-group">
  		      <label for="edit_qualification">Update Qualificatuion:</label>
  		      <input type="text" class="form-control" id="edit_qualification" name="edit_qualification" value="<?php echo $qualification; ?>">
  		    </div>
  		    <div class="form-group">
  		      <label for="edit_institute">Update Institute:</label>
  		      <input type="text" class="form-control" id="edit_institute" name="edit_institute" value="<?php echo $institute; ?>">
  		    </div>
  		    <div class="form-group">
  		      <label for="edit_dob">Update Date of Birth:</label>
  		      <input type="text" class="form-control" id="edit_dob" name="edit_dob" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])/(0[1-9]|1[012])/[0-9]{4}" title="You will have to enter in this pattern(25/12/2012)" value="<?php echo $dob; ?>">
  		    </div>
  		    <div class="form-group">
  		      <label for="edit_phone">Update Phone No:</label>
  		      <input type="number" class="form-control" id="edit_phone" name="edit_phone" value="<?php echo $phone; ?>">
  		    </div>
  		    <div class="form-group">
  		      <label for="edit_address">Update Address:</label>
  		      <input type="text" class="form-control" id="edit_address" name="edit_address" value="<?php echo $address; ?>">
  		    </div>
          <!--<div class="form-group">
  		      <label for="current_password">Current Password:</label>
  		      <input type="password" class="form-control" id="current_password" name="current_password" value="<?php //echo $user_pass; ?>">
  		    </div>
          <div class="form-group">
            <label for="new_password">New Password:</label>
            <input type="password" class="form-control" id="new_password" name="new_password" value="<?php //echo $user_pass; ?>">
          </div> -->
          <input type="submit" name="submit" class="btn btn-default" value="Update" id="edit_info">
          <div class="update_response" style="display:none; color: red;"></div>
  		    <div class="create_loader2" style="display:none;">
  		    	<img src="<?php echo PLUGIN_HTTP_URL.'images/ajax-loader.gif' ?>">
  		    </div>
  	  </form>
    </div>

 <!-- PROGRESS REPORT -->

      <?php
      $html = '<div id="Reports" class="tabcontent">
          <h3>E-Learning Progress Report</h3>
          <div class="my_compl_repo">
              <a style="cursor: pointer;" hre="'.$redirect.'">'.$redirect.'</a>
              <div><label>Student ID:'.$user_id.'</label></div>
              <div><label>Student Name:'.$ful_name.'</label></div>
              <div><label>Student Email:'.$user_email.'</label></div>
              <div><label>Student Phone:'.$phone.'</label></div>
              <div><label>Date of Joining:'.$user_joining[0].'</label></div>
            </div>';
      $course_progress =  get_user_meta($user_id,'_sfwd-course_progress',true);

      $html .= '<div>
        <table class="table">
          <thead class="t_repo">
            <tr>
              <th>Course ID</th>
              <th>Course Name</th>
              <th>Course Type</th>
              <th>Price</th>
              <th>Status</th>
              <th>Certificate</th>
            </tr>
          </thead>
          <tbody class="b_repo">';

      if (!empty($course_progress))
      {

          foreach ($course_progress as $key => $value)
          {
            $post_id =$key;
            $course_post =  get_post_meta($post_id,'_sfwd-courses',true);
            $course_completed =  get_user_meta($user_id,'course_completed_'.$post_id,true);
            $post_ifo = get_post($post_id);
            $certificate_id =$course_post['sfwd-courses_certificate'];
            $course_price =$course_post['sfwd-courses_course_price'];
            $course_type = $course_post['sfwd-courses_course_price_type'];
            $certificate_ifo = get_post($certificate_id);
            $c_certificate_issue = "";
            if (!empty($course_completed))
            {
              $course_Status = "Completed";
              $c_certificate_issue = "Issued";
            }
            else
            {
              $course_Status = "InComplete";
              $c_certificate_issue = "Not Issued";
            }
            $c_type = "";
            $c_price = "";
            if ($course_type == "free")
            {
                $c_type = "Free";
                $c_price = "0";
            }
            if ($course_type == "paynow")
            {
              $c_type = "Paid";
                $c_price = $course_price;
            }
            $html.='<tr>
                      <td>'.$post_id.'</td>
                      <td>'.$post_ifo->post_title.'</td>
                      <td>'.$c_type.'</td>
                      <td>$'.$c_price.'</td>
                      <td>'.$course_Status.'</td>
                      <td>'.$c_certificate_issue.'</td>
                   </tr>';
        }
      }
      $pdf_url = site_url().'/progress-report/';
      $pdf_email = site_url().'/report-email/';
      $html .= '</tbody>
      </table>
      </div>
      <div class="pdf"><a href="'.$pdf_url.'">Download PDF</a> / <a href="'.$pdf_email.'">Send Email(In PDF Format)</a></div>';
      $html .='</div>';
      echo $html;
      /////////////////////////
      #upload report to admin folder
      // $logo_path = PLUGIN_URL.'images/logo.png';
      // $logo ='<img src="'.$logo_path.'"/>';
      // $mpdf = new mPDF();
      // $mpdf->SetHeader($logo);
      // $mpdf->WriteHTML($html);
      // $mpdf->SetFooter('Progress Report|{PAGENO}');
      // $mpdf->Output();
       ?>
  </div>
</section>
<?php get_footer(); ?>
