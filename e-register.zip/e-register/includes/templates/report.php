<?php
require(PLUGIN_URL."mpdf60/mpdf.php");
///////////////////////////////
$user_id = get_current_user_id();
#GET USER INFORMATION
$user_info = get_userdata( $user_id );
$ful_name = $user_info->display_name;
$user_email = $user_info->user_email;
$user_name = $user_info->user_login;
$user_pass = $user_info->user_pass;
$user_joining = $user_info->user_registered;
$user_joining = explode(' ',$user_joining);
$qualification = get_user_meta($user_id, 'qualification', true);
$institute = get_user_meta($user_id, 'institute', true);
$dob = get_user_meta($user_id, 'dob', true);
$phone = get_user_meta($user_id, 'phone', true);
$address = get_user_meta($user_id, 'address', true);
$redirect = site_url();
$html ='<div id="Reports" class="tabcontent">
      <h3>E-Learning Progress Report</h3>
        <div class="my_compl_repo">
          <a style="cursor: pointer;" hre="'.$redirect.'">'.$redirect.'</a>
          <div><label>Student ID:'.$user_id.'</label></div>
          <div><label>Student Name:'.$ful_name.'</label></div>
          <div><label>Student Email:'.$user_email.'</label></div>
          <div><label>Student Phone:'.$phone.'</label></div>
          <div><label>Date of Joining:'.$user_joining[0].'</label></div>
        </div>';
  $course_progress =  get_user_meta($user_id,'_sfwd-course_progress',true);
  $html .= '<div>
    <table class="table">
      <thead class="t_repo" style="background-color: #83cace;">
        <tr>
          <th>Course ID</th>
          <th>Course Name</th>
          <th>Course Type</th>
          <th>Price</th>
          <th>Status</th>
          <th>Certificate</th>
        </tr>
      </thead>
      <tbody class="b_repo" style="background-color: #e6f3f2;">';
  foreach ($course_progress as $key => $value)
  {
    $post_id =$key;
    $course_post =  get_post_meta($post_id,'_sfwd-courses',true);
    $course_completed =  get_user_meta($user_id,'course_completed_'.$post_id,true);
    $post_ifo = get_post($post_id);
    $certificate_id =$course_post['sfwd-courses_certificate'];
    $course_price =$course_post['sfwd-courses_course_price'];
    $course_type = $course_post['sfwd-courses_course_price_type'];
    $certificate_ifo = get_post($certificate_id);
    $c_certificate_issue = "";
    if (!empty($course_completed))
    {
      $course_Status = "Completed";
      $c_certificate_issue = "Issued";
    }
    else
    {
      $course_Status = "InComplete";
      $c_certificate_issue = "Not Issued";
    }
    $c_type = "";
    $c_price = "";
    if ($course_type == "free")
    {
        $c_type = "Free";
        $c_price = "0";
    }
    if ($course_type == "paynow")
    {
      $c_type = "Paid";
      $c_price = $course_price;
    }
    $html.='<tr>
              <td>'.$post_id.'</td>
              <td>'.$post_ifo->post_title.'</td>
              <td>'.$c_type.'</td>
              <td>$'.$c_price.'</td>
              <td>'.$course_Status.'</td>
              <td>'.$c_certificate_issue.'</td>
           </tr>';
  }
  $pdf_url = site_url().'/progress-report/';
  $html .= '</tbody>
    </table>
    </div>
  </div>';
/////////////////////////
$pdf_file = $user_name. '_report.pdf';
$filename = PLUGIN_URL.'students_report_files/'.$pdf_file;
$prog_report = update_user_meta($user_id, 'progress_report', $filename);
$logo_path = PLUGIN_URL.'images/logo.png';
$logo = '<img src="'.$logo_path.'"/>';
$mpdf = new mPDF();
$mpdf->SetHeader($logo);
$mpdf->WriteHTML($html);
$mpdf->SetFooter('Progress Report|{PAGENO}');
$mpdf->Output($filename, 'F');
$mpdf->Output();

?>
