<?php
ob_start();
/**
 * @package E_Learning_Register
 * @version 4.4
 */
/*
Plugin Name: E_Learning_Register
Plugin URI: https://wordpress.org/plugins/E_Learning_Register/
Description: E_Learning_Register can manage multiple users inforamtion, plus you can customize the link and the mail contents flexibly with simple markup.
Version: 5.5
Author:Ayesha Akber
Author URI: http://localhost/
*/
/*
@parameter: $url
@output : array|object|string
@author: Ayesha Akber
*/
//hello tidy_parse_string
define('PLUGIN_URL',plugin_dir_path( __FILE__ ));   //F:/xzamp/htdocs till plugin folder
define('PLUGIN_HTTP_URL',plugin_dir_url( __FILE__ ));   //hhtps:www.google.com till plugin folder

#### INCLUDE CLASS #####
include('includes/registration_class.php');
$learning = new Registration_class(); #CLASS OBJECT

add_action('wp_enqueue_scripts','e_scripts');
function e_scripts() //DONE
{
		wp_enqueue_script('e-sc1', 'https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js', array('jquery'));
		wp_enqueue_script('e-sc4', 'https://code.jquery.com/jquery-1.12.4.js', array('jquery'));
		wp_enqueue_script('e-sc5', 'https://code.jquery.com/ui/1.12.1/jquery-ui.js', array('jquery'));
		//wp_enqueue_script('e-sc4', 'https://cdnjs.cloudflare.com/ajax/libs/datepicker/0.5.2/datepicker.js', array('jquery'));
		//wp_enqueue_script('e-sc5', 'https://cdnjs.cloudflare.com/ajax/libs/datepicker/0.5.2/datepicker.min.js', array('jquery'));
   		wp_enqueue_script('e-sc2', plugin_dir_url( __FILE__ ).'js/script.js' );
		wp_enqueue_style('e-css', plugin_dir_url(__FILE__)  . 'css/style.css' );
		wp_enqueue_style('e-css3', 'http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css' );
    	wp_enqueue_script('e-sc3', 'http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array('jquery'));
 		wp_enqueue_style('my-css', 'http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css');
}

add_action('wp_head','objective_javascript');
add_action('wp_ajax_objective_callback','objective_callback');
add_action('wp_ajax_nopriv_objective_callback', 'objective_callback');
add_action('wp_ajax_edit_objective_callback','edit_objective_callback');
add_action('wp_ajax_nopriv_edit_objective_callback', 'edit_objective_callback');
function objective_javascript()
{
	$user_id = get_current_user_id();
	$uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
	$uri = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
	$uri_segments = explode('/', $uri);
	$uri_segments_count = count($uri_segments);
	$user_segment = $uri_segments[$uri_segments_count - 2];
	#course_346_access_from-> course taken
	$post_id = get_the_ID();
	$course_access = get_user_meta($user_id,'course_'.$post_id.'_access_from',true);
	#print_r($course_access);
	$user_id = get_current_user_id();
	#GET USER INFORMATION
	$user_info = get_userdata( $user_id );
	$course_already_access = get_user_meta($user_id,'personal_objective_'.$post_id,true);
	
	
	$object = '';
	$date = '';
	$hrs = '';
	$min = '';
	$sec = '';
	if (!empty($course_already_access)) {
		$object = $course_already_access['my_obj'];
		//$hrs = $course_already_access['hrs'];
		$hr = $course_already_access['hr'];
		$date = $course_already_access['date'];
		$min = $course_already_access['min'];
		$sec = $course_already_access['sec'];
	}
	if(!empty($course_already_access))
	{
		?>
		<script>
		jQuery(document).ready(function()
		{
			var time = '<?php echo $hr.":".$min.":".$sec;?>';

			var objective_div = '<div class="myobjective"></div>';
			jQuery('#learndash_course_status').after(objective_div);
			var already_access  = '<div class="per_obj"><label>Your Personal Objective:</label><?php echo $object;?></div><div class="per_hrs"><label>Date:</label><span><?php echo $date;?></span><label>Time:</label><span>'+time+'</span></div><div class="time_left"><span id="timer"></span></div><input type="button" class="btn btn-default edit" name="edit" value="edit"><form class="obj_form" method="post" style="display:none;"><div class="form-group"><label>Set Your personal Objective</label><input type="text" class="edit_obj" name="obj" value="<?php echo $object;?>"></div><div class="form-group"><label>Set Your Hour(s)</label><p>Choose Date: <input type="text" id="datepicker1" value="<?php echo $date; ?>"></p><label>Hours</label><select class="edit_hrs"><?php for($i=0;$i<=23;$i++) {  if($hr==$i){ ?> <option value="<?php echo $i; ?>" selected="selected"><?php echo $i;?> </option> <?php } else{ ?><option value="<?php echo $i; ?>"><?php echo $i; ?></option><?php } }  ?></select><label>Minutes</label><select class="edit_min"><?php for($k=0;$k<=59;$k++){ if($k==$min){ ?> <option value="<?php echo $k;?>" selected="selected"><?php echo $k; ?></option><?php } else{ ?><option value="<?php echo $k;?>"><?php echo $k; ?></option> <?php } } ?></select><label>Seconds</label><select class="edit_sec"><?php for($j=0;$j<=59;$j++){ if($j==$sec){ ?> <option value="<?php echo $j;?>" selected="selected"><?php echo $j; ?></option><?php } else{ ?><option value="<?php echo $j;?>"><?php echo $j; ?></option> <?php } } ?></select></div><div class="edit_ajax_loader" style="display:none;"><img src="<?php echo PLUGIN_HTTP_URL.'images/ajax-loader.gif' ?>"/></div><input type="button" class="btn btn-default edit_submit" name="submit" value="Save"></form>';

			jQuery('.myobjective').html(already_access);
			jQuery( function() {
    			jQuery( "#datepicker1" ).datepicker({minDate: 0,dateFormat: 'M,dd yy'});
  			} );
			var date = '<?php echo $date; ?>';
			var hr = '<?php echo $hr; ?>';
			var min = '<?php echo $min; ?>';
			var sec = '<?php echo $sec; ?>';

			////////////////////////////////////
			var user_date = date+' '+hr+':'+min+':'+sec;
		// var user_date = 'Apr 18, 2017'+' '+hr+':'+min+':'+sec;

        //Set the date we're counting down to
        //var countDownDate = new Date("Apr 17, 2017 23:37:25").getTime();
        var countDownDate = new Date(user_date).getTime();

        //Update the count down every 1 second
       	var x = setInterval(function() {
            //Get todays date and time
            var now = new Date().getTime();
            //Find the distance between now an the count down date
            var distance = countDownDate - now;
            //Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);
            //Output the result in an element with id="timer"
            document.getElementById("timer").innerHTML = days + "d " + hours + "h "
            + minutes + "m " + seconds + "s ";
            //If the count down is over, write some text
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("timer").innerHTML = "EXPIRED";
            }
        }, 1000);
			////////////////////////////////////
			console.log(already_access);

			 jQuery(document).on('click','.edit',function(){
				jQuery('.obj_form').toggle();
				var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
				jQuery(document).on('click', '.edit_submit',function (e)
				{
						/*You can get this value from some hidden field or div*/
						e.preventDefault();
						var edit_obj = jQuery('.edit_obj').val();
						var edit_hrs = jQuery('.edit_hrs').val();
						var edit_min = jQuery('.edit_min').val();
						var edit_sec = jQuery('.edit_sec').val();
						var datepicker1 = jQuery('#datepicker1').val();

						var post_id = '<?php echo $post_id; ?>';
						jQuery('.edit_ajax_loader').show();
						var data = {
								'action': 'edit_objective_callback',
								'edit_obj': edit_obj,
								'edit_hrs': edit_hrs,
								'edit_min' : edit_min,
								'edit_sec' : edit_sec,
								'datepicker1' : datepicker1,
								'post_id': post_id,
						};
						$.post(ajaxurl, data, function (response)
						{
							//alert(response);
							//jQuery('.myobjective').html(response);
							jQuery('.edit_ajax_loader').hide();
							location.reload();
						});
				});

			});
		});
		</script>
		<?php
	}
	else
	{
			if (!empty($course_access))
			{
					if (!empty($uri_segments[2]))
					{
						?>
						<script>
							jQuery(document).ready(function()
							{
								var objective_div = '<div class="myobjective"></div>';
								jQuery('#learndash_course_status').after(objective_div);
								var objective_form = '<form class="obj_form" method="post"><div class="form-group"><label>Set Your personal Objective</label><input type="text" class="obj" name="obj" value=""></div><div class="form-group"><label>Set Your Hour(s)</label><p>Choose Date: <input type="text" id="datepicker" value=""></p><label>Hours</label><select class="hr"><option value="choose">choose</option><?php for($m=0;$m<=23;$m++){ ?> <option value="<?php echo $m; ?>"><?php echo $m; ?></option> <?php } ?></select><label>Minutes</label><select class="min"><option value="choose">choose</option><?php for($n=0;$n<=59;$n++){ ?> <option value="<?php echo $n; ?>"><?php echo $n; ?></option> <?php } ?></select><label>Seconds</label><select class="sec"><option value="choose">choose</option><?php for($o=0;$o<=59;$o++){ ?> <option value="<?php echo $o; ?>"><?php echo $o; ?></option> <?php } ?></select></div><div class="ajax_loader" style="display:none;"><img src="<?php echo PLUGIN_HTTP_URL.'images/ajax-loader.gif'?>"/></div><input type="button" class="btn btn-default submit" name="submit" value="Save"></form>';
								jQuery('body').find('.myobjective').html(objective_form);
								
								jQuery( function() {
    								jQuery( "#datepicker" ).datepicker({minDate: 0,dateFormat: 'M,dd yy'});
  								} );
								var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
				        jQuery('.submit').on('click', function (e)
				        {
				            /*You can get this value from some hidden field or div*/
				            e.preventDefault();

				            var object = jQuery('.obj').val();

								var today_date = jQuery('.today_date').val();
						        var hr = jQuery('.hr').val();
						        var min = jQuery('.min').val();
						        var sec = jQuery('.sec').val();
						        
						        
					        	var post_id = '<?php echo $post_id; ?>';
					        	if(today_date=="" || hr=="" || min=="" || sec=="" || object==""){
					        		jQuery(".myobjective").show();
					        		jQuery(".new_message").remove();
					        		jQuery('.myobjective').append('<span class="new_message">Required All fields..</span>');
					        	}
					        	else if(hr=="choose" || min=="choose" || sec='choose'){
					        		jQuery(".new_message").remove();
					        		jQuery('.myobjective').append('<span class="new_message">Required All fields..</span>');
					        	}
					        	else{
								var today_date1 = jQuery('#datepicker').val();
								jQuery('.ajax_loader').show();
				           		        var data = {
							                'action': 'objective_callback',
							                'object': object,
							                'today_date1': today_date1,
											'hrs': hrs,
							                'hr': hr,
							                'min': min,
							                'sec': sec,
							                'post_id': post_id,
							            };
							            $.post(ajaxurl, data, function (response)
							            {
							              //alert(response);
														jQuery('.ajax_loader').hide();
														location.reload();
														jQuery('.myobjective').html(response);
							            });
				        			}
								});
							});

						</script>
						<?php
					}
			}
	}
}

function objective_callback()
{
	$user_id = get_current_user_id();
	$object = $_POST['object'];
	$hrs = $_POST['hrs'];
	$today_date1 = $_POST['today_date1'];
	$hr = $_POST['hr'];
	$min = $_POST['min'];
	$sec = $_POST['sec'];
	$post_id = $_POST['post_id'];
	// $personal_objective = array(
	// 	'post_id' =>$post_id,
	// 	'my_obj' =>$object,
	// 	'my_hrs' =>$hrs
	// );
	$personal_objective = array(
		'post_id' =>$post_id,
		'my_obj' =>$object,
		'date' =>$today_date1,
		'hr' =>$hr,
		'min' =>$min,
		'sec' =>$sec,
	);
	$my_obj = update_user_meta($user_id,'personal_objective_'.$post_id,$personal_objective);
	$html  = '<div class="per_obj"><label>Your Personal Objective:</label>'.$object.'</div><div class="per_hrs"><label>Hours:</label>'.$hrs.'</div>';
	//$html .='<input type="button" class="btn btn-default edit" name="edit" value="edit"><form class="obj_form" method="post" style="display:none;"><div class="form-group"><label>Set Your personal Objective</label><input type="text" class="obj" name="obj" value=""></div><div class="form-group"><label>Set Your Hour(s)</label><input type="text" class="hrs" name="hrs" value=""></div><input type="button" class="btn btn-default submit" name="submit" value="Save"></form>';
	//$html .=	do_shortcode ('[TimeCounter date="2017/04/11 18:00:00" past="false" timeZone= showDay="true" showHour="true" showMinute="true" showSecond="true" dayText="Days" hourText="Hours" minuteText="Minutes" secondText="Seconds" imagefolder="default" onFinish=""]');
	echo $html;
	die();
}
function edit_objective_callback()
{
	$user_id = get_current_user_id();
	$edit_obj = $_POST['edit_obj'];
	$edit_hrs = $_POST['edit_hrs'];
	$edit_min = $_POST['edit_min'];
	$edit_sec = $_POST['edit_sec'];
	$datepicker1 = $_POST['datepicker1'];
	$post_id = $_POST['post_id'];
	/*$edit_personal_objective = array(
		'post_id' =>$post_id,
		'my_obj' =>$edit_obj,
		'my_hrs' =>$edit_hrs
	);*/
	$edit_personal_objective = array(
		'post_id' =>$post_id,
		'my_obj' =>$edit_obj,
		'date' =>$datepicker1,
		'hr' =>$edit_hrs,
		'min' =>$edit_min,
		'sec' =>$edit_sec,
	);
	$my_obj = update_user_meta($user_id,'personal_objective_'.$post_id,$edit_personal_objective);
	$html  = '<div class="per_obj"><label>Your Personal Objective:</label>'.$edit_obj.'</div><div class="per_hrs"><label>Hours:</label>'.$edit_hrs.'</div>';
	//<input type="button" class="btn btn-default edit" name="edit" value="edit">
	//$html  .=	do_shortcode ('[TimeCounter date="2017/04/11 18:00:00" past="false" timeZone= showDay="true" showHour="true" showMinute="true" showSecond="true" dayText="Days" hourText="Hours" minuteText="Minutes" secondText="Seconds" imagefolder="default" onFinish=""]');
	echo $html;
	die();
}

?>
