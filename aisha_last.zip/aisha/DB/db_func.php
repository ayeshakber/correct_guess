<?php
//
class DB_function
{
	//select all users
	public function select_all()
	{
		$res = mysql_query("SELECT * FROM users");
		return $res;
	}

	//select 1 user
	public function select_user($id)
	{
		$res = mysql_query("SELECT * FROM users WHERE id='$id'");
		return $res;
	}


	//user insert query
	public function insert_users($full_name,$email,$username,$password,$job_title,$dob,$nic,$country,$city,$postal_code,$address,$user_desc)
	{
		
		$res = mysql_query("INSERT users(full_name,email,username,password,job_title,dob,nic,country,city,postal_code,address,user_desc) VALUES('$full_name','$email','$username','$password','$job_title','$dob','$nic','$country','$city','$postal_code','$address','$user_desc')") or die("registeration fail");
		return $res;
	}

	//login query
	public function user_login($username,$password)
	{
		//session_start();
		//echo "SELECT * FROM users WHERE username='$username' AND password='$password'";
		$res=mysql_query("SELECT * FROM users WHERE username='$username' AND password='$password'") or die("table query eror");

		if(mysql_num_rows($res)){
			$arr = array();
			while ($row = mysql_fetch_array($res)) 
			{
				 $_SESSION["user_id"]=$row['id'];
				
			}
			$res = "welcome";
		}
		else{
			$res = "Invalid Usernam OR Password";
		}
		
		return $res;
	}

	//upadte user
	public function user_update($id,$full_name,$job_title,$dob,$nic,$country,$city,$postal_code,$address,$user_desc)
	{
		$res = mysql_query("UPDATE users SET full_name='$full_name', job_title='$job_title', dob='$dob', nic='$nic', country='$country', city='$city', postal_code='$postal_code', address='$address', user_desc='$user_desc' WHERE id='$id'") or die("update query table");
		//print_r($res);
		//$res = "success"
		if(!empty($res)){
			$res = "success";
		}
		else{
			echo "error";
		}
		return $res;
	}

	//delete user
	function user_delete($id)
	{
		 $res = mysql_query("DELETE FROM users WHERE id='$id'");
		 return $res;
	}
	//contact us user
	public function contact_us($name,$email,$subject,$msg)
	{
		$res = mysql_query("INSERT contact_us(name,email,subject,msg) VALUES('$name','$email','$email','$msg')");
		return $res;
	}

	//subscribe users
	public function subscribe_user($email_address)
	{
		$res = mysql_query("INSERT subscribe_users(email_address) VALUES('$email_address')");
		return $res;
	}

	//select all users
	public function select_all_choose_us()
	{
		$res = mysql_query("SELECT * FROM choose_us");
		return $res;
	}

}

?>