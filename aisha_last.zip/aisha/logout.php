<?php 
//session_start();
include('header.php');
//session_start();
if(isset($_GET["logout"]) && $_GET["logout"]=="success"){
	session_destroy();
	?>
	<script>
		window.location="http://localhost/aisha/";
	</script>
	<?php
}
include('footer.php');
?>
