<?php 
include('header.php');
include('DB/db_conn.php');
include('DB/db_func.php');
//$user_id = $_SESSION["user_id"];
$db_func = new DB_function();
$res = $db_func->select_all_choose_us();
$arr = array();
$i=0;
while($row = mysql_fetch_assoc($res)) 
{
	$arr[$i]['id'] =$row['id'];
	$arr[$i]['title'] =$row['title'];
	$arr[$i]['desc'] =$row['desc'];
	$arr[$i]['images'] =$row['images'];
	++$i; 
}
?>
<div class="content">
		<div class="row slider_div">
			<div id="owl-demo" class="owl-carousel">
			<?php
			$images = array();
			if ($dir = opendir('images/sliders/')) 
			{
				while (false !== ($file = readdir($dir))) 
				{
					if ($file != "." && $file != "..") 
					{
						$images[] = $file; 
					}
				}
				closedir($dir);
			}
			foreach ($images as $key => $value) 
			{	
				echo '<div class="item">';
					//echo '<div class="img-wrap">';
					//echo '<span class="close">&times;</span>';
					echo '<img src="images/sliders/'.$images[$key].'" alt="" /> ';
					//echo '</div>';
				echo '</div>';
				//echo "<br>";
			}
			?>
			</div>
		</div>
		<div class="row offers_div"> 
            <div class="col-md-4 deals">
            	<legend>Deals</legend>
	            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
	            <span>Price:$150</span>
            	<a href="javascript:void(0)">
	            	<div>
	            		<img src="images/logo4.jpg" alt="">
	            	</div>
            	</a>
            </div>
            <div class="col-md-4 offfer">
            	<legend>Offers</legend>
	            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
	            <span>Price:$150</span>
            	<a href="javascript:void(0)">
	            	<div>
	            		<img src="images/logo4.jpg" alt="">
	            	</div>
            	</a>
            </div>
            <div class="col-md-4 package">
	            <legend>Packages</legend>
	        	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
	        	<span>Price:$150</span>
	            <a href="javascript:void(0)">
	            	<div>
	            	<img src="images/logo4.jpg" alt="">
	            	</div>
	            </a>
            </div>
        </div>
		<div class="row choose_us"> 
			<legend align="center">WHY CHOOSE US?</legend>
			<?php
			foreach ($arr as $key => $value) 
			{
				/*echo $value['title'];
				echo $value['desc'];
				echo $value['images'];*/
				?>
	            <div class="col-md-4 choose" id="<?php echo $value['id']; ?>">
	            	<div align="center">
	            		<img src="images/<?php echo $value['images']; ?>" alt="">
	            	</div>
	            	<legend align="center"><?php echo $value['title']; ?></legend>
		            <p><?php echo $value['desc']; ?>
	            	<a href="javascript:void(0)">
	            	</a>
	            </div>
            <?php
			}
			?>
       </div>
</div>	<!-- content -->

	<style>
	#parent {
	    width:50%;
	    height:100%;

	}

	#owl-demo .item{
	  margin: 3px;
	}
	#owl-demo .item img{
	  display: block;
	  width: 100%;
	  height: auto;
	}

	#owl-demo .item .img-wrap {
    position: relative;
    
	}
	#owl-demo .item .img-wrap .close {
    position: absolute;
    top: 2px;
    right: 2px;
   z-index: 1; 
    
	}

</style>
<?php 
include('footer.php');
?>
