<?php
//echo $_GET['full_name'];
session_start();
include('../DB/db_conn.php');
include('../DB/db_func.php');
$db_func = new DB_function();

if(isset($_GET['contacts']))
{
	//echo "working...";
	$name = $_GET['full_name'];
	$email = $_GET['email'];
	$sub = $_GET['subject'];
	$msg = $_GET['msg'];
	$contact_user = $db_func->contact_us($name,$email,$sub,$msg);

	echo "<h2>Your msg has been sent</h2>";


}
if(isset($_GET["signups"])){
	$full_name = $_GET["full_name"];
	$email = $_GET["email"];
	$Username = $_GET["Username"];
	$password = $_GET["password"];
	$password  = md5($password );
	$job = $_GET["job"];
	$dob = $_GET["dob"];
	$nic = $_GET["nic"];
	$country = $_GET["country"];
	$city = $_GET["city"];
	$postal_code = $_GET["postal_code"];
	$address = $_GET["address"];
	$USER_DESC = $_GET["USER_DESC"];
	$register_user = $db_func->insert_users($full_name,$email,$Username,$password,$job,$dob,$nic,$country,$city,$postal_code,$address,$USER_DESC);
	##### WELCOME EMAIL #######
	  $to = $email;
		$subject = "Welcome to Fastr Food Factory";
		$message = "
		<html>
			<head>
			<title>Foods Factory</title>
			</head>
		<body>
		    <h1>Welcome to Fastr Food Factory</h1>
       <p>A fast food restaurant, also known as a quick service restaurant (QSR) within the industry, is a specific type of restaurant that serves fast food cuisine and has minimal table service</p><br>
      <h4>What are the benefits?</h4>
      <p>TThe food served in fast food restaurants is typically part of a , offered from a limited menu, cooked in bulk in advance and kept hot, finished and packaged to order, and usually available for take away, though seating may be provided at the restaurant.</p>
      <p>Visit our Website:http://localhost/aisha/ 
		</body>
		</html>";
		#Always set content-type when sending HTML email
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		#More headers
		$headers .= 'From: <webmaster@example.com>' . "\r\n";
		$headers .= 'Cc: ayeshakber.cs2011@gmail.com' . "\r\n";
		mail($to,$subject,$message,$headers);
	echo "<h2>Your Registration successful</h2>";

}
if(isset($_GET["login_sub"])){
	$login_username = $_GET['user_login'];
	$pasword = $_GET['login_pass'];
	$login_user = $db_func->user_login($login_username,$pasword);
	echo $login_user;
}
if(isset($_GET["edit_pro"])){
	$edit_full_name = $_GET['edit_full_name'];
	$edit_job = $_GET['edit_job'];
	$edit_dob = $_GET['edit_dob'];
	$edit_nic = $_GET['edit_nic'];
	$edit_country = $_GET['edit_country'];
	$edit_city = $_GET['edit_city'];
	$edit_postal_code = $_GET['edit_postal_code'];
	$edit_address = $_GET['edit_address'];
	$edit_user_desc = $_GET['edit_user_desc'];
	$user_id = $_SESSION["user_id"];
	$udpate_user = $db_func->user_update($user_id,$edit_full_name,$edit_job,$edit_dob,$edit_nic,$edit_country,$edit_city,$edit_postal_code,$edit_address,$edit_user_desc);
	echo $udpate_user;
}


if(isset($_GET["subs_submit"])){
	$subs_emails = $_GET['subs_emails'];
	$login_user = $db_func->subscribe_user($subs_emails);
	echo "Subscribed Succesfully";
}
?>