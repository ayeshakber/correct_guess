<?php
session_start();
//echo $_SESSION[""]
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
  <title>Admin | Fast Food Factory </title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- Important Owl stylesheet -->
	<link rel="stylesheet" href="owl.carousel/owl-carousel/owl.carousel.css">
	 
	<!-- Default Theme -->
	<link rel="stylesheet" href="owl.carousel/owl-carousel/owl.theme.css">
	 
	<!--  jQuery 1.7+  -->
	<!--<script src="../jquery-1.9.1.min.js"></script>-->
	 
	<!-- Include js plugin -->
	<script src="owl.carousel/owl-carousel/owl.carousel.js"></script>
	<!-- C:\xampp\htdocs\OWL\try\owl.carousel\owl-carousel -->
	<script src="js/script.js"></script>
	<link rel="stylesheet" href="css/style.css">
	<script>
		$(document).ready(function() 
		{

	  		$("#owl-demo").owlCarousel({
	 
		      autoPlay: 3000, //Set AutoPlay to 3 seconds
		 
		      items : 4,
		      itemsDesktop : [1199,3],
		      itemsDesktopSmall : [979,3]
		 
			  });
		 
		});
	</script>
	<style>
		.head_menu {
		    list-style-type: none;
		    margin: 0;
		    padding: 0;
		    overflow: hidden;
		    background-color: #333333;
		}

		.head_menu li {
		    float: left;
		}

		.head_menu li a {
		    display: block;
		    color: white;
		    text-align: center;
		    padding: 16px;
		    text-decoration: none;
		}

		.head_menu li a:hover {
		    background-color: #111111;
		}
	</style>
</head>
<body>
<header id="header" class="header">
			<div class="row header_div">
				<div class="col-md-4 logo_name">
	              <img src="images/logo4.jpg" alt="">
	              <a class="brand_name" href="/aisha"><h3>Administartor | Fast Food Factory</h3></a>
	            </div>
	            <div class="right_icons">
					<div class="col-md-2 seacrh">
		                  <input type="text" class="form-control" placeholder="Search...." ng-model="search">
		            </div>	
		            <div class="col-md-6 menu">
		            <ul class="head_menu">
		            	<li><a href="../index.php" ><b>Go to Website</b></a></li>
		            	<li><a href="users.php" ><b>Users</b></a></li>
		            	<li><a href="packages.php" ><b>Packages</b></a></li>
		            	<li><a href="deals.php" ><b>Deals</b></a></li>
		            	<li><a href="choose_us.php" ><b>Why Choose</b></a></li>
		            	<li><a href="careers.php"><b>Careers</b></a></li>
		            	<?php
		            	if(isset($_SESSION["user_id"])){
		            		$user_id = $_SESSION["user_id"];
		            	}
		            	else{
		            		$user_id="";
		            	}
		            	if(empty($user_id)){
		            		//echo "work";
		            		?>
		            		<li><a href="login.php" ><b>Login</b></a></li>
		            		<li><a href="register.php" ><b>Register</b></a></li>
		            		<?php
		            	}
		            	else{
		            		?>
		            		<li><a href="profile.php" ><b>Profile</b></a></li>
		            		<li><a href="logout.php?logout=success" ><b>Logout</b></a></li>
		            		<?php
		            	}
		            	?>
		            	
		            </ul>	
					</div>
				</div>
			</div>
		</header>
	<div class="container">
		
		<!-- /header -->

