
<?php 
include('header.php');
?>
<div class="content">
	<div class="row admin_div"> 
        <div class="col-md-4 deals">
        	<legend>My Info</legend>
            	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p><span>Price:$150</span>
        	<a href="javascript:void(0)">
            	<div>
            	<img src="images/logo4.jpg" alt="">
            	</div>
        	</a>
        </div>
        <div class="col-md-4 offfer">
        	<legend>Edit</legend>
            	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            	<span>Price:$150</span>
	        	<a href="javascript:void(0)">
	            	<div>
	            	<img src="images/logo4.jpg" alt="">
	            	</div>
	        	</a>
	        	<ul>
	        		<li class="fa fa-coffee"></li>
	        	</ul>
        </div>
       <!--  <div class="col-md-4 package">
            <legend>Packages</legend>
            	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            	<span>Price:$150</span>
            <a href="javascript:void(0)">
            	<div>
            	<img src="images/logo4.jpg" alt="">
            	</div>
            </a>
        </div> -->
    </div>
</div>

<?php 
include('footer.php');
?>