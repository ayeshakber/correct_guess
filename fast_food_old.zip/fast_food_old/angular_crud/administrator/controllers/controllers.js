myApp.controller('empController', function($scope,$http)
{	
	//site url 
	/*var url = window.location.origin
	//admin login 
	$scope.submit = function(){
		var uname = $scope.username;
		var password = $scope.password;
		
		if ($scope.username == 'admin' && $scope.password == 'admin') 
		{
			$rootScope.loggedIn = true;
			$location.path('/employees');
		}
		else
		{
			alert('Wrong Credential!');
			$location.path('/');
		}
	};

	//get admin
	$scope.getAdmin = function(){
		$http.get('DB_access/admin_user.php').then(function(response){
			$scope.admin = response.data;
		});
	};

	//get all employees
	$scope.getEmployees = function(){
		$http.get('DB_access/allselect_user.php').then(function(response){
			$scope.employees = response.data;
		});
	};

	//add employees
	$scope.addEmployee = function(info){
		$http.post('DB_access/insert_user.php', info).then(function(response){
			window.location.href = url+'/blog/angular_crud/administrator/#/employees/';
		});
	};

	//show specific employees
	$scope.showEmployee = function(){
		var id = $routeParams.id;
		$http.post('DB_access/show1_user.php',{'id':id}).then(function(response){
			var emp  = response.data;
			$scope.employee = emp[0];
		});
	};

	//update employees
	$scope.updateEmployee = function(info){
		$http.post('DB_access/update_user.php', info).then(function(response){

			window.location.href = url+'/blog/angular_crud/administrator/#/employees';
		});
	};

	//delete employees
	$scope.deleteEmployee = function(id){
		var id = id;
		$http.post('DB_access/delete_user.php',{'id':id}).then(function(response){
			$route.reload();
		});
	};*/

});
