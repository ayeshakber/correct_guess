var myApp = angular.module("myApp", ["ui.router"]);

myApp.config(function($stateProvider){
	$stateProvider
	.state("home",{
		url: "/",
		templateUrl: "templates/home.html",
		controller:"serviceController"
	})
	.state("home1",{
		url: "/home",
		templateUrl: "templates/home.html",
		controller:"serviceController"
	})
	.state("login", {
		url: "/login",
		templateUrl:'templates/login.html',
		controller:'serviceController'
	})
	.state("register", {
		url:"/register",
		templateUrl:'templates/register.html',
		controller:'serviceController'
	})
	.state("dashboard", {
		url:"/dashboard",
		templateUrl:'templates/dashboard.php',
		controller:'MainController'
	})
	.state("contact_us", {
		url:"/contact_us",
		templateUrl:'templates/contact_us.php',
		controller:'serviceController'
	})
	.state("about_us", {
		url:"/about_us",
		templateUrl:'templates/about_us.php',
		controller:'serviceController'
	});

	
});


