<?php 
include("db_conn.php");
$data = json_decode(file_get_contents("php://input"));
//variable
$name = $data->contact_name;
$email = $data->contact_email;
$subj = $data->contact_subj;
$msg = $data->contact_msg;

$sql = "INSERT INTO contact_us (contact_name,contact_email, contact_subj, contact_msg) 
VALUES ('$data->contact_name', '$data->contact_email', '$data->contact_subj', '$data->contact_msg')";
$qry = $conn->query($sql);


$to = $email;
$subject = $subj;

$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>

	".$msg."
</body>
</html>
";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <webmaster@example.com>' . "\r\n";
$headers .= 'Cc: ayesha.aimviz@gmail.com' . "\r\n";

mail($to,$subject,$message,$headers);

echo json_encode($data);
$conn->close();

?>