<div class="contact_us">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h3>Contact Us</h3>
		</div>
		<div class="panel-body">
		  	<form ng-submit="userContact()" method="POST">
		      
		      <div class="form-group">
		        <label for="contact_name">Name:</label>
		        <input type="text" class="form-control" id="contact_name" ng-model="contactInfo.contact_name" required>
		      </div>
		      
		      <div class="form-group">
		        <label for="contact_email">Email:</label>
		        <input type="text" class="form-control" id="contact_email" ng-model="contactInfo.contact_email" required>
		      </div>

		      <div class="form-group">
		        <label for="contact_subj">Subject:</label>
		        <input type="text" class="form-control" id="contact_subj" ng-model="contactInfo.contact_subj" required>
		      </div>
		      
		      <div class="form-group">
		        <label for="contact_msg">Message:</label>
		        <input type="text" class="form-control" id="contact_msg" ng-model="contactInfo.contact_msg" required>
		      </div>
		      <!-- <div class="response" ng-model="msg_success">{{msg_success}}</div> -->

		      <button type="submit" class="saved emp-btn">Submit</button>
		    </form>	
	    </div>
	</div>
</div>
<?php


?>