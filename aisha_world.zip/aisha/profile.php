<?php 
include('header.php');
include('DB/db_conn.php');
include('DB/db_func.php');
$db_func = new DB_function();
$res = $db_func->select_all();
$id = $db_func->select_user('1');
$arr = array();
$i=0;
while ($row = mysql_fetch_assoc($id)) 
{
	$arr[$i]['full_name'] =$row['full_name'];
	$arr[$i]['email'] =$row['email'];
	$arr[$i]['username'] =$row['username'];
	$arr[$i]['job_title'] =$row['job_title'];
	$arr[$i]['dob'] =$row['dob'];
	$arr[$i]['id_number'] =$row['id_number'];
	$arr[$i]['country'] =$row['country'];
	$arr[$i]['city'] =$row['city'];
	$arr[$i]['postal_code'] =$row['postal_code'];
	$arr[$i]['address'] =$row['address'];
	$arr[$i]['desc_yourself'] =$row['desc_yourself'];
	++$i; 
}
?>
<div class="content">
	<legend>My Personal</legend>
	<div class="profile_info">
	<fieldset>
		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="full_name">Full Name</label>  
		  <div class="col-md-5">
		  <span><?php print_r($arr[0]['full_name']); ?></span>
		  <!-- <input id="full_name" name="full_name" type="text" placeholder="Enter your Full Name" class="form-control input-md" required=""> -->
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="email">Email Address</label>  
		  <div class="col-md-5">
		  <span><?php print_r($arr[0]['email']); ?></span>
		  <!-- <input id="email" name="email" type="text" placeholder="Enter Your Email Address" class="form-control input-md" required=""> -->
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="Username">UserName</label>  
		  <div class="col-md-5">
		  <span><?php print_r($arr[0]['username']); ?></span>
		  <!-- <input id="Username" name="Username" type="text" placeholder="Enter your username" class="form-control input-md" required=""> -->
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="job">Job Designation</label>  
		  <div class="col-md-5">
		  <span><?php print_r($arr[0]['job_title']); ?></span>
		  <!-- <input id="job" name="job" type="text" placeholder="Enter your Job Titile" class="form-control input-md" required=""> -->
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="dob">Date of Birth</label>  
		  <div class="col-md-5">
		  <span><?php print_r($arr[0]['dob']); ?></span>
		  <!-- <input id="dob" name="dob" type="text" placeholder="Enter your DOB" class="form-control input-md" required=""> -->
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="nic">ID Card Number</label>  
		  <div class="col-md-5">
		  <span><?php print_r($arr[0]['id_number']); ?></span>
		  <!-- <input id="nic" name="nic" type="text" placeholder="Enter your ID card Number" class="form-control input-md" required=""> -->
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="country">Country</label>  
		  <div class="col-md-5">
		  <span><?php print_r($arr[0]['country']); ?></span>
		  <!-- <input id="country" name="country" type="text" placeholder="Enter Your Country Name" class="form-control input-md" required=""> -->
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="city">City</label>  
		  <div class="col-md-5">
		  <span><?php print_r($arr[0]['city']); ?></span>
		  <!-- <input id="city" name="city" type="text" placeholder="Enter Your City Name" class="form-control input-md" required=""> -->
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="postal_code">Postal Code</label>  
		  <div class="col-md-5">
		  <span><?php print_r($arr[0]['postal_code']); ?></span>
		  <!-- <input id="postal_code" name="postal_code" type="text" placeholder="Enter Your Postal Code" class="form-control input-md" required=""> -->
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="address">Address</label>  
		  <div class="col-md-5">
		  <span><?php print_r($arr[0]['address']); ?></span>
		  <!-- <input id="address" name="address" type="text" placeholder="Enter Your Address" class="form-control input-md" required=""> -->
		    
		  </div>
		</div>
		
		<!-- Textarea -->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="USER_DESC">About Myself</label>
		  <div class="col-md-4"> 
		  <<p><?php print_r($arr[0]['desc_yourself']); ?></p>                    
		    <!-- <textarea class="form-control" id="USER_DESC" name="USER_DESC" rows="5" cols="50"></textarea> -->
		  </div>
		</div>
		</fieldset>
	<!--  -->
	<!--  -->
	</div>
	
</div>
<?php 
include('footer.php');
?>
