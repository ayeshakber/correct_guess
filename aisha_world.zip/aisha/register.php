<?php 
include('header.php');
?>
<div class="content">
	<form class="form-horizontal">
		<fieldset>

		<!-- Form Name -->
		<legend>Form Name</legend>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="full_name">Full Name</label>  
		  <div class="col-md-5">
		  <input id="full_name" name="full_name" type="text" placeholder="Enter your Full Name" class="form-control input-md" required="">
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="email">Email Address</label>  
		  <div class="col-md-5">
		  <input id="email" name="email" type="text" placeholder="Enter Your Email Address" class="form-control input-md" required="">
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="Username">UserName</label>  
		  <div class="col-md-5">
		  <input id="Username" name="Username" type="text" placeholder="Enter your username" class="form-control input-md" required="">
		    
		  </div>
		</div>
		<!-- Password input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="password">Password</label>
		  <div class="col-md-5">
		    <input id="password" name="password" type="password" placeholder="Enter Your Password" class="form-control input-md" required="">
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="job">Job Designation</label>  
		  <div class="col-md-5">
		  <input id="job" name="job" type="text" placeholder="Enter your Job Titile" class="form-control input-md" required="">
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="dob">Date of Birth</label>  
		  <div class="col-md-5">
		  <input id="dob" name="dob" type="text" placeholder="Enter your DOB" class="form-control input-md" required="">
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="nic">ID Card Number</label>  
		  <div class="col-md-5">
		  <input id="nic" name="nic" type="text" placeholder="Enter your ID card Number" class="form-control input-md" required="">
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="country">Country</label>  
		  <div class="col-md-5">
		  <input id="country" name="country" type="text" placeholder="Enter Your Country Name" class="form-control input-md" required="">
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="city">City</label>  
		  <div class="col-md-5">
		  <input id="city" name="city" type="text" placeholder="Enter Your City Name" class="form-control input-md" required="">
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="postal_code">Postal Code</label>  
		  <div class="col-md-5">
		  <input id="postal_code" name="postal_code" type="text" placeholder="Enter Your Postal Code" class="form-control input-md" required="">
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="address">Address</label>  
		  <div class="col-md-5">
		  <input id="address" name="address" type="text" placeholder="Enter Your Address" class="form-control input-md" required="">
		    
		  </div>
		</div>
		
		<!-- Textarea -->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="USER_DESC">Describe Yourself</label>
		  <div class="col-md-4">                     
		    <textarea class="form-control" id="USER_DESC" name="USER_DESC" rows="5" cols="50"></textarea>
		  </div>
		</div>

		<!-- Sign up -->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="submit"></label>
		  <div class="col-md-4">
		  	<input type="submit" id="signup" name="signup" class="btn btn-primary" value="Register">
		  </div>
		</div>
		
		<div class="success_resp" style="display:none; color: red;"></div>
		    <div class="loader" style="display:none;">
		    	<img src="images/ajax-loader.gif">
			</div>
		</fieldset>
	</form>

	</div>
<?php 
include('footer.php');
?>
