<?php 
include('header.php');
?>
<div class="content">
		<div class="row slider_div">
			<h1>Slider goes here....</h1>
			<div class="item">

			</div>
			<div id="owl-demo" class="owl-carousel">
			<?php
			$images = array();
			if ($dir = opendir('images/')) 
			{
				while (false !== ($file = readdir($dir))) 
				{
					if ($file != "." && $file != "..") 
					{
						$images[] = $file; 
					}
				}
				closedir($dir);
				
			}
			foreach ($images as $key => $value) 
			{	
				echo '<div class="item">';
					//echo '<div class="img-wrap">';
					//echo '<span class="close">&times;</span>';
					echo '<img src="images/'.$images[$key].'" alt="" /> ';
					//echo '</div>';
				echo '</div>';
				//echo "<br>";

			}
			?>

			</div>
		</div>
		<div class="row offers_div"> 
            <div class="col-md-4 deals">
            	<legend>Deals</legend>
	            	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p><span>Price:$150</span>
            	<a href="">
	            	<div>
	            	<img src="images/logo4.jpg" alt="">
	            	</div>
            	</a>
            </div>
            <div class="col-md-4 offfer">
            	<legend>Offers</legend>
	            	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
	            	<span>Price:$150</span>
            	<a href="">
	            	<div>
	            	<img src="images/logo4.jpg" alt="">
	            	</div>
            	</a>
            </div>
            <div class="col-md-4 package">
	            <legend>Packages</legend>
	            	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
	            	<span>Price:$150</span>
	            <a href="">
	            	<div>
	            	<img src="images/logo4.jpg" alt="">
	            	</div>
	            </a>
            </div>
        </div>
	</div>
<?php 
include('footer.php');
?>
