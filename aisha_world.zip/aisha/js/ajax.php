<?php

if($_POST['action']=='contact_callback')
{
	echo "working...";
}

?>