<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
  <title>My Fast Food Factory </title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="js/script.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
	<div class="container" id="parent" >
		<header id="header" class="">
			<div class="row header_div">
				<div class="col-md-4 logo_name">
	              <img src="images/logo4.jpg" alt="">
	              <a class="navbar-brand" href="/aisha">Fast Foods Factory</a>
	            </div>

				<div class="col-md-4 seacrh">
	                  <input type="text" class="form-control" placeholder="Search...." ng-model="search">
	            </div>	
	            <div class="col-md-4 menu">
	            <ul>
	            	<li><a href="aboutus.php" ><b>About Us</b></a></li>
	            	<li><a href="contactus.php" ><b>Contact Us</b></a></li>
	            	<li><a href="careers.php"><b>Careers</b></a></li>
	            	<li><a href="login.php" ><b>Login</b></a></li>
	            	<li><a href="register.php" ><b>Register</b></a></li>
	            	<li><a href="profile.php" ><b>Profile</b></a></li>
	            </ul>	
				</div>
			</div>
		</header>
		<!-- /header -->

