<?php 
include('header.php');
// include('DB/db_func.php');
// $db_func = new DB_function();
	
$paper_id = 1;

$sql = "SELECT * FROM paper_size where paper_type_id=".$paper_id;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
     // echo "Paper type id: " . $row["paper_type_id"]. " - Size: " . $row["size"]. " - Color: " . $row["color"]. "<br>";
    }
} else {
    //echo "0 results";
}
//$conn->close();
?>
<div class="content">	
	<div>
		<form class="form-horizontal">
		<fieldset>
		<!-- Form Name -->
		<legend>Form Name</legend>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="full_name">Full Name</label>  
		  <div class="col-md-5">
		  <input id="full_name" name="full_name" type="text" placeholder="Enter your Full Name" class="form-control input-md" required="">
		    
		  </div>
		</div>

		<!-- Text input-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="email">Email Address</label>  
		  <div class="col-md-5">
		  <input id="email" name="email" type="text" placeholder="Enter Your Email Address" class="form-control input-md" required="">
		    
		  </div>
		</div>
		<!-- sELECT-->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="type">Select Printing Type</label>  
		  <div class="col-md-5">
		  	<select class="form-control input-md paper_type">
		  		<option value="">Choose Paper Type</option>
		  		<?php
		  		$sql = "SELECT * FROM paper_type";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					    // output data of each row
					    while($row = $result->fetch_assoc()) {
					        ?>
					        <option value="<?php echo $row["id"]; ?>"><?php echo $row["paperType"]; ?></option>
					        <?php
					    }
					} else {
					   ?>
					        <option value="">No Type Available</option>
					        <?php
					}
					?>

		  	</select>
		 
		  </div>
	
		    <div class="type_loader" style="display:none;">
		    	<img src="images/ajax-loader.gif">
		    </div>
	    	  <div class="type_resp" style="display:none; color: red;">
	    	  </div>

		</div>


		<div class="form-group paper_size_div" style="display:none;">
		  <label class="col-md-4 control-label" for="type">Select Printing Size</label>  
		  <div class="col-md-5">
		  	<select class="form-control input-md paper_size">
		  		<option value="">Choose Paper Size</option>
		  		
		  	</select>
		  </div>
		</div>


	
		<!-- Sign up -->
		<div class="form-group">
		  <label class="col-md-4 control-label" for="submit"></label>
		  <div class="col-md-4">
		  	<input type="submit" id="signup" name="signup" class="btn btn-primary" value="Register">
		  </div>
		</div>
		
		<div class="success_resp" style="display:none; color: red;"></div>
		    <div class="loader" style="display:none;">
		    	<img src="images/ajax-loader.gif">
			</div>
		</fieldset>
	</form>

	</div>

	<div>
		<legend>Deals</legend>
	    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p><span>
		<div class="row offers_div hidden"> 
            <div class="col-md-4 deals">
            	<legend>Deals</legend>
	            	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p><span>Price:$150</span>
            	<a href="">
	            	<div>
	            	<img src="images/logo4.jpg" alt="">
	            	</div>
            	</a>
            </div>
            <div class="col-md-4 offfer">
            	<legend>Offers</legend>
	            	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
	            	<span>Price:$150</span>
            	<a href="">
	            	<div>
	            	<img src="images/logo4.jpg" alt="">
	            	</div>
            	</a>
            </div>
            <div class="col-md-4 package">
	            <legend>Packages</legend>
	            	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
	            	<span>Price:$150</span>
	            <a href="">
	            	<div>
	            	<img src="images/logo4.jpg" alt="">
	            	</div>
	            </a>
            </div>
        </div>
   	 </div>
	</div>
<?php 
include('footer.php');
?>
