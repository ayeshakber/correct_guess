    <footer class="main-footer">
        <div class="footer-div">
            <div class="row info"> 
                <div class="col-md-4">
                    <strong>About us</strong>
                    <span>
                        <p>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                        </p>
                        
                    </span> 
                </div>
                <div class="col-md-4">
                    <strong>Follow us</strong>
                    <span>
                        <ul>
                            <li><a href="javascript:void(0);">Facebook</a></li>
                            <li><a href="javascript:void(0);">Twitter</a></li>
                            <li><a href="javascript:void(0);">LinkedIn</a></li>
                        </ul>
                    </span>
                </div>
                <div class="col-md-4">
                    <strong>Subscribe Now</strong><br>
                    <span>
                        <input type="text" name=""><br><br>
                        <input type="submit" name="" value="Submit">
                    </span>
                </div>
            </div> 


            <div class="row created-by"> 
                <div class="col-md-6 copyright">
                    <?php
                        echo 'All Rights Reserved &copy; 2016-'.date("Y");
                    ?>
                    
                </div>
                <div class="col-md-6 admin">
                    <strong><i>Designed & Developed by: Aisha Akber<br></i></strong>
                </div>
                
            </div> 
        </div>
    </footer>
    </div>
</body>
</html>
                
            
            
            
