<?php
$hostname = "localhost"; 
$username = "root";
$password = "g0lpik0!";
$DB = "food_demo";
// //connection to the database
// $conn = mysql_connect($hostname, $username, $password) 
//   or die("Unable to connect to MySQL");
// //echo "Connected to MySQL<br>";
// $selected = mysql_select_db("food_demo",$conn) 
//   or die("Could not select examples");



// Create connection
$conn = new mysqli($hostname, $username, $password,$DB);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";

?>