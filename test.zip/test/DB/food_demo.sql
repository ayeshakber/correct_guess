-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 01, 2018 at 06:15 PM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.25-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(8) NOT NULL,
  `name` varchar(125) DEFAULT NULL,
  `email` varchar(125) DEFAULT NULL,
  `subject` varchar(125) DEFAULT NULL,
  `msg` varchar(125) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `subject`, `msg`, `status`, `created`, `updated`) VALUES
(1, 'asdfsd', 'ayesha.aimiz@gmail.com', 'ayesha.aimiz@gmail.com', 'fsdfsd', NULL, '2017-05-08 08:35:18', '2017-05-08 08:35:18'),
(2, 'asas', 'dasda@gmail.com', 'dasda@gmail.com', 'lsdmfklsdf', NULL, '2017-05-08 08:37:33', '2017-05-08 08:37:33'),
(3, 'madiha', 'madiha@gmail.com', 'madiha@gmail.com', 'dfmlsd', NULL, '2017-05-08 08:38:13', '2017-05-08 08:38:13');

-- --------------------------------------------------------

--
-- Table structure for table `paper`
--

CREATE TABLE `paper` (
  `id` int(11) NOT NULL,
  `paperType` varchar(125) NOT NULL,
  `quality` varchar(125) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `status` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `paper_size`
--

CREATE TABLE `paper_size` (
  `id` int(11) NOT NULL,
  `paper_type_id` int(11) NOT NULL,
  `size` varchar(125) NOT NULL,
  `color` varchar(125) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paper_size`
--

INSERT INTO `paper_size` (`id`, `paper_type_id`, `size`, `color`, `created_at`, `updated_at`, `deleted_at`, `status`) VALUES
(1, 1, '10 x 30', 'red', '2018-03-01 00:00:00', '2018-03-01 07:43:48', '2018-03-01 00:00:00', 0),
(2, 2, '101 x 80', 'blue', '2018-03-01 00:00:00', '2018-03-01 07:44:07', '2018-03-01 00:00:00', 0),
(3, 1, '20 x 50', 'pink', '2018-03-01 00:00:00', '2018-03-01 07:44:40', '2018-03-01 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `paper_type`
--

CREATE TABLE `paper_type` (
  `id` int(11) NOT NULL,
  `paperType` varchar(125) NOT NULL,
  `quality` varchar(125) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `status` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paper_type`
--

INSERT INTO `paper_type` (`id`, `paperType`, `quality`, `created_at`, `updated_at`, `deleted_at`, `status`) VALUES
(1, 'plain', 'low', '2018-03-01 00:00:00', '2018-03-01 07:42:48', '2018-03-01 00:00:00', 0),
(2, 'glossary', 'high', '2018-03-01 00:00:00', '2018-03-01 07:42:57', '2018-03-01 00:00:00', 0),
(3, 'glass', 'nedium', NULL, '2018-03-01 09:48:59', NULL, 0),
(4, 'glass', 'nedium', NULL, '2018-03-01 09:56:17', NULL, 0),
(5, 'glass', 'nedium', NULL, '2018-03-01 09:57:55', NULL, 0),
(6, 'glass', 'nedium', NULL, '2018-03-01 10:01:12', NULL, 0),
(7, 'glass', 'nedium', NULL, '2018-03-01 10:02:51', NULL, 0),
(8, 'glass', 'nedium', NULL, '2018-03-01 10:03:00', NULL, 0),
(9, 'glass', 'nedium', NULL, '2018-03-01 10:12:21', NULL, 0),
(10, 'glass', 'nedium', NULL, '2018-03-01 10:12:22', NULL, 0),
(11, 'glass', 'nedium', NULL, '2018-03-01 10:12:22', NULL, 0),
(12, 'glass', 'nedium', NULL, '2018-03-01 10:12:23', NULL, 0),
(13, 'glass', 'nedium', NULL, '2018-03-01 10:12:23', NULL, 0),
(14, 'glass', 'nedium', NULL, '2018-03-01 10:13:28', NULL, 0),
(15, 'glass', 'nedium', NULL, '2018-03-01 10:16:42', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `subscribe_users`
--

CREATE TABLE `subscribe_users` (
  `id` int(8) NOT NULL,
  `email_address` varchar(125) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscribe_users`
--

INSERT INTO `subscribe_users` (`id`, `email_address`, `status`, `created`, `updated`) VALUES
(1, 'amna@gmail.com', NULL, '2017-05-08 11:52:22', '2017-05-08 11:52:22'),
(2, 'ali@gmail.com', NULL, '2017-05-08 12:24:47', '2017-05-08 12:24:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(8) NOT NULL,
  `full_name` varchar(125) DEFAULT NULL,
  `email` varchar(125) DEFAULT NULL,
  `username` varchar(125) DEFAULT NULL,
  `password` varchar(125) DEFAULT NULL,
  `job_title` varchar(125) DEFAULT NULL,
  `dob` varchar(125) DEFAULT NULL,
  `nic` varchar(125) DEFAULT NULL,
  `country` varchar(125) DEFAULT NULL,
  `city` varchar(125) DEFAULT NULL,
  `postal_code` int(8) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `user_desc` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `username`, `password`, `job_title`, `dob`, `nic`, `country`, `city`, `postal_code`, `address`, `user_desc`, `status`, `created`, `updated`) VALUES
(1, 'Ayesha AKber', 'ayesha@gmail.com', 'ayesha.aimviz', 'ayeshak123', 'PHP Developer', '2017-03-01', '4353464', 'Pakistan', 'Karac', 2147483647, 'Gulshan Block 6, Sindh2652', 'Im Smartl.25625', NULL, '2017-05-08 05:13:46', '2017-05-08 05:13:46'),
(2, 'ass', 'ass@gmail.com', 'asdfsdf', 'af4353', 'fdsfsdf', 'fsfs', '34235345', 'dfsdfsd', 'gfsdg', 53534, 'fsdfsdfsd', 'dgdfgdfg', NULL, '2017-05-08 08:59:36', '2017-05-08 08:59:36'),
(3, 'ssss', '', '', '', '', '', '', '', '', 0, '', '', NULL, '2017-05-08 10:29:55', '2017-05-08 10:29:55'),
(4, 'sdfsdfs', 'as@gmail.com', 'admfdsf', '123456789', 'asdfsfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsdf', 0, 'sdfsdf', 'sdfsdf', NULL, '2017-05-08 10:50:31', '2017-05-08 10:50:31'),
(5, 'SDFSDF', 'SDFSDF@GMAIL.COM', 'SFSFSDF', '1232435334646', 'SDFSDF', 'DFSDF', 'SDFSDF', 'SDFSDF', 'SDFSDF', 0, 'SDFSD', 'SDFSDF', NULL, '2017-05-08 10:52:29', '2017-05-08 10:52:29'),
(6, 'sdfsdf', 'sdfsdf@gmail.com', 'adsfdsdf', 'dfsdfsdfsdfsdf', 'sdfsdfsdf', 'sdfsdf', 'sdfsdf', 'sdfsd', 'sdfsdf', 0, 'sdfsd', 'sdfsdf', NULL, '2017-05-08 10:53:05', '2017-05-08 10:53:05'),
(7, 'SDFSDF', 'SDFSDF@gmail.com', 'SDFSDF', 'SDFSDFSDFSDFSDF', 'SDFSDF', 'SDF', 'SDFSDSD', 'SDFSDF', 'SDFSDF', 0, 'SDFSDF', 'SDFSDF', NULL, '2017-05-08 10:55:13', '2017-05-08 10:55:13'),
(8, 'SDFSDF', 'SDFSDF@gmail.com', 'SDFSDF', 'SDFSDFSDFSDFSDF', 'SDFSDF', 'SDF', '4353464', 'SDFSDF', 'SDFSDF', 0, 'SDFSDF', 'SDFSDF', NULL, '2017-05-08 10:55:24', '2017-05-08 10:55:24'),
(9, 'sdfsdf', 'sdfsdf@gmail.com', 'sdfsdfsdf', 'sdfsdfsdfsdf', 'sdfsdf', 'sdfsdf', '343536464', 'sdfsdf', 'sdfsd', 0, 'sdfsd', 'sdfsd', NULL, '2017-05-08 10:57:17', '2017-05-08 10:57:17'),
(10, 'alia', 'alia@gmail.com', 'fdfks', 'b88a4d411b826bee9a09a6e51716e1f8', 'sdfsdf', '2017-05-09', '4334545345345', 'Paksiatn', 'karahi', 34334, '5435g45', '45', NULL, '2017-05-08 13:02:41', '2017-05-08 13:02:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper`
--
ALTER TABLE `paper`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_size`
--
ALTER TABLE `paper_size`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_type`
--
ALTER TABLE `paper_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribe_users`
--
ALTER TABLE `subscribe_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `paper`
--
ALTER TABLE `paper`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `paper_size`
--
ALTER TABLE `paper_size`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `paper_type`
--
ALTER TABLE `paper_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `subscribe_users`
--
ALTER TABLE `subscribe_users`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
