<?php
//require 'DB/db_conn.php';
class DB_function
{

	//select all users
	// public function insert_paper($paperType,$quality)
	// {
		
	// 	$sql = "INSERT INTO paper_type (paperType, quality)
	// 	VALUES ('$paperType', '$quality')";

	// 	if ($conn->query($sql) === TRUE) {
	// 	    echo "New record created successfully";
	// 	} else {
	// 	    echo "Error: " . $sql . "<br>" . $conn->error;
	// 	}

	// 	$conn->close();
	// }

	//select all users
	public function select_all()
	{
		$res = mysql_query("SELECT * FROM users");
		return $res;
	}

	//select 1 user
	public function select_user($id)
	{
		$res = mysql_query("SELECT * FROM users WHERE id='$id'");
		return $res;
	}

	public function contact_us($name,$email,$subject,$msg)
	{
		$res = mysql_query("INSERT contact_us(name,email,subject,msg) VALUES('$name','$email','$email','$msg')");
		return $res;
	}
	//insert query
	public function insert_new_admin($username,$password)
	{
		$res = mysql_query("INSERT admin(username,password) VALUES('$username','$password')");
		
		//return $res;
	}

	//login query
	public function admin_login($username,$password)
	{

		$res=mysql_query("SELECT count(*) as countlogin FROM admin WHERE username='$username' AND password='$password'");
		//$row = mysql_fetch_assoc($res);
		return $res;
	}

}

?>