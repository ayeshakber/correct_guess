<?php 
include('header.php');
?>
<div class="content">
		<form class="form-horizontal">
			<fieldset>
				<!-- Form Name -->
				<legend>Login</legend>
				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="user_login">Username</label>  
				  <div class="col-md-5">
				  	<input id="user_login" name="user_login" type="text" placeholder="Enter Your Name" class="form-control input-md" required="">
				    
				  </div>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="login_pass">Password</label>  
				  <div class="col-md-5">
				  	<input id="login_pass" name="login_pass" type="text" placeholder="Enter Your Password" class="form-control input-md" required="">
				  </div>
				</div>
				<!-- Submit -->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="login_sub"></label>
				  <div class="col-md-4">
				  	<input type="submit" id="login_sub" name="login_sub" class="btn btn-primary" value="Sign in">
				  </div>
				</div>

			</fieldset>
		</form>
	</div>
<?php 
include('footer.php');
?>
