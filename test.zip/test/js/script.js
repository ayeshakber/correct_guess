
jQuery(document).ready(function ()
            {
              jQuery('.contact_loader').hide();
            	jQuery('.type_loader').hide();

              jQuery('.paper_type').on('change',function(){
                jQuery('.type_loader').show();
                ///alert('change');
                var type = jQuery(this).val();
               // console.log(type);

                $.ajax({
                 type: 'POST',
                 url: 'js/ajax.php',
                 data: {
                     'action': 'get_printing',
                      'type': type,
                    
                 },
                 success: function (data, textStatus, XMLHttpRequest) { 
                                   
                    console.log(data);
                    jQuery('.type_loader').hide(); //check stripe api
                    if(data !=0)
                    {
                        jQuery('.paper_size_div').show();
                        jQuery('.paper_size').html(data);
                    }
                    else
                    {
                      jQuery('.paper_size_div').hide();
                    }
                           
                           
                 },
                 error: function (MLHttpRequest, textStatus, errorThrown) {
                     console.log('Error '+errorThrown);
                 }

             });
    });






            });	//end jQuery