// CONTACT US 
function contact_us()
{
        document.getElementById('contact_loaders').style.display = 'block';

        var full_name = document.getElementById('contact_name').value;
          var email = document.getElementById('contact_email').value;
          var subject = document.getElementById('subject').value;
          var msg = document.getElementById('msg').value;
          var contacts = document.getElementById('contacts').value;
           //document.getElementById('contact_loader').show;
           if(full_name=="" || email=="" || subject=="" || msg==""){
          document.getElementById('contact_resps').style.display = 'block';
           document.getElementById("contact_resps").innerHTML='<h3>Required all fields</h3>';
        }
        else if (IsEmail(email)==false) {
            //jQuery('.response').show();
          document.getElementById('contact_resps').style.display = 'block';
          document.getElementById("contact_resps").innerHTML='<h3>Enter Valid Email Address</h3>';
        }
        else
        {

          // var ajax=false;
          // if(window.XMLHttpRequest){
          // ajax=new XMLHttpRequest();
          // }else{
          // ajax=new ActiveXObject("microsoft.XMLHTTP");
          // }
          // ajax.onreadystatechange=function(){
          //   if(ajax.readyState==4 && ajax.status==200){
          //     document.getElementById('contact_loaders').style.display = 'none';
          //     document.getElementById('contact_resps').style.display = 'block';
          //   document.getElementById("contact_resps").innerHTML=ajax.responseText;

          //   } 
          // }
          // ajax.open("get","js/ajax.php?full_name="+full_name+"&email="+email+"&subject="+subject+"&msg="+msg+"&contacts="+contacts,true);
          // ajax.send();

          ///////////////////////////////
           $.ajax({
           type: 'GET',
           url: 'js/ajax.php',
           data: {
             full_name:full_name,
             email:email,
             subject:subject,
             msg:msg,
           },
           success:function(data,textStatus,XMLHTTPRequest){
           console.log(data);
             // console.log(textStatus);
             // console.log(XMLHTTPRequest);
             // alert('done');
        // document.getElementById('contact_loaders').style.display = 'none';
        //       document.getElementById('contact_resps').style.display = 'block';
        //     document.getElementById("contact_resps").innerHTML=ajax.responseText;

           },
           error:function(XMLHTTPRequest,textStatus,errorThrown){
             console.log(errorThrown);
             console.log(textStatus);
             console.log(XMLHTTPRequest);
             
           }
         });
          ///////////////////////////////
      }
  
}


//////////////////////////
/////////////////////////
/////////////////////////
/////////////////////////






              /* In front end of WordPress we have to define ajaxurl */
                //var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
                jQuery('#contact').on('click', function (e)
                {
                    /* You can get this value from some hidden field or div */
                    e.preventDefault();
                    alert('working here........');
                    jQuery('.contact_loader').show();
                   /* var url = '<?php echo site_url(); ?>';
                    url = url+'/my-login/';*/
                    var full_name = jQuery('.contact_name').val();
                    var email = jQuery('.contact_email').val();
                    var username = jQuery('.subject').val();
                    var pwd = jQuery('.msg').val();
                     /*var data = {
                          'action': 'e_submit',
                          'contact_name': contact_name,
                          'contact_email': contact_email,
                          'subject': subject,
                          'msg': msg,
                      };
                      $.post(ajaxurl, data, function (response)
                      {
                          jQuery('.contact_loader').hide(); //check stripe api
                          jQuery('.contact_resp').show();
                          jQuery('.contact_resp').html(response);
                          if (callback == 'user_done')
                          {
                            setTimeout(function()
                            {
                               window.location.href = url;
                            },1000);
                          }
                      });*/
                      ///////////////////
                  $.ajax({
                 type: 'POST',
                 url: 'ajax.php',
                 data: {
                     'action': 'contact_callback',
                      'contact_name': contact_name,
                      'contact_email': contact_email,
                      'subject': subject,
                      'msg': msg
                 },
                 success: function (data, textStatus, XMLHttpRequest) { 
                                   
                    console.log(data);
                    console.log(textStatus);
                    console.log(XMLHttpRequest);
                    jQuery('.contact_loader').hide(); //check stripe api
                            jQuery('.contact_resp').show();
                            jQuery('.contact_resp').html(response);
                            if (callback == 'user_done')
                            {
                              setTimeout(function()
                              {
                                 window.location.href = url;
                              },1000);
                            }
                 },
                 error: function (MLHttpRequest, textStatus, errorThrown) {
                     console.log('Error '+errorThrown);
                 }

             });
                      ////////////////////
                    
                }); //e sub end