<?php
require '../DB/db_conn.php';
if($_POST['action']=='get_printing')
{
	
	$paper_id  = $_POST['type'];

	$html = '';
	$sql = "SELECT * FROM paper_size where paper_type_id=".$paper_id;
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {

		// echo "working...after select...";
		// echo $paper_id;
		// print_r($result);
		//die;
	    // output data of each row
	     $html .= '<option value="">Choose Paper Size</option>';
	    while($row = $result->fetch_assoc()) {
	      //echo "Paper type id: " . $row["paper_type_id"]. " - Size: " . $row["size"]. " - Color: " . $row["color"]. "<br>";
	      $html .= '<option value="'.$row["id"].'">'.$row["size"].'</option>';
	    }
	} else {
	    $html .= "0";
	}
	//$conn->close();

	echo $html;
}



?>