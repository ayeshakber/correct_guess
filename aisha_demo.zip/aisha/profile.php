<?php 
//session_start();
include('header.php');
include('DB/db_conn.php');
include('DB/db_func.php');
$user_id = $_SESSION["user_id"];
$db_func = new DB_function();
//$res = $db_func->select_all();
$res = $db_func->select_user($user_id);
$arr = array();
$i=0;
while ($row = mysql_fetch_assoc($res)) 
{
	$arr[$i]['id'] =$row['id'];
	$arr[$i]['full_name'] =$row['full_name'];
	$arr[$i]['email'] =$row['email'];
	$arr[$i]['username'] =$row['username'];
	$arr[$i]['job_title'] =$row['job_title'];
	$arr[$i]['dob'] =$row['dob'];
	$arr[$i]['nic'] =$row['nic'];
	$arr[$i]['country'] =$row['country'];
	$arr[$i]['city'] =$row['city'];
	$arr[$i]['postal_code'] =$row['postal_code'];
	$arr[$i]['address'] =$row['address'];
	$arr[$i]['user_desc'] =$row['user_desc'];
	++$i; 
}
//print_r($arr);
?>
<style>
    /* Style the tab */
    div.tab {
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
    }
    /* Style the buttons inside the tab */
    div.tab button {
        background-color: inherit;
        float: left;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 16px;
        transition: 0.3s;
    }
    /* Change background color of buttons on hover */
    div.tab button:hover {
        background-color: #ddd;
    }
    /* Create an active/current tablink class */
    div.tab button.active {
        background-color: #ccc;
    }
    /*Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #ccc;
        border-top: none;
    }
  </style>
  <script>
  function openTabs(evt, tabName)
  {
    // Declare all variables
    var i, tabcontent, tablinks;
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
 }
  </script>
<div class="content">
	<legend>My Profile</legend>
	<div class="profile_info">
		    <div class="tab">
		      <button class="tablinks active" onclick="openTabs(event, 'View')">View</button>
		      <button class="tablinks" onclick="openTabs(event, 'Edit')">Edit</button>
		      <button class="tablinks" onclick="openTabs(event, 'Orders')">Orders</button>
		    </div>
		<div id="View" class="tabcontent" style="display:block;">	
			<h2>Details</h2>	    
			<fieldset>
				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_full_name">Full Name</label>  
				  <span><?php print_r($arr[0]['full_name']); ?></span>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_email">Email Address</label>  
				  <span><?php print_r($arr[0]['email']); ?></span>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_username">Username</label>  
				  <span><?php print_r($arr[0]['username']); ?></span>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_job">Job Designation</label>  
				  <span><?php print_r($arr[0]['job_title']); ?></span>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_dob">Date of Birth</label>  
				  <span><?php print_r($arr[0]['dob']); ?></span>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_nic">ID Card Number</label>  
				  <span><?php print_r($arr[0]['nic']); ?></span>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_country">Country</label>  
				  <span><?php print_r($arr[0]['country']); ?></span>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_city">City</label>  
				  <span><?php print_r($arr[0]['city']); ?></span>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_postal_code">Postal Code</label>  
				  <span><?php print_r($arr[0]['postal_code']); ?></span>
				</div>

				<!-- Text input-->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_address">Address</label>  
				  <span><?php print_r($arr[0]['address']); ?></span>
				</div>
				
				<!-- Textarea -->
				<div class="form-group">
				  <label class="col-md-4 control-label" for="view_USER_DESC">About Myself</label>
				  <p><?php print_r($arr[0]['user_desc']); ?></p>                    
				</div>
			</fieldset>
		</div>

		<div id="Edit" class="tabcontent">
			<h2>Edit Info</h2>
			<form class="form-horizontal" method="POST" action="" class="signup_form" enctype="multipart/form-data">
				<fieldset>
					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_full_name">Full Name</label>  
					 	<input id="edit_full_name" name="edit_full_name" type="text" class="form-control input-md" value="<?php print_r($arr[0]['full_name']); ?>">	
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_email">Email Address</label>  
					  <input id="edit_email" name="edit_email" type="email" class="form-control input-md" value="<?php print_r($arr[0]['email']); ?>" disabled>
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_username">Username</label>
					   <input id="edit_Username" name="edit_Username" type="text" class="form-control input-md" value="<?php print_r($arr[0]['username']); ?>" disabled>  
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_job">Job Designation</label>
					   <input id="edit_job" name="edit_job" type="text" class="form-control input-md" value="<?php print_r($arr[0]['job_title']); ?>">  
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_dob">Date of Birth</label>  
					   <input id="edit_dob" name="edit_dob" type="date" class="form-control input-md" value="<?php print_r($arr[0]['dob']); ?>">
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_nic">ID Card Number</label> 
					  <input id="edit_nic" name="edit_nic" type="text" class="form-control input-md" value="<?php print_r($arr[0]['nic']); ?>"> 
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_country">Country</label>  
					   <input id="edit_country" name="edit_country" type="text" class="form-control input-md" value="<?php print_r($arr[0]['country']); ?>">
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_city">City</label> 
					   <input id="edit_city" name="edit_city" type="text" class="form-control input-md" value="<?php print_r($arr[0]['city']); ?>"> 
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_postal_code">Postal Code</label>
					   <input id="edit_postal_code" name="edit_postal_code" type="text" class="form-control input-md" value="<?php print_r($arr[0]['postal_code']); ?>">
					</div>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_address">Address</label>  
					   <input id="edit_address" name="edit_address" type="text" class="form-control input-md" value="<?php print_r($arr[0]['address']); ?>">
					</div>
					
					<!-- Textarea -->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="edit_user_desc">About Myself</label>
					  <textarea class="form-control" id="edit_user_desc" name="edit_user_desc" rows="5" cols="50" value="<?php print_r($arr[0]['user_desc']); ?>"><?php print_r($arr[0]['user_desc']); ?></textarea>
					</div>

					<!-- Sign up -->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="submit"></label>
					  <div class="col-md-4">
					  	<input type="button" id="edit_pro" name="edit_pro" class="btn btn-primary" value="Update" onclick="user_update_profile();">
					  </div>
					</div>
					
					<div class="edit_resp" id="edit_resps" style="display:none; color: red;"></div>
					<div class="edit_loader" style="display:none;">
				    	<img src="images/ajax-loader.gif">
					</div>

				</fieldset>
			</form>
		</div>

		<div id="Orders" class="tabcontent">
		<h2>My order</h2>
		<h4>My all order goes here...</h4>
		</div>
	<!--  -->
	<!--  -->
	</div>
	
</div>
<?php 
include('footer.php');
?>
