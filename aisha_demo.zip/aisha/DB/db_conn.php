<?php
$hostname = "localhost"; 
$username = "root";
$password = "";
//connection to the database
$conn = mysql_connect($hostname, $username, $password) 
  or die("Unable to connect to MySQL");
//echo "Connected to MySQL<br>";
$selected = mysql_select_db("food_demo",$conn) 
  or die("Could not select examples");
  ?>