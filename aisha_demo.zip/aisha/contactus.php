<?php 
include('header.php');
include('DB/db_conn.php');
include('DB/db_func.php');
$db_func = new DB_function();
?>
<div class="content">
		<!--  -->
		<!--  -->
		<!--  -->
	<form class="form-horizontal" method="POST" action="" name="contact_user">
		<fieldset>
			<!-- Form Name -->
			<legend>Contact Us</legend>
			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="contact_name">Name</label>  
			  <div class="col-md-5">
			  	<input id="contact_name" name="contact_name" type="text" placeholder="Enter Your Full Name" class="form-control input-md" required="">
			    
			  </div>
			</div>

			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="contact_email">Email</label>  
			  <div class="col-md-5">
			  <input id="contact_email" name="contact_email" type="text" placeholder="Enter Your Email Address" class="form-control input-md" required="">
			    
			  </div>
			</div>

			<!-- Text input-->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="subject">Subject</label>  
			  <div class="col-md-5">
			  <input id="subject" name="subject" type="text" placeholder="WriteYour Subject" class="form-control input-md" required="">
			    
			  </div>
			</div>

			<!-- Textarea -->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="msg">Your Message</label>
			  <div class="col-md-4">                     
			    <textarea class="form-control" id="msg" name="msg"></textarea>
			  </div>
			</div>

			<!-- Button -->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="contact"></label>
			  <div class="col-md-4">
			  <input type="button" id="contacts" class="contact" name="contact" class="btn btn-primary" value="Submit" onclick="contact_us();">
			  </div>
			</div>

			<div class="contact_resp" id="contact_resps" style="display:none; color: red;"></div>
		    <div class="contact_loader" id="contact_loaders" style="display:none;">
		    	<img src="images/ajax-loader.gif">
		    </div>

		</fieldset>
	</form>
	<?php
				/*if (isset($_POST['contact'])) 
				{
					$name=$_POST['contact_name'];
					$email=$_POST['contact_email'];
					$subject=$_POST['subject'];
					$msg=$_POST['msg'];
					$is_form_submit=true;
					$admin_email ="ayeshakber.cs2011@gmail.com";
					

					if ($is_form_submit==true) 
					{

						$contact = $db_func->contact_us($name,$email,$subject,$msg);	
						echo " Your Message has been sent!.";
						//sending email
						//mail($to,$subject,$msg,$headers);	-->mail function 
						if(mail($admin_email, $subject, $msg, $email))
						{
							echo "Mail Sent";;
						}
						else
						{
							echo "Not Sent";
						}
				
				}
			}*/
				?>

		<!--  -->
		<!--  -->
		<!--  -->
	</div>
<?php 
include('footer.php');
?>
