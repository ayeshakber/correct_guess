    
    </div> <!-- container -->
    <footer class="main-footer">
        <div class="footer-div">
            <div class="row info"> 
                <div class="col-md-4">
                    <strong>About Us</strong>
                    <span>
                        <p>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                        </p>
                        
                    </span> 
                </div>
                <div class="col-md-4">
                    <strong>Follow us</strong>
                    <span>
                        <ul>
                            <li><a href="javascript:void(0);">Facebook</a></li>
                            <li><a href="javascript:void(0);">Twitter</a></li>
                            <li><a href="javascript:void(0);">LinkedIn</a></li>
                        </ul>
                    </span>
                </div>

                <div class="col-md-4">
                    <strong>Subscribe Now</strong><br>
                    <span>
                    <form method="POST" action="" class="subcriber" enctype="multipart/form-data">
                        <input type="text" name="email" id="subs_emails" class="subs_email"><br><br>
                        <input type="button" name="subs_submit" id="subs_submit"
                        value="Submit" onclick="subscribe_user();">
                        <span id="subs_msg" style="display:none; color: green;"></span>
                    </form>
                    </span>
                </div>
                
            </div> 


            <div class="row created-by"> 
                <div class="col-md-6 copyright">
                    <?php
                        echo 'All Rights Reserved &copy; 2016-'.date("Y");
                    ?>
                    
                </div>
                <div class="col-md-6 admin">
                    <strong><i>Designed & Developed by: Aisha Akber (PHP Developer)<br></i></strong>
                </div>
                
            </div> 
        </div>
    </footer>
</body>
</html>
                
            
            
            
