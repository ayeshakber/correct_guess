
//REGISTER 
function IsEmail(email) 
{
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
 }

function register()
{
    //document.getElementById('contact_loaders').style.display = 'block';

      var full_name = document.getElementById('full_name').value;
      var email = document.getElementById('email').value;
      var Username = document.getElementById('Username').value;
      var password = document.getElementById('password').value;
      var job = document.getElementById('job').value;
      var dob = document.getElementById('dob').value;
      var nic = document.getElementById('nic').value;
      var country = document.getElementById('country').value;
      var city = document.getElementById('city').value;
      var postal_code = document.getElementById('postal_code').value;
      var address = document.getElementById('address').value;
      var USER_DESC = document.getElementById('USER_DESC').value;
      var signups = document.getElementById('signups').value;

      if(full_name==''){
         document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('full_name').style.borderColor = "red";
      }
      else{
        document.getElementById('full_name').style.borderColor = "gray";
      }
      if(email==''){
        document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('email').style.borderColor = "red";
      }
      else{
        document.getElementById('email').style.borderColor = "gray";
      }
      if(Username==''){
        document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('Username').style.borderColor = "red";

      }
      else{
         document.getElementById('Username').style.borderColor = "gray";
      }
      if(password==''){
        document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('password').style.borderColor = "red";
      }
      else{
         document.getElementById('password').style.borderColor = "gray";
      }
      if(job==''){
         document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('job').style.borderColor = "red";
      }
      else{
         document.getElementById('job').style.borderColor = "gray";
      }
      if(dob==''){
          document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('dob').style.borderColor = "red";
      }
      else{
         document.getElementById('dob').style.borderColor = "gray";
      }
      if(nic==''){
          document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('nic').style.borderColor = "red";
      }
      else{
         document.getElementById('nic').style.borderColor = "gray";
      }
      if(country==''){
          document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('country').style.borderColor = "red";
      }
      else{
         document.getElementById('country').style.borderColor = "gray";
      }
      if(city==''){
          document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('city').style.borderColor = "red";
      }
      else{
         document.getElementById('city').style.borderColor = "gray";
      }
      if(address==''){
          document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('address').style.borderColor = "red";
      }
      else{
         document.getElementById('address').style.borderColor = "gray";
      }
      if(postal_code==''){
          document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('postal_code').style.borderColor = "red";
      }
      else{
         document.getElementById('postal_code').style.borderColor = "gray";
      }
      if(USER_DESC==""){
         document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
         document.getElementById('USER_DESC').style.borderColor = "red";

      }else{
 document.getElementById('USER_DESC').style.borderColor = "gray";
      }
      
      if(full_name=="" || email=="" || Username=="" || password=="" || job=="" || dob=="" || nic=="" || country=="" || city=="" || address=='' || postal_code=="" || USER_DESC==""){
        document.getElementById('success_resps').style.display = 'block';
         document.getElementById("success_resps").innerHTML='Required all fields';
      }
      else if (IsEmail(email)==false) {
                      //jQuery('.response').show();
                document.getElementById('success_resps').style.display = 'block';
                document.getElementById("success_resps").innerHTML='Enter Valid Email';
      }
      else if(password.length<=8){
        document.getElementById('success_resps').style.display = 'block';
                document.getElementById("success_resps").innerHTML='Password should be greater then 8 character';
      }
      //var n1 = document.getElementById("num1");

    //sum = Number(nic);
    //console
   else if(isNaN(Number(document.getElementById('nic').value))) {
        document.getElementById('success_resps').style.display = 'block';
                document.getElementById("success_resps").innerHTML='ID Card Number Should be only number ';
         
    }
    else if(isNaN(Number(document.getElementById('postal_code').value))) {
        document.getElementById('success_resps').style.display = 'block';
                document.getElementById("success_resps").innerHTML='Postal Code Should be only number';
         
    }
      else{

        var ajax=false;
        if(window.XMLHttpRequest){
        ajax=new XMLHttpRequest();
        }else{
        ajax=new ActiveXObject("microsoft.XMLHTTP");
        }
        ajax.onreadystatechange=function(){
          if(ajax.readyState==4 && ajax.status==200){
          //  document.getElementById('contact_loaders').style.display = 'none';
            document.getElementById('success_resps').style.display = 'block';
          document.getElementById("success_resps").innerHTML=ajax.responseText;

          } 
        }
        ajax.open("get","js/ajax.php?full_name="+full_name+"&email="+email+"&Username="+Username+"&password="+password+"&job="+job+"&dob="+dob+"&nic="+nic+"&country="+country+"&city="+city+"&postal_code="+postal_code+"&address="+address+"&USER_DESC="+USER_DESC+"&signups="+signups,true);
        ajax.send();
      }
       //document.getElementById('contact_loader').show;


        // hide the lorem ipsum text
        //document.getElementById('contact_loader').style.display = 'none';
  
  
}

//login function 
function user_logins()
{
    //document.getElementById('contact_loaders').style.display = 'block';

      var user_login = document.getElementById('user_login').value;
      var login_pass = document.getElementById('login_pass').value;
      var login_sub = document.getElementById('login_sub').value;
       //document.getElementById('contact_loader').show;


        // hide the lorem ipsum text
        //document.getElementById('contact_loader').style.display = 'none';
  var ajax=false;
  if(window.XMLHttpRequest){
  ajax=new XMLHttpRequest();
  }else{
  ajax=new ActiveXObject("microsoft.XMLHTTP");
  }
  ajax.onreadystatechange=function(){
    if(ajax.readyState==4 && ajax.status==200){
    //  document.getElementById('contact_loaders').style.display = 'none';
      document.getElementById('success_resps').style.display = 'block';
    
    if(ajax.responseText!="welcome"){
      document.getElementById("success_resps").innerHTML=ajax.responseText;
    }
    else{
      window.location="http://localhost/aisha/profile.php";
    }
    } 
  }
  ajax.open("get","js/ajax.php?user_login="+user_login+"&login_pass="+login_pass+"&login_sub="+login_sub,true);
  ajax.send();
  
}
// update profile
function user_update_profile()
{
    //document.getElementById('contact_loaders').style.display = 'block';

      var edit_full_name = document.getElementById('edit_full_name').value;
      var edit_job = document.getElementById('edit_job').value;
      var edit_dob = document.getElementById('edit_dob').value;
      var edit_nic = document.getElementById('edit_nic').value;
      var edit_country = document.getElementById('edit_country').value;
      var edit_city = document.getElementById('edit_city').value;
      var edit_postal_code = document.getElementById('edit_postal_code').value;
      var edit_address = document.getElementById('edit_address').value;
      var edit_user_desc = document.getElementById('edit_user_desc').value;
      
      var edit_pro = document.getElementById('edit_pro').value;
       //document.getElementById('contact_loader').show;


        // hide the lorem ipsum text
        //document.getElementById('contact_loader').style.display = 'none';
        if(edit_full_name=="" || edit_job=="" || edit_dob=="" || edit_nic=="" || edit_country=="" || edit_city=="" || edit_postal_code=="" || edit_address=="" || edit_user_desc==""){
        document.getElementById('edit_resps').style.display = 'block';
         document.getElementById("edit_resps").innerHTML='Required all fields';
      }
      else if(isNaN(Number(document.getElementById('edit_nic').value))) {
        document.getElementById('edit_resps').style.display = 'block';
                document.getElementById("edit_resps").innerHTML='ID Card Number Should be only number ';
         
    }
    else if(isNaN(Number(document.getElementById('edit_postal_code').value))) {
        document.getElementById('edit_resps').style.display = 'block';
                document.getElementById("edit_resps").innerHTML='Postal Code Should be only number';
         
    }
      else{
         var ajax=false;
          if(window.XMLHttpRequest){
          ajax=new XMLHttpRequest();
          }else{
          ajax=new ActiveXObject("microsoft.XMLHTTP");
          }
          ajax.onreadystatechange=function(){
            if(ajax.readyState==4 && ajax.status==200){
            //  document.getElementById('contact_loaders').style.display = 'none';
             
               document.getElementById('edit_resps').style.display = 'block';
              if(ajax.responseText!="success"){
                
                document.getElementById("edit_resps").innerHTML=ajax.responseText;
              }
              else{
                document.getElementById("edit_resps").innerHTML='Profile has been updated';
                
                  
                setTimeout(function(){ window.location="http://localhost/aisha/profile.php";   }, 1000);
                
              }
            } 
          }
          ajax.open("get","js/ajax.php?edit_full_name="+edit_full_name+"&edit_job="+edit_job+"&edit_dob="+edit_dob+"&edit_nic="+edit_nic+"&edit_country="+edit_country+"&edit_city="+edit_city+"&edit_postal_code="+edit_postal_code+"&edit_address="+edit_address+"&edit_user_desc="+edit_user_desc+"&edit_pro="+edit_pro,true);
          ajax.send();
      }
 
  
}
// CONTACT US 
function contact_us()
{
        document.getElementById('contact_loaders').style.display = 'block';

        var full_name = document.getElementById('contact_name').value;
          var email = document.getElementById('contact_email').value;
          var subject = document.getElementById('subject').value;
          var msg = document.getElementById('msg').value;
          var contacts = document.getElementById('contacts').value;
           //document.getElementById('contact_loader').show;
           if(full_name=="" || email=="" || subject=="" || msg==""){
          document.getElementById('contact_resps').style.display = 'block';
           document.getElementById("contact_resps").innerHTML='<h3>Required all fields</h3>';
        }
        else if (IsEmail(email)==false) {
            //jQuery('.response').show();
          document.getElementById('contact_resps').style.display = 'block';
          document.getElementById("contact_resps").innerHTML='<h3>Enter Valid Email Address</h3>';
        }
        else
        {

          var ajax=false;
          if(window.XMLHttpRequest){
          ajax=new XMLHttpRequest();
          }else{
          ajax=new ActiveXObject("microsoft.XMLHTTP");
          }
          ajax.onreadystatechange=function(){
            if(ajax.readyState==4 && ajax.status==200){
              document.getElementById('contact_loaders').style.display = 'none';
              document.getElementById('contact_resps').style.display = 'block';
            document.getElementById("contact_resps").innerHTML=ajax.responseText;

            } 
          }
          ajax.open("get","js/ajax.php?full_name="+full_name+"&email="+email+"&subject="+subject+"&msg="+msg+"&contacts="+contacts,true);
          ajax.send();
      }
  
}


//subscriber
function subscribe_user()
{
    
      var subs_emails = document.getElementById('subs_emails').value;
      var subs_submit = document.getElementById('subs_submit').value;
    var ajax=false;
    if(window.XMLHttpRequest){
    ajax=new XMLHttpRequest();
    }else{
    ajax=new ActiveXObject("microsoft.XMLHTTP");
    }
    ajax.onreadystatechange=function(){
      if(ajax.readyState==4 && ajax.status==200){
      //  document.getElementById('contact_loaders').style.display = 'none';
        document.getElementById('subs_msg').style.display = 'block';
      
        document.getElementById("subs_msg").innerHTML=ajax.responseText;
      
      } 
    }
  ajax.open("get","js/ajax.php?subs_emails="+subs_emails+"&subs_submit="+subs_submit,true);
  ajax.send();
  
}