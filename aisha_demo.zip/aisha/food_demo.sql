/*
SQLyog Ultimate v11.11 (32 bit)
MySQL - 5.6.26 : Database - food_demo
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`food_demo` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `food_demo`;

/*Table structure for table `contact_us` */

DROP TABLE IF EXISTS `contact_us`;

CREATE TABLE `contact_us` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(125) DEFAULT NULL,
  `email` varchar(125) DEFAULT NULL,
  `subject` varchar(125) DEFAULT NULL,
  `msg` varchar(125) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `contact_us` */

insert  into `contact_us`(`id`,`name`,`email`,`subject`,`msg`,`status`,`created`,`updated`) values (1,'asdfsd','ayesha.aimiz@gmail.com','ayesha.aimiz@gmail.com','fsdfsd',NULL,'2017-05-08 13:35:18','2017-05-08 13:35:18'),(2,'asas','dasda@gmail.com','dasda@gmail.com','lsdmfklsdf',NULL,'2017-05-08 13:37:33','2017-05-08 13:37:33'),(3,'madiha','madiha@gmail.com','madiha@gmail.com','dfmlsd',NULL,'2017-05-08 13:38:13','2017-05-08 13:38:13');

/*Table structure for table `subscribe_users` */

DROP TABLE IF EXISTS `subscribe_users`;

CREATE TABLE `subscribe_users` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `email_address` varchar(125) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `subscribe_users` */

insert  into `subscribe_users`(`id`,`email_address`,`status`,`created`,`updated`) values (1,'amna@gmail.com',NULL,'2017-05-08 16:52:22','2017-05-08 16:52:22'),(2,'ali@gmail.com',NULL,'2017-05-08 17:24:47','2017-05-08 17:24:47');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(125) DEFAULT NULL,
  `email` varchar(125) DEFAULT NULL,
  `username` varchar(125) DEFAULT NULL,
  `password` varchar(125) DEFAULT NULL,
  `job_title` varchar(125) DEFAULT NULL,
  `dob` varchar(125) DEFAULT NULL,
  `nic` varchar(125) DEFAULT NULL,
  `country` varchar(125) DEFAULT NULL,
  `city` varchar(125) DEFAULT NULL,
  `postal_code` int(8) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `user_desc` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`id`,`full_name`,`email`,`username`,`password`,`job_title`,`dob`,`nic`,`country`,`city`,`postal_code`,`address`,`user_desc`,`status`,`created`,`updated`) values (1,'Ayesha AKber','ayesha@gmail.com','ayesha.aimviz','ayeshak123','PHP Developer','2017-03-01','4353464','Pakistan','Karac',2147483647,'Gulshan Block 6, Sindh2652','Im Smartl.25625',NULL,'2017-05-08 10:13:46','2017-05-08 10:13:46'),(2,'ass','ass@gmail.com','asdfsdf','af4353','fdsfsdf','fsfs','34235345','dfsdfsd','gfsdg',53534,'fsdfsdfsd','dgdfgdfg',NULL,'2017-05-08 13:59:36','2017-05-08 13:59:36'),(3,'ssss','','','','','','','','',0,'','',NULL,'2017-05-08 15:29:55','2017-05-08 15:29:55'),(4,'sdfsdfs','as@gmail.com','admfdsf','123456789','asdfsfsdf','sdfsdf','sdfsdf','sdfsdf','sdfsdf',0,'sdfsdf','sdfsdf',NULL,'2017-05-08 15:50:31','2017-05-08 15:50:31'),(5,'SDFSDF','SDFSDF@GMAIL.COM','SFSFSDF','1232435334646','SDFSDF','DFSDF','SDFSDF','SDFSDF','SDFSDF',0,'SDFSD','SDFSDF',NULL,'2017-05-08 15:52:29','2017-05-08 15:52:29'),(6,'sdfsdf','sdfsdf@gmail.com','adsfdsdf','dfsdfsdfsdfsdf','sdfsdfsdf','sdfsdf','sdfsdf','sdfsd','sdfsdf',0,'sdfsd','sdfsdf',NULL,'2017-05-08 15:53:05','2017-05-08 15:53:05'),(7,'SDFSDF','SDFSDF@gmail.com','SDFSDF','SDFSDFSDFSDFSDF','SDFSDF','SDF','SDFSDSD','SDFSDF','SDFSDF',0,'SDFSDF','SDFSDF',NULL,'2017-05-08 15:55:13','2017-05-08 15:55:13'),(8,'SDFSDF','SDFSDF@gmail.com','SDFSDF','SDFSDFSDFSDFSDF','SDFSDF','SDF','4353464','SDFSDF','SDFSDF',0,'SDFSDF','SDFSDF',NULL,'2017-05-08 15:55:24','2017-05-08 15:55:24'),(9,'sdfsdf','sdfsdf@gmail.com','sdfsdfsdf','sdfsdfsdfsdf','sdfsdf','sdfsdf','343536464','sdfsdf','sdfsd',0,'sdfsd','sdfsd',NULL,'2017-05-08 15:57:17','2017-05-08 15:57:17'),(10,'alia','alia@gmail.com','fdfks','b88a4d411b826bee9a09a6e51716e1f8','sdfsdf','2017-05-09','4334545345345','Paksiatn','karahi',34334,'5435g45','45',NULL,'2017-05-08 18:02:41','2017-05-08 18:02:41');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
