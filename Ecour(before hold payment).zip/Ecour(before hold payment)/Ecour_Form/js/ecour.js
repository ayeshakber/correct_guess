/*function initAutocomplete() {
    var map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: -33.8688, lng: 151.2195},
        zoom: 13,
        mapTypeId: 'roadmap'
    });

    // Create the search box and link it to the UI element.
    var input = document.getElementById('pac-input');
    var searchBox = new google.maps.places.SearchBox(input);
    map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

    // Bias the SearchBox results towards current map's viewport.
    map.addListener('bounds_changed', function() {
        searchBox.setBounds(map.getBounds());
    });

    var markers = [];
    // Listen for the event fired when the user selects a prediction and retrieve
    // more details for that place.
    searchBox.addListener('places_changed', function() {
        var places = searchBox.getPlaces();

        if (places.length == 0) {
            return;
        }

        // Clear out the old markers.
       /* markers.forEach(function(marker) {
            marker.setMap(null);
        });
        markers = [];
*/
        // For each place, get the icon, name and location.
      /*  var bounds = new google.maps.LatLngBounds();
        places.forEach(function(place) {
            if (!place.geometry) {
                console.log("Returned place contains no geometry");
                return;
            }
            var icon = {
                url: place.icon,
                size: new google.maps.Size(71, 71),
                origin: new google.maps.Point(0, 0),
                anchor: new google.maps.Point(17, 34),
                scaledSize: new google.maps.Size(25, 25)
            };

            // Create a marker for each place.
            markers.push(new google.maps.Marker({
                map: map,
                icon: icon,
                title: place.name,
                position: place.geometry.location
            }));

            if (place.geometry.viewport) {
                // Only geocodes have viewport.
                bounds.union(place.geometry.viewport);
            } else {
                bounds.extend(place.geometry.location);
            }
        });
        map.fitBounds(bounds);
    });
}*/
////////////////////////////////

jQuery(document).ready(function()
{

    /*/////// START MAP LOCATION ////////
    var options = {
        map: ".map_canvas"
    };

    jQuery("#geocomplete").geocomplete(options)
        .bind("geocode:result", function(event, result){
            $.log("Result: " + result.formatted_address);
        })
        .bind("geocode:error", function(event, status){
            $.log("ERROR: " + status);
        })
        .bind("geocode:multiple", function(event, results){
            $.log("Multiple: " + results.length + " results found");
        });
*/
    /////// END MAP LOCATION ////////

///////DONE DONE DONE ////////////////
    jQuery('#create_loader').hide();
    jQuery('#strip_acoount_detail').hide();
    jQuery('#existing_account').on('click',function ()
        {
            jQuery('#strip_acoount_detail').show();

        });

    //START IMAGE PREVIEW
    function readURL(input)
    {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#drag_img').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#photo").change(function(){
        readURL(this);
    });
///////DONE DONE DONE ////////////////

//END IMAGE PREVIEW

    // This example adds a search box to a map, using the Google Place Autocomplete
    // feature. People can enter geographical searches. The search box will return a
    // pick list containing a mix of places and predicted search terms.

    // This example requires the Places library. Include the libraries=places
    // parameter when you first load the API. For example:
    // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

    ////////////DONE DONE DONE ///////////////
    jQuery('#strip_api_submit').on('click',function(e)
    {
        jQuery('#strip_loader').show();
        e.preventDefault();

        var strip_api = jQuery('#strip_api').val();
        console.log(strip_api);

        jQuery.ajax
        ({
            type:'POST',
            // url:ajax_call_ecour.ajaxurl_ecour,
            url:'Ecour_Form.php',
             data :
            // action:'account_check', //ajax call function name
                 'strip_api='+strip_api,
               //DATA END

            success:function(data,textStatus,XMLHTTPRequest)
            {
                jQuery('#strip_loader').hide(); //check stripe api
                jQuery('#create_loader').hide();    //form submit

                data = JSON.parse(data);
                //jQuery('#strip_api_msg').html('WORKINGGG....');
                jQuery('#strip_api_msg').html(data.json_result);

                var my_val = jQuery('#strip_api_msg').text();
                if(my_val=='VALID')
                {
                    jQuery('#stripe_val').val('1');
                }
                else
                {
                    jQuery('#stripe_val').val('0');
                }
                console.log(data);
            },   //SUCCESS END

            error:function(XMLHTTPRequest,textStatus,errorThrown)
            {
                console.log(textStatus);
                console.log(XMLHTTPRequest);
            }  //ERROR END

        });	//AJAX END

    });

    ////////////DONE DONE DONE ///////////////

    //Username
    $('#my_name').keydown(function(){
        $('#username_match_msg').hide();
    });

    //Email
    $('#email').keydown(function(){
        $('#email_match_msg').hide();
    });

    //HIDE LOGIN LINK IN SIGN UP PAGE
    jQuery('#login_link').hide();

    //AJAX FORM SUBMISSIONS
    jQuery('#ecour_form').on('submit',function (e)
    {

            //alert('user created.');
            jQuery('#create_loader').show();
            e.preventDefault();
            var name = jQuery('#name').val();
            var email = jQuery('#email').val();
            var password = jQuery('#password').val();
            var phone = jQuery('#phone').val();
            var photo = jQuery('#photo').val();
            //var geocomplete = jQuery('#geocomplete').val();
            var location = jQuery('#pac-input').val();
            var agree = jQuery('#agree').val();

            console.log(name);
            console.log(email);
            console.log(password);
            console.log(phone);
            console.log(photo);
            console.log(location);

        if(jQuery('#stripe_val').val()=='1')
        {
            jQuery.ajax     //AJAX START
            ({
                type: 'POST',
                // url:ajax_call_ecour.ajaxurl_ecour,
                url: 'Ecour_Form.php',
                data: new FormData(this),
                contentType: false,       // The content type used when sending data to the server.
                cache: false,             // To unable request pages to be cached
                processData: false,        // To send DOMDocument or non processed data file it is set to false
                /* data :{
                 action:'eregister', //ajax call function name
                 //nonce: ajax_call_ecour.nonce,
                 name:name,
                 email:email,
                 password:password,
                 phone:phone,
                 photo:photo,
                 location:location,
                 //geocomplete:geocomplete,
                 agree:agree
                 },  //DATA END*/
                success: function (data, textStatus, XMLHTTPRequest)
                {
                    jQuery('#create_loader').hide();
                    jQuery('#all_field_correct').hide();
                    //jQuery('#success_msg').html('Account created successfully.');
                    data = JSON.parse(data);
                    console.log(data);
                    jQuery('#success_msg').html(data.user_created);
                    jQuery('#photo_status').html(data.upload_message);

                    //Email Error
                    jQuery('#email_match_msg').show();
                    jQuery('#email_match_msg').html(data.email_match);

                    //Username Error
                    jQuery('#username_match_msg').show();
                    jQuery('#username_match_msg').html(data.username_match);

                    //SHOW LOGIN LINK AFTER REGISTRATION
                    jQuery('#login_link').show();

                },   //SUCCESS END
                error: function (XMLHTTPRequest, textStatus, errorThrown)
                {
                    console.log(textStatus);
                    console.log(XMLHTTPRequest);
                }  //ERROR END

            });	//AJAX END
        }
        else
        {
            jQuery('#create_loader').hide();
            jQuery('#all_field_correct').html('<b>PLEASE ENTER VALID STRIPE ACCOUNT INFORMATION</b>');
            /*alert('INCORRECT INFO');
            window.location.href = "http://110.37.221.34:7777/blog/wordpress/ecour-forms/";*/

        }
    });  //FORM SUBMIT END



});