<?php
/**
 * Created by PhpStorm.
 * User: Ayesha
 * Date: 9/30/2016
 * Time: 4:55 PM
 */
class Ecour_Register
{
    function __construct()
    {
        ## TEMP INCLUDES ##
        add_filter('template_include', array($this, 'register'));
        add_filter('template_include', array($this, 'login'));
        add_action('init', array($this, 'verify')); //verify email function

        add_action('wp_head', array($this, 'stripe_account_javascript'),50);
        add_action('wp_ajax_stripe_account', array($this, 'stripe_account_callback'));
        add_action('wp_ajax_nopriv_stripe_account', array($this, 'stripe_account_callback'));

        ##FORM SUBMISSION##
        add_action('wp_head', array($this, 'form_submit_javascript'));
        add_action('wp_ajax_form_submit', array($this, 'form_submit_callback'));
        add_action('wp_ajax_nopriv_form_submit', array($this, 'form_submit_callback'));
		/* waseem ajax file upload hooks start */
		add_action('wp_ajax_cvf_upload_files_up', array($this, 'cvf_upload_files_up') );
		add_action('wp_ajax_nopriv_cvf_upload_files_up', array($this, 'cvf_upload_files_up') ); // Allow front-end submission 
		/* waseem ajax file upload hooks end */
    }
	
    function register($template)
    {
        if (is_page('my-registration')) {
            $user_template = dirname(__FILE__) . "/register_template/register_template.php";
            return $user_template;
        }
        return $template;
    }
    function login($template)
    {
        if (is_page('login')) {
            $user_template = dirname(__FILE__) . "/register_template/login_template.php";
            return $user_template;
        }
        return $template;
    }
    ### FOR STRIPE ACCONT ###
    function stripe_account_javascript()
    { ?>
        <script type="text/javascript">
            /* Make this document ready function to work on click where you want */
            jQuery(document).ready(function ($)
            {
            	console.log('AISHA KHAN JAVASCRIPT 123456');
            	jQuery('#create_loader').hide();
	            jQuery('#strip_acoount_detail').hide();
	            jQuery('#login_link').hide();

	            jQuery('#existing_account').on('click', function () 
	            {
                    //alert('working');
	            	jQuery('#strip_acoount_detail').show();
	            });
                /* In front end of WordPress we have to define ajaxurl */
                var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
                jQuery('#strip_api_submit').on('click', function (e)
                {
                    /* You can get this value from some hidden field or div */
                    jQuery('#strip_loader').show();
                    e.preventDefault();
                    var strip_api = jQuery('#strip_api').val();
                    console.log(strip_api);
                    var data = {
                        'action': 'stripe_account',
                        'strip_api': strip_api,
                    };
                    $.post(ajaxurl, data, function (response)
                    {
						response  = response.trim();

                        jQuery('#strip_loader').hide(); //check stripe api
                        jQuery('#strip_api_msg').html(response);
                        var my_val = jQuery('#strip_api_msg').text();
                  
                        if (response == 'VALID') {
                        	//alert('validd');
                            jQuery('#stripe_val').val('1');
                        }
                        else {
                            jQuery('#stripe_val').val('0');
                        }
                    });
                });	//strip check end

                //functionss
                function readURL(input)
	            {
	                if (input.files && input.files[0]) {
	                    var reader = new FileReader();
	                    reader.onload = function (e) {
	                        jQuery('#drag_img').attr('src', e.target.result);
	                    }
	                    reader.readAsDataURL(input.files[0]);
	                }
	            }
	            jQuery("#photo").change(function ()
	            {
	                readURL(this);
	            });
	            ////IMAGE PREVIEW////
	            //Username
	            jQuery('#my_name').keydown(function () {
	                jQuery('#username_match_msg').hide();
	            });
	            //Email
	            jQuery('#email').keydown(function () {
	                jQuery('#email_match_msg').hide();
	            });

            });	//jquery end
        </script> <?php
    }
    ### FOR STRIPE ACCONT ###
    ### FOR STRIPE ACCONT CALLBACk###
    function stripe_account_callback()
    {
        $secretKey = $_POST['strip_api'];

        $args = array(
            'role' => 'subscriber',
            'fields' => 'all',
        );
        $all_user = get_users($args);

       $matched_key = '';
        foreach ($all_user as $user)
        {
            $usersecretKey = get_user_meta($user->ID,'stripe_secret_key',true);
            if($secretKey == $usersecretKey) {
                $matched_key = 'This Key is Already Exist';
              #             echo $user->ID;
                break;
            }
        }
#      die();
        #$res = array();
        # $publishableKey = 'pk_test_ktBe4SXg14zROMbZxbiDaxOi'; #### STRIPE MY API KEY ####
        # $secretKey = 'sk_test_B3eZEv3hzysWDbUxzyVtyRuF';    #### STRIPE MY SECRET KEY ####
        $url = 'https://api.stripe.com/v1/charges?key=' . $secretKey;
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $auth = curl_exec($curl);
        $json_result = '';
        $json = json_decode($auth);
        if ($auth)
        {
            $json = json_decode($auth);
            if (!empty($json->error->message))
            {
                $json_result = 'INVALID';
            }
            else
            {
                $json_result = 'VALID';
                /*if($matched_key=='')
                {
                    $json_result = 'VALID';
                }
                else{
                    $json_result = '<h5>';
                    $json_result .= $matched_key;
                    $json_result .= '</h5>';
                }*/


            }
        }
        #print_r($json_result);
        echo $json_result;
        die();
    }
    ### FOR STRIPE ACCOUNT CALLBACk###
    ### FOR FORM SUBMISSION###
    function form_submit_javascript()
    { ?>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                /* In front end of WordPress we have to define ajaxurl */
                var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

                jQuery('#ecour_form').on('submit', function (e) {
                    /* You can get this value from some hidden field or div */
                    e.preventDefault();
					//alert("work");
                    //alert('user created.');
                    jQuery('#create_loader').show();
                    var name = jQuery('#my_name').val();
                    var email = jQuery('#email').val();
                    var password = jQuery('#password').val();
                    var phone = jQuery('#phone').val();
                    var photo = jQuery('#photo').val();
                    var userfilepath = jQuery('#userfilepath').val();
                    var location = jQuery('.location').val();
                    var agree = jQuery('#agree').val();
                    var strip_api = jQuery('#strip_api').val();
                    var get_id = jQuery('#get_id').val();
                    var journey_start = jQuery('.journey_start').val();
                    var journey_end = jQuery('.journey_end').val();
                    /*console.log(name);
                    console.log(email);
                    console.log(password);
                    console.log(phone);
                    console.log(photo);
                    console.log(userfilepath);
                    console.log(location);
                    console.log(journey_start);
                    console.log(journey_end);*/

                    var data = {
                        'action': 'form_submit',
                        'name': name,
                        'email': email,
                        'password': password,
                        'phone': phone,
                        'photo': photo,
                        'userfilepath': userfilepath,
                        'location': location,
                        'agree': agree,
                        'strip_api': strip_api,
                        'get_id': get_id,
                        'journey_start': journey_start,
                        'journey_end': journey_end,
                    };
                    if (jQuery('#stripe_val').val() == '1')
                    {
                        $.post(ajaxurl, data, function (response)
                        {
                            //alert(response);
                            jQuery('#create_loader').hide();
                            jQuery('#all_field_correct').hide();

                            jQuery('#success_msg').show();
                            jQuery('#success_msg').html(response);
                        });
                    }
                    else
                    {
                        jQuery('#create_loader').hide();
                        jQuery('#all_field_correct').html('<span style="font-size:<?php echo esc_attr( get_option('change_size_font_error') );?>px; color:<?php echo esc_attr( get_option('change_fnt_color_errors') ); ?>;"><?php echo esc_attr( get_option('change_error_message') ); ?></span>');
                    }
                });
            });
			
        </script> <?php
    }
    ### FOR FORM SUBMISSION###
    ### FOR FORM SUBMISSION CALLBACK###
    function form_submit_callback()
    {
            $submit = $_POST["aisha"];
            $get_id = $_POST['get_id']; //if fb user exist then pick this ID and update ALL fields
            $get_hidden_fb_id = get_user_meta($get_id,'fb_id',true);
            ### START condition for Facebook user  ###
            $display_name = $_POST['name'];
            $email = $_POST['email'];
            $user_name = str_replace(' ', '_', $display_name);
            $full_name = explode(' ', $display_name);
            $name_count = count($full_name);
            $f_name = $full_name[0];
            $l_name = $full_name[1];
            ### FACEBOOK USERS GET DATA BY EMAIL ###
            #$res['fb_user_email'] = get_user_by('user_email',$res['email']);
            ### FACEBOOK USERS GET DATA BY EMAIL ###
            ##ERROR MSG DISPLAY##
            $args = array(
                'role' => 'subscriber',
                'fields' => 'all',
            );
            $all_user = get_users($args);
            $all_user_email = '';
            $all_user_name = '';
            foreach ($all_user as $value) {

                $all_user_email[] = $value->user_email;
                $all_user_name[] = $value->user_login;
            }
            $my_all_email = $all_user_email;
            $my_all_username = $all_user_name;
            $password = $_POST['password'];
            $phone = $_POST['phone'];
            $location = $_POST['location'];
            $agree = $_POST['agree'];
            $strip_api = $_POST['strip_api'];
            $userfilepath = $_POST['userfilepath'];

            ##JOURNEY###
                $journey_start = $_POST['journey_start'];
                $journey_end = $_POST['journey_end'];
            ##JOURNEY###
            $j1 = array();

            if(!empty($journey_start) && !empty($journey_end))
            {
                $j1 = array(
                    'start_point'=>$journey_start,
                    'end_point'=>$journey_end,
                );
            }
            $j_data = array(
                $j1,
            );

            $hash = md5(rand(1000, 5000));    #for unique registartion key for user
            #USER CREATING ARRAY
            $ecour_user = array(
                'user_login' => $user_name.'_'.$hash,
                'user_email' => $email,
                'user_pass' => $password,
                'display_name' => $display_name,
                'role' => 'subscriber',
            );
        ####  START -> IF FB USER EXIST SO RUN THIS CODE ####
            if ($get_hidden_fb_id=='')
            {
                ##FOR UNIQUE USER NAME
                $username_match='';
                $user_created='';
                $hash ='';
                $hash1 =md5(rand(100, 500));;
                if (in_array($user_name, $my_all_username)) {
                    $user_created = "Username is Already Exist.";
                    $hash = (rand(0,999));
                    echo $user_created;
                    die();
                }
                ##FOR UNIQUE EMAIL
                $email_match='';
                if (in_array($email, $my_all_email)) {
                    $user_created = "Email Address Already Exist.";
                    $fb_user_email = get_user_by('user_email', $email);
                    echo $user_created;
                    die();
                }
                #USER INSERT FUNCTION
                $user_id = wp_insert_user($ecour_user);
                #CHECK ERROR
                if (!is_wp_error($user_id))
                {
                    #UPDATE USER INFORMATION
                    $user_location = update_user_meta($user_id, 'user_location', $location);
                    $user_phone = update_user_meta($user_id, 'user_phone',$phone);
                    $terms_agree = update_user_meta($user_id, 'terms_agree', $agree);
                    $stripe_secret_key = update_user_meta($user_id, 'stripe_secret_key', $strip_api);
                    $account_hash_key = update_user_meta($user_id, 'account_hash_key', $hash);
                    $f_name = update_user_meta($user_id, 'first_name', $f_name);
                    $l_name = update_user_meta($user_id, 'last_name', $l_name);

                    $profile_pic = update_user_meta($user_id, 'profile_pic', $userfilepath);

                   /* $journey_start = update_user_meta($user_id, 'journey_start', $journey_start);
                    $journey_end = update_user_meta($user_id, 'journey_end', $journey_end);*/

                    $save_journey = update_user_meta($user_id,'save_journey',$j_data);
                    #START PROFILE IMAGE UPLOAD
                    $uplod_dir = wp_upload_dir();
                    $path = $uplod_dir['path'];
                    /*$res['upload_dir'] = wp_upload_dir();
                    $res['path'] = $res['upload_dir']['url'];*/
                    $sourcePath = $_FILES['photo']['tmp_name']; // Storing source path of the file in a variable
                    $targetPath = $path . '/' . $_FILES['photo']['name']; // Target path where file is to be stored
                    $success = move_uploaded_file($sourcePath, $targetPath); // Moving Uploaded file
                    $upload_message='';
                    if ($success)
                    {
                        $upload_message = 'IMAGE UPLOADED Successfully';
                        $pro_meta_key = update_user_meta($user_id, 'profile_pic', $uplod_dir['url'] . '/' . $_FILES['photo']['name']);
                    }
                    #END PROFILE IMAGE UPLOAD
                    $user_created = '';
                    $user_created = '<span style="font-size:'.esc_attr( get_option('change_size_font') ).'px; color:'.esc_attr( get_option('change_fnt_color_error') ).'">"'.esc_attr( get_option('change_success_message') ).'"</span>';
                    ##### WELCOME EMAIL #######
                    $to = $email;
                    $subject = "Welcome to Ecour";
                    $message = '
                        <html align="center">
                        <head>
                        <title>Welcome to Ecour</title>
                        </head>
                        <body>
                        <h1>Welcome to Ecour :)</h1>
                        <p>The word perfume derives from the Latin perfumare, meaning "to smoke through". Perfumery, as the art of making perfumes </p><br>
                    <p>All bringers are registered with their name, email address and credit card information. It provides that extra security and helps us to assure and simplify the service at the same time.</p>   
                   <p>Please click this link to activate your account:' . get_permalink(get_page_by_path('activate-account')) . '?verify=1&user_id=' . $user_id . '&email=' . $email . '&hash=' . $hash1 . '</p>
                        </body>
                        </html>
                        ';
                    # Always set content-type when sending HTML email
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    # More headers
                    $headers .= 'From: <webmaster@example.com>' . "\r\n";
                    $headers .= 'Cc: ayesha.aimviz@gmail.com' . "\r\n";
                    $res['email_sent'] = mail($to, $subject, $message, $headers);
                    ##### WELCOME EMAIL #######
                   # $register_user = get_user_by_id('id', $user_id);

                   #USER LOGIN
					$creds = array(
						'user_login'    => $email,
						'user_password' => $password,
						'remember'      => true
					);
					$user = wp_signon( $creds, false );

					if ( is_wp_error( $user ) ) 
					{
						echo $user->get_error_message();
					} 
					else 
					{
						?>
						<script type="text/javascript">
						jQuery(document).ready(function()
						{
							var url = '<?php echo site_url(); ?>';
							//window.location.href(url+'/task-search/');
							window.open(url+'/task-search/','_self');

						});
						</script>
						<!-- wp_safe_redirect(site_url().'/task-search/' );
						exit;	 -->
						<?php			
					}
					#USER LOGIN

                }
            }
        ####  END -> IF FB USER EXIST SO RUN THIS CODE ####
        #### START -> ELSE USER CREATED ####
            else
            {
                #UPDATE USER INFORMATION
                $user_location = update_user_meta($get_id, 'user_location', $location);
                $user_phone = update_user_meta($get_id, 'user_phone',$phone);
                $terms_agree = update_user_meta($get_id, 'terms_agree', $agree);
                $stripe_secret_key = update_user_meta($get_id, 'stripe_secret_key', $strip_api);
                $account_hash_key = update_user_meta($get_id, 'account_hash_key', $hash);
                $f_name = update_user_meta($get_id, 'first_name', $f_name);
                $l_name = update_user_meta($get_id, 'last_name', $l_name);


                $profile_pic = update_user_meta($get_id, 'profile_pic', $userfilepath);

                /*$journey_start = update_user_meta($get_id, 'journey_start', $journey_start);
                $journey_end = update_user_meta($get_id, 'journey_end', $journey_end);*/

                $save_journey = update_user_meta($get_id,'save_journey',$j_data);

                #START PROFILE IMAGE UPLOAD
                $uplod_dir = wp_upload_dir();
                $path = $uplod_dir['path'];
                /*$res['upload_dir'] = wp_upload_dir();
                $res['path'] = $res['upload_dir']['url'];*/
                $sourcePath = $_FILES['photo']['tmp_name']; // Storing source path of the file in a variable
                $targetPath = $path . '/' . $_FILES['photo']['name']; // Target path where file is to be stored
                $success = move_uploaded_file($sourcePath, $targetPath); // Moving Uploaded file
                $upload_message='';
                if ($success)
                {
                    $upload_message = 'IMAGE UPLOADED Successfully';
                    $pro_meta_key = update_user_meta($get_id, 'profile_pic', $uplod_dir['url'] . '/' . $_FILES['photo']['name']);
                }
                #END PROFILE IMAGE UPLOAD
                $user_created = '';
                $user_created = '<span style="font-size:'.esc_attr( get_option('change_size_font') ).'px; color:'.esc_attr( get_option('change_size_font') ).'">"'.esc_attr( get_option('change_fnt_color_error') ).'"</span>';
				// '<h3><i>USER CREATED SUCCESSFULLY!<br> CHECK YOUR EMAIL TO RECEIVED WELL COME EMAIL FROM OUR TEAM.</i></h3>'
                
                ##### WELCOME EMAIL #######
                $fb_user_password = 'ecour';
                $to = $email;
                $subject = "Welcome to Ecour";
                $message = '
                        <html align="center">
                        <head>
                        <title>Welcome to Ecour</title>
                        </head>
                        <body>
                        <h1>Welcome to Ecour :)</h1>
                        <p>With Ecour you can send anything anywhere - with decent, helpful people who will be going that way, anyway. You can finally bring home that chair you inherited from grandma, or the skis that remained in your shed last year. How else would you pick them up in an easy, safe and cost-effective way? </p><br>
                    <p>Wanna send or bring something? Use the buttons <below>2cb cb cb cb cb cb cb cb cb cb cb cb cb cb cb cb </below> to do it</p>
                    <p>All bringers are registered with their name, email address and credit card information. It provides that extra security and helps us to assure and simplify the service at the same time.</p> 
                   <p>Please click this link to activate your account:' . get_permalink(get_page_by_path('activate-account')) . '?verify=1&user_id=' . $get_id . '&email=' . $email . '&hash=' . $hash . '</p>
                    <p>Your Ecour Account Password is'.$fb_user_password.'</p> 
                    <p>You can change your password at anytime. Click link below:</p> 
                    <p>'.get_permalink(get_page_by_path('ecour-profile-page')).'/'.$get_id.'</p> 
                        </body>
                        </html>
                        ';
                # Always set content-type when sending HTML email
                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                # More headers
                $headers .= 'From: <webmaster@example.com>' . "\r\n";
                $headers .= 'Cc: ayesha.aimviz@gmail.com' . "\r\n";
                $res['email_sent'] = mail($to, $subject, $message, $headers);
                ##### WELCOME EMAIL #######

                #USER LOGIN
                $creds = array(
                    'user_login'    => $email,
                    'user_password' => $fb_user_password,
                    'remember'      => true
                );
                $user = wp_signon( $creds, false );

                if ( is_wp_error( $user ) ) 
                {
                    echo $user->get_error_message();
                } 
                else 
                {
                    ?>
                    <script type="text/javascript">
                    jQuery(document).ready(function()
                    {
                        var url = '<?php echo site_url(); ?>';
                        //window.location.href(url+'/task-search/');
                        window.open(url+'/task-search/','_self');

                    });
                    </script>
                    <!-- wp_safe_redirect(site_url().'/task-search/' );
                    exit;    -->
                    <?php           
                }
                #USER LOGIN
            }
        #### END -> ELSE USER CREATED ####
        if ($_GET['verify'] == 1)
            {
                $u_id = $_GET['user_id'];
                $verify = update_user_meta($u_id, 'email_verify', '1');
            }
            echo $user_created;
         //echo $upload_message;
        die();
    }
    ### FOR FORM SUBMISSION CALLBACK###
    function verify()
    {
        if ($_GET['verify'] == 1)
        {
            $u_id = $_GET['user_id'];
            $verify = update_user_meta($u_id, 'email_verify', '1');
        }
    }
	
	
	
	
	
	/* waseem files upload function code */
	function cvf_upload_files_up(){
    // print_r($_FILES);
	
	// echo "work";
	// die();
    // $parent_post_id = isset( $_POST['post_id'] ) ? $_POST['post_id'] : 0;  // The parent ID of our attachments
    $valid_formats = array("jpg", "png", "gif", "bmp", "jpeg"); // Supported file types
    $max_file_size = 1024 * 500; // in kb
    $max_image_upload = 10; // Define how many images can be uploaded to the current post
    $wp_upload_dir = wp_upload_dir();
    $path = $wp_upload_dir['path'] . '/';
    $count = 0;
	// Create post object
		$my_post = array(
		  'post_title'    => 'abhs',
		  'post_content'  => 'sdfsdf',
		  'post_status'   => 'publish',
		  'post_author'   => 1
		);
		 
		// Insert the post into the database
		
		$parent_post_id = wp_insert_post( $my_post );
		
    $attachments = get_posts( array(
        'post_type'         => 'attachment',
        'posts_per_page'    => -1,
        'post_parent'       => $parent_post_id,
        'exclude'           => get_post_thumbnail_id() // Exclude post thumbnail to the attachment count
    ) );

    // Image upload handler
    if( $_SERVER['REQUEST_METHOD'] == "POST" ){
       
        // Check if user is trying to upload more than the allowed number of images for the current post
        /*if( ( count( $attachments ) + count( $_FILES['files']['name'] ) ) > $max_image_upload ) {*/
			/*  echo "work";
							die(); */
            /*$upload_message[] = "Sorry you can only upload " . $max_image_upload . " images for each Ad";
        } else {*/
            
            foreach ( $_FILES['files']['name'] as $f => $name ) {
                $extension = pathinfo( $name, PATHINFO_EXTENSION );
                // Generate a randon code for each file name
                $new_filename = $this->cvf_td_generate_random_codes( 20 )  . '.' . $extension;
                
                if ( $_FILES['files']['error'][$f] == 4 ) {
					 /* echo "no";
							die(); */
                    continue; 
                }
                
                if ( $_FILES['files']['error'][$f] == 0 ) {
					 /* echo "yes";
							die(); */
                    // Check if image size is larger than the allowed file size
                    /*if ( $_FILES['files']['size'][$f] > $max_file_size ) {
                        $upload_message[] = "$name is too large!.";
                        continue;

                    // Check if the file being uploaded is in the allowed file types
                    }*/
                    if( ! in_array( strtolower( $extension ), $valid_formats ) ){
                        $upload_message[] = "$name is not a valid format";
                        continue; 
                    
                    } else{ 
                        // If no errors, upload the file...
                        if( move_uploaded_file( $_FILES["files"]["tmp_name"][$f], $path.$new_filename ) ) {
                            
                            $count++; 
							
                            $filename = $path.$new_filename;
                            $filetype = wp_check_filetype( basename( $filename ), null );
                            $wp_upload_dir = wp_upload_dir();
                            $attachment = array(
                                'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
                                'post_mime_type' => $filetype['type'],
                                'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
                                'post_content'   => '',
                                'post_status'    => 'inherit'
                            );
                            // Insert attachment to the database
                            $attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );

                            require_once( ABSPATH . 'wp-admin/includes/image.php' );
                            
                            // Generate meta data
                            $attach_data = wp_generate_attachment_metadata( $attach_id, $filename ); 
                            wp_update_attachment_metadata( $attach_id, $attach_data );
                            
                        }
                    }
                }
            }
       // }
    }
    // Loop through each error then output it to the screen
    if ( isset( $upload_message ) ) :
        foreach ( $upload_message as $msg ){        
            printf( __('<p class="bg-danger">%s</p>', 'wp-trade'), $msg );
        }
    endif;
    
    // If no error, show success message
    if( $count != 0 ){

        // printf( __('<p class = "bg-success">%d files added successfully!</p>', 'wp-trade'), $count );   
		 global $wpdb;
		$select_pst = "SELECT $wpdb->posts.ID from $wpdb->posts where $wpdb->posts.post_parent='".$parent_post_id."'";
		$result = $wpdb->get_results($select_pst,object);
		foreach($result as $kys){
			echo wp_get_attachment_url($kys->ID);
			/* ?>
			<img src="<?php  ?>"/>
			<?php */
		}
    }
    
    exit();
}

// Random code generator used for file names.
function cvf_td_generate_random_codes($length=10) {
 
   $string = '';
   $characters = "23456789ABCDEFHJKLMNPRTVWXYZabcdefghijklmnopqrstuvwxyz";
 
   for ($p = 0; $p < $length; $p++) {
       $string .= $characters[mt_rand(0, strlen($characters)-1)];
   }
 
   return $string;
 
}


	
}   ##CLASS END
