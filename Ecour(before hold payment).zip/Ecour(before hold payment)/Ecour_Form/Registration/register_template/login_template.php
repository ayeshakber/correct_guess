<?php get_header();?>
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

        <form class="ecour_login_form" id="ecour_login_form" name="ecour_login_form" method="POST" accept-charset="utf-8">
            <label>Email:</label>
            <input type="email" name="ecou_user_email" id="ecou_user_email" required="required"> </br>

            <label>Password:</label>
            <input type="password" name="ecour_user_pass" id="ecour_user_pass" required="required"> </br>

            <input type="checkbox" name="remember_me" id="remember_me">remember me </br>
            <input type="submit" name="submit_login" value="LOG IN">
        </form>
        <div align="center">
            <h4>OR</h4>
        </div>
       <!--  <p>hello facebook </p> -->

        <?php do_action('facebook_login_button');?>
        <?php
        if (isset($_POST['submit_login']))
        {
            $user_email = wp_strip_all_tags($_POST['ecou_user_email']);
            $user_email = login_with_email_address($_POST['ecou_user_email']);
            $user_pas = wp_strip_all_tags($_POST['ecour_user_pass']);
           /* echo "Your Email: ";
            echo "<br>";
            print_r($_POST['ecou_user_email']);
            echo "<br>";
            echo "Your Password: ";
            print_r($_POST['ecour_user_pass']);
            echo "<br>";*/
            $creds = array();
            $creds['user_login']=$user_email;
            $creds['user_password']=$user_pas;
            $creds['remember_me'] = 'true';
            $user = wp_signon($creds ,false);
            if (is_wp_error($user))
            {
            	echo '<div align="center">';
                	echo $user->get_error_message();
                echo '</div>';
            }
            else
            {
                wp_redirect(site_url().'/ecour-profile');
                exit;
            }
        }
        function login_with_email_address($username)
        {
            $user = get_user_by('user_email',$username);
            if(!empty($user->user_login))
                $username = $user->user_login;
            return $username;
        }
        ?>
    </main><!-- .site-main -->
</div><!-- .content-area -->
<?php get_footer(); ?>
