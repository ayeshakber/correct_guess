<?php get_header();
$url0 = PLUGIN_URL . "facebook/fb_config.php";
include($url0);
?>
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCi7_en6OpMbjn7j0A251CVbLQkrHIk2_8&sensor=false&amp;libraries=places"
                async defer></script>
        <script scr="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
        <!--        <script src="--><?php //echo plugins_url( __FILE__ ) ?><!--../../js/jquery.geocomplete.js"></script>-->

        <script>

            jQuery(document).ready(function()
            {
                
                jQuery("#geocomplete").val('Birmingham, United Kingdom');

                    ///START ADDRESS MAP LOCATION///
                var latlng = new google.maps.LatLng(40.723080, -73.984340); //you can use any location as center on map startup
                    var options = {
                        map: ".map_canvas",
                        center: latlng,
                    };
                    jQuery("#geocomplete").geocomplete(options)
                        .bind("geocode:result", function(event, result){
                            //jQuery.log("Result: " + result.formatted_address);
                        })
                        .bind("geocode:error", function(event, status){
                            //jQuery.log("ERROR: " + status);
                        })
                        .bind("geocode:multiple", function(event, results){
                            //jQuery.log("Multiple: " + results.length + " results found");
                        });
                    ///END ADDRESS MAP LOCATION///
                ///START POINT JOURNEY MAP LOCATION///
                var options = {
                    map: ".map_canvas_01"
                };
                jQuery("#geocomplete_01").geocomplete(options)
                    .bind("geocode:result", function(event, result){
                        jQuery.log("Result: " + result.formatted_address);
                    })
                    .bind("geocode:error", function(event, status){
                        jQuery.log("ERROR: " + status);
                    })
                    .bind("geocode:multiple", function(event, results){
                        jQuery.log("Multiple: " + results.length + " results found");
                    });
                ///START POINT JOURNEY MAP LOCATION///

                ///END POINT JOURNEY MAP LOCATION///
                var options = {
                    map: ".map_canvas_02"
                };
                jQuery("#geocomplete_02").geocomplete(options)
                    .bind("geocode:result", function(event, result){
                        jQuery.log("Result: " + result.formatted_address);
                    })
                    .bind("geocode:error", function(event, status){
                        jQuery.log("ERROR: " + status);
                    })
                    .bind("geocode:multiple", function(event, results){
                        jQuery.log("Multiple: " + results.length + " results found");
                    });
                ///END POINT JOURNEY MAP LOCATION///
            });
        </script>
        <!-- FB REGISTRATION -->
        <?php
        global $facebook, $fbPermissions, $homeurl_singup;
        //$facebook->destroySession();
        $user_id= get_current_user_id();
        $user_profile = $facebook->api('/me?fields=id,first_name,last_name,email,gender,locale,picture');
        $fb_id = $user_profile ["id"];
        $first_name = $user_profile ["first_name"];
        $last_name = $user_profile ["last_name"];
        $email = $user_profile ["email"];
        $gender = $user_profile ["gender"];
        $picture = $user_profile ["picture"]["data"]["url"];
        //$password = md5(rand(1000,5000));
        /*echo "BEFORE response:";
        echo "<pre>";
        print_r($user_profile);
        echo "</pre>";*/
        $password = 'ecour';
        if(empty($user_profile['id']))
        {

       /* echo "IF:";
        echo "<pre>";
        print_r($user_profile);
        echo "</pre>";*/

        //$facebook->destroySession();
            $loginUrl = $facebook->getLoginUrl(array('redirect_uri'=>$homeurl_singup,'scope'=>$fbPermissions));
            ///$output = '<a href="'.$loginUrl.'"><img src="'.plugin_dir_url( __FILE__ ) .'/images/fb_signup.png"></a>';
            $output = '<a href="'.$loginUrl.'"><img src="'.PLUGIN_HTTP_URL.'/facebook/images/fb_signup.png"></a>';
        }
        else
        {
            $hash = md5(rand(1000, 5000));    #for unique registration key for user
            $fb_user_info = array(
                'user_login'=>$first_name.'_'.$last_name.'_'.$hash,
                'user_email'=> $email,
                'user_pass'=> $password,
                'display_name'=>$first_name.' '.$last_name,
                'role' => 'subscriber'
            );
            $fb_user_id = wp_insert_user($fb_user_info);
            $fb_id = update_user_meta($fb_user_id,'fb_id',$fb_id);
            $first_name = update_user_meta($fb_user_id,'first_name',$first_name);
            $last_name = update_user_meta($fb_user_id,'last_name', $last_name);
            $fb_verify = update_user_meta($fb_user_id,'fb_verify','true');
            $fb_email = update_user_meta($fb_user_id,'fb_email','true');
            $fb_photo = update_user_meta($fb_user_id,'photo',$picture);

        /*echo "ELSE:";
        echo "<pre>";
        print_r($user_profile);
        echo "</pre>";*/

            if ( empty( $fb_user_id->errors ) )
            {
                echo '<h3 style="color:black;" align="center">You are connected with Facebook.<br>  Please Fill All Required Fields to Completed Registration.</h3>';
            }
            else
            {
                
                echo '<h3 align="center">This Facebook User is Already Connected To Our Site, Please Go to Facebook and Logout Your Account and Try Another One.<br>Then Go Back On This Page And Again Sign Up To Our Site.</h3>';

                #$facebook->getLogoutUrl();
                $facebook->destroySession();
                ### END FB SESSSION EXPIRE###
                $loginUrl = $facebook->getLoginUrl(array('redirect_uri'=>$homeurl_singup,'scope'=>$fbPermissions));
                $output = '<a href="'.$loginUrl.'"><img src="'.PLUGIN_HTTP_URL.'/facebook/images/fb_signup.png"></a>';

            } 
        }
         
        echo $output;
        $get_fb_id ='';
        $u_info ='';
        $email ='';
        $first_name ='';
        $last_name ='';
        $fb_photo ='';
        $user_pass ='';
        if(!empty($fb_user_id))
        {
            $u_info = get_userdata($fb_user_id);
            $email = $u_info->user_email;
            $user_pass = $u_info->user_pass;
            $get_fb_id = get_user_meta($fb_user_id,'fb_id',true);
            $first_name = get_user_meta($fb_user_id,'first_name',true);
            $last_name = get_user_meta($fb_user_id,'last_name',true);
            $fb_photo = get_user_meta($fb_user_id,'photo',true);
        }
        ?>
        <div>
            <h4>OR</h4>
        </div>
        <!-- FB REGISTRATION -->
        <form action="" method="POST" enctype="multipart/form-data" name="ecour_form" id="ecour_form">
            <h2>Ecour Registration Form</h2>
            <div class="e_username">
                <label>Name*</label>
                <input type="text" name="my_name" id="my_name" class="my_name" value="<?php if(($first_name!='') && ($last_name!='')){ echo $first_name.' '.$last_name;}else{echo '';}?>" required/><br><br>
                <div id="username_match_msg" style="color:deeppink"></div>
            </div>
            <!-- FB USER ID -->
            <input type="hidden" name="get_id" class="get_id" id="get_id" value="<?php echo $fb_user_id;?>">
            <input type="hidden" name="get_id" class="get_id" id="get_id" value="<?php echo $fb_user_id;?>">
            <!-- FB USER ID -->
            <div class="e_email">
                <label>Email*</label>
                <input type="text" name="email" id="email" class="email" value="<?php if($email!=''){ echo $email;}else{echo '';}?>" required/><br><br>
                <div id="email_match_msg" style="color:deeppink"></div>
            </div>
            <div class="e_password">
                <label>Password*</label>
                <input type="password" name="password" id="password" class="password" <?php if($user_pass!=''){ echo 'disabled' ;}else{echo 'required';}?> /><br><br>
            </div>
            <div class="e_phone">
                <label>Mobile Number*</label>
                <input type="text" name="phone" id="phone" class="phone" required/><br><br>
            </div>
            <div class="e_photo">
                <div class="row">
                    <div class="col-sm-6" id="image_upload">
                        <label>Upload a Photo*</label>
						<div class = "full-wd upload-form">
                                <div class= "upload-response"></div>
                                <div class="col-sm-12" id="image_preview">
                        <img id="drag_img" src="<?php if($fb_photo!='') {echo $fb_photo; }else { echo '';} ?>" alt="" />
                    </div>
                                <div class = "form-group photo_upload">
                                    <label><?php __('Select Files:', 'cvf-upload'); ?></label>
                                    <input type = "file" name = "files[]" accept = "image/*" class = "files-data form-control" multiple />
									<input type="hidden" name="userfilepath" id="userfilepath" value="<?php echo $picture; ?>"/>
                                </div>
                                <div class = "form-group full-wd">
                                    <!--<input type = "submit" value = "Preview" class = "btn btn-primary btn-upload" />-->
                                </div>
								</div>
                        <!--<input type="file" name="photo" id="photo" class="photo" value="<?php // echo $fb_photo;?>" required/><br><br>-->
                    </div>
                  
                </div>
            </div>
            <div class="e_address">
                <label>Address*</label>
                <input id="geocomplete" name="location" class="location" type="text" size="90" value="" />
				<input id="find" type="button" value="find">
                <div class="map_canvas" style="height: 500px;"></div>
            </div>
            <!--   MAP LOCATION    -->
            <!--   Regular Journey START POINT   -->
            <div class="e_journey">
                <label>Your Regular Journey*</label>
                <div class="row" id="regular_journey">
                    <div class="col-sm-6">
                        <span>From</span>
                        <input id="geocomplete_01" name="journey_start" class="journey_start" type="text" placeholder="Your Start Point" size="90" />
                        <div class="map_canvas_01" style="height: 500px; display: none"></div>
                    </div>
                    <!--   Regular Journey END POINT   -->
                    <div class="col-sm-6">
                        <span>To</span>
                        <input id="geocomplete_02" name="journey_end" class="journey_end" type="text" placeholder="Your End Point" size="90" />
                        <div class="map_canvas_02" style="height: 500px; display: none"></div>
                    </div>
                </div>
            </div>
            <div class="e_stripe_account">
                <label>Connect / Setup Stripe Account* </label>
                <div class="row">
                    <div class="col-sm-6">
                        <input type="button" name="existing_account" id="existing_account" class="existing_account" value="Connect to your existing stripe account" required/><br><br>
                        <div id="strip_acoount_detail" class="strip_acoount_detail">
                            <label>Enter Your Stripe API KEY:</label>
                            <input type="text" name="strip_api" id="strip_api" class="strip_api" value="" placeholder="Enter youe Stripe Account API Key" required/><br>
                            <input type="button" name="strip_api_submit" id="strip_api_submit" class="strip_api_submit" value="Check" /><br>
                            <div id="strip_loader" style="display:none;">
                                <img src="http://110.37.221.34:7777/blog/wordpress/wp-content/uploads/2016/09/ajax-loader.gif "/>
                            </div>
                            <div>
                                <input type="hidden" name="stripe_val" id="stripe_val" class="stripe_val" value="">
                            </div>
                            <div id="strip_api_msg" style="color:blue"></div>
                        </div>
                    </div>

                    <div>
                        <h4>OR</h4>
                    </div>
                    <div class="col-sm-6">
                        <a href="https://stripe.com/">
                            <input type="button" value="Setup a new stripe account" required/>
                        </a>
                    </div>
                </div>
            </div>
            <input type="checkbox" name="agree" id="agree" class="agree" value="1" required/>
            <label>Agree to The Terms And Conditions*</label><br><br>
            <input type="submit" name="aisha" value="Create Account" class="aisha" id="aisha"/>
        </form>
        <div id="all_field_correct" class="all_field_correct" style="color:red"></div>
		<?php  $upload_dir = wp_upload_dir(); ?>
        <div id="create_loader" style="display:none;">
            <img src="<?php echo $upload_dir["baseurl"]; ?>/ajax-loader.gif "/>
        </div>
        <div id="photo_status" style="color:green"> </div>
        <div id="success_msg" style="color:red"></div>
       <!--  <div id="login_link">
            <p>Now You can login to your Account.</p>
            <a href="<?php echo site_url().'/ecour-login/'; ?>">Login</a>
        </div> -->
        <?php
        ###sent email to users##
        function email_sent($user_id,$message,$subject)
        {
            $to_email = $user_id->user_email;
            $hash = md5(rand(1000,5000));	//for unique registartion for register user
            $message = '
          <html align="center">
             <head>
              <title>Welcome to Ecour</title>
             </head>
             <body>
               <h1>Welcome to Ecour :)</h1>
               <p>With Ecour you can send anything anywhere - with decent, helpful people who will be going that way, anyway. You can finally bring home that chair you inherited from grandma, or the skis that remained in your shed last year. How else would you pick them up in an easy, safe and cost-effective way? </p><br>
               <p>Wanna send or bring something? Use the buttons <below>2cb cb cb cb cb cb cb cb cb cb cb cb cb cb cb cb </below> to do it</p>
               <p>All bringers are registered with their name, email address and credit card information. It provides that extra security and helps us to assure and simplify the service at the same time.</p>   
               <p>Please click this link to activate your account:' . get_permalink(172) . '?verify=1&user_id=' . $user_id . '&email=' . $to_email . '&hash=' . $hash . '</p>
            </body>
          </html>
          ';
            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            // More headers
            $headers .= 'From: <webmaster@example.com>' . "\r\n";
            $headers .= 'Cc: ayesha.aimviz@gmail.com' . "\r\n";
            mail($to_email, $subject, $message, $headers);
        }
        ?>
    </main><!-- .site-main -->
</div><!-- .content-area -->
<script>
jQuery(document).ready(function() {
                                // When the Upload button is clicked...
                                jQuery('body').on('change', '.files-data', function(e){
                                    e.preventDefault();
									// alert("work");
                                    var fd = new FormData();
                                    var files_data = jQuery('.upload-form .files-data'); // The <input type="file" /> field
                                    
                                    // Loop through each data and create an array file[] containing our files data.
                                    jQuery.each(jQuery(files_data), function(i, obj) {
                                        jQuery.each(obj.files,function(j,file){
                                            fd.append('files[' + j + ']', file);
                                        })
                                    });
                                    
                                    // our AJAX identifier
                                    fd.append('action', 'cvf_upload_files_up');
                                    var abs = jQuery('#create_loader').wrapAll();
                                    jQuery('.upload-form').after(abs);
                                    // uncomment this code if you do not want to associate your uploads to the current page.
                                    // fd.append('post_id', <?php echo $_GET["task_id"]; ?>); 
									jQuery('#create_loader').show();
                                    jQuery.ajax({
                                        type: 'POST',
                                        url: '<?php echo admin_url( 'admin-ajax.php' ); ?>',
                                        data: fd,
                                        contentType: false,
                                        processData: false,
                                        success: function(response){
                                            jQuery('#drag_img').attr('src',response); //Append Server Response
											jQuery('#userfilepath').val(response);
											jQuery('#create_loader').hide();
											//jQuery('.files-data').hide();
											//jQuery('.btn-upload').hide();
                                        }
                                    });
                                });
                            });  
							</script>
    <script src="<?php echo plugins_url('Ecour_Form/js/jquery.geocomplete.js' ) ?>"></script>
	<script>
	jQuery(document).ready(function(){
		jQuery("#find").click(function(){
          jQuery("#geocomplete").trigger("geocode");
        });
		jQuery('#find').trigger('click');
	});
	</script>
	<style>
	#find{
		display:none;
	}
	<style>
							<?php get_footer(); ?>