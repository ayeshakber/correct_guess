<?php
$url = PLUGIN_URL . "facebook/fb_config.php";
$url2 = PLUGIN_URL . "facebook/includes/functions.php";
include($url);
include($url2);
#print_r(site_url());
class Profile_View
{
    function __construct()
    {
        add_shortcode('view_user_profile',array($this,'view_user_profile'));
		 add_shortcode('view_task_all',array($this,'view_taks_user'));
        add_action('wp_footer', array($this, 'verify_email_javascript'));
        add_action('wp_ajax_verify_email', array($this, 'verify_email_callback'));
        add_action('wp_ajax_nopriv_verify_email', array($this, 'verify_email_callback'));


        add_action( 'wp_footer', array($this,'credit_card_javascript') );
        add_action( 'wp_ajax_credit_card', array($this,'credit_card_callback') );
        add_action( 'wp_ajax_nopriv_credit_card', array($this,'credit_card_callback') );
    }
	function view_taks_user(){
		?>
		<style>
			div#post-446 h1 {
				display: none;
			}
		</style>
		<?php
		 global $current_user;
                            get_currentuserinfo();
$argss = array(
                                    'author'        =>  $current_user->ID,
                                    'orderby'       =>  'post_date',
                                    'order'         =>  'DESC',
                                    'posts_per_page' => -1,
                                    'post_type' => 'task'
                                );
 $the_querys = new WP_Query( $argss );
if ( $the_querys->have_posts() ) {
                                    echo '<h3>My Task</h3>
                                            <ul>';
                                    while ( $the_querys->have_posts() ) {
                                        $the_querys->the_post();
                                        echo '<a href="'.get_permalink().'" ><li>' . get_the_title() . '</li></a>';
                                    }
                                    echo '</ul>';
                                    /* Restore original Post Data */
                                    wp_reset_postdata();
                                } else {
                                    // no posts found
                                }
	}
    function  view_user_profile()
    {
        $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $uri_segments = explode('/', $uri_path);
        

        $uri_segments_count = count($uri_segments);
        $user_segment = $uri_segments[$uri_segments_count - 2];
       /*   echo "User SEGMENT";
        print_r($user_segment);
        echo "<br>";
*/
        if(is_user_logged_in() || is_numeric($user_segment))
        {
        #print_r(get_current_user_id());
            if(is_numeric($user_segment))
                $user_id = $user_segment;
            else
                $user_id = get_current_user_id();

            $user_info = get_userdata($user_id);
            #print_r($user_info);
          //  echo $user_id;
            $display_name = ($user_info->display_name);
            $user_registered = ($user_info->user_registered);
            $profile_pic = get_user_meta($user_id, 'profile_pic', true);
            //$profile_pic = get_user_meta($user_id, 'photo', true);
            $email_verify = get_user_meta($user_id, 'email_verify', true);
            $fb_verify = get_user_meta($user_id, 'fb_verify', true);
            $fb_id = get_user_meta($user_id, 'fb_id', true);
            $phone_verify = get_user_meta($user_id, 'phone_verify', true);
            $credit_card_connected = get_user_meta($user_id, 'credit_card_detail', true);

            $get_journey = get_user_meta($user_id, 'save_journey', true);

            if(empty($profile_pic))
                $profile_pic = get_avatar_url($user_id);

            if(isset($get_journey[0]['start_point']) && isset($get_journey[0]['end_point'])) {
                $start_1 = $get_journey[0]['start_point'];
                $end_1 = $get_journey[0]['end_point'];
            }

            if(isset($get_journey[1]['start_point']) && isset($get_journey[1]['end_point'])) {
                $start_2 = $get_journey[1]['start_point'];
                $end_2 = $get_journey[1]['end_point'];
            }

            if(isset($get_journey[2]['start_point']) && isset($get_journey[2]['end_point'])) {
                $start_3 = $get_journey[2]['start_point'];
                $end_3 = $get_journey[2]['end_point'];
            }

            ?>
            <script
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCi7_en6OpMbjn7j0A251CVbLQkrHIk2_8&sensor=false&amp;libraries=places"
                async defer></script>
            <script scr="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
            <!--<script src="--><?php //echo plugins_url( __FILE__ )
            ?><!--../../js/jquery.geocomplete.js"></script>-->
            <script src="<?php echo plugins_url('Ecour_Form/js/jquery.geocomplete.js') ?>"></script>
            <script>
                jQuery(document).ready(function () {
                    ///START ADDRESS MAP LOCATION///
                    var options = {
                        map: ".map_1"
                    };
                    jQuery("#start_1").geocomplete(options)
                        .bind("geocode:result", function (event, result) {
                            jQuery.log("Result: " + result.formatted_address);
                        })
                        .bind("geocode:error", function (event, status) {
                            jQuery.log("ERROR: " + status);
                        })
                        .bind("geocode:multiple", function (event, results) {
                            jQuery.log("Multiple: " + results.length + " results found");
                        });
                    ///END ADDRESS MAP LOCATION///

                    ///START ADDRESS MAP LOCATION///
                    var options = {
                        map: ".map_2"
                    };
                    jQuery("#end_1").geocomplete(options)
                        .bind("geocode:result", function (event, result) {
                            jQuery.log("Result: " + result.formatted_address);
                        })
                        .bind("geocode:error", function (event, status) {
                            jQuery.log("ERROR: " + status);
                        })
                        .bind("geocode:multiple", function (event, results) {
                            jQuery.log("Multiple: " + results.length + " results found");
                        });
                    ///END ADDRESS MAP LOCATION///
                    ///START POINT JOURNEY MAP LOCATION///
                    var options = {
                        map: ".map_3"
                    };
                    jQuery("#start_2").geocomplete(options)
                        .bind("geocode:result", function (event, result) {
                            jQuery.log("Result: " + result.formatted_address);
                        })
                        .bind("geocode:error", function (event, status) {
                            jQuery.log("ERROR: " + status);
                        })
                        .bind("geocode:multiple", function (event, results) {
                            jQuery.log("Multiple: " + results.length + " results found");
                        });
                    ///START POINT JOURNEY MAP LOCATION///

                    ///END POINT JOURNEY MAP LOCATION///
                    var options = {
                        map: ".map_4"
                    };
                    jQuery("#end_2").geocomplete(options)
                        .bind("geocode:result", function (event, result) {
                            jQuery.log("Result: " + result.formatted_address);
                        })
                        .bind("geocode:error", function (event, status) {
                            jQuery.log("ERROR: " + status);
                        })
                        .bind("geocode:multiple", function (event, results) {
                            jQuery.log("Multiple: " + results.length + " results found");
                        });
                    ///END POINT JOURNEY MAP LOCATION///


                    ///END POINT JOURNEY MAP LOCATION///
                    var options = {
                        map: ".map_5"
                    };
                    jQuery("#start_3").geocomplete(options)
                        .bind("geocode:result", function (event, result) {
                            jQuery.log("Result: " + result.formatted_address);
                        })
                        .bind("geocode:error", function (event, status) {
                            jQuery.log("ERROR: " + status);
                        })
                        .bind("geocode:multiple", function (event, results) {
                            jQuery.log("Multiple: " + results.length + " results found");
                        });
                    ///END POINT JOURNEY MAP LOCATION///
                    ///END POINT JOURNEY MAP LOCATION///
                    var options = {
                        map: ".map_6"
                    };
                    jQuery("#end_3").geocomplete(options)
                        .bind("geocode:result", function (event, result) {
                            jQuery.log("Result: " + result.formatted_address);
                        })
                        .bind("geocode:error", function (event, status) {
                            jQuery.log("ERROR: " + status);
                        })
                        .bind("geocode:multiple", function (event, results) {
                            jQuery.log("Multiple: " + results.length + " results found");
                        });
                    ///END POINT JOURNEY MAP LOCATION///
                });
            </script>

            <div>
                <div class="profile_info" align="center">
                    <div class="profile_name">
                        <div>
                            <img src="<?php echo $profile_pic; ?>" width="200">
                            <h3>
                                <?php echo $display_name; ?>
                                <div class="user-average-rating">
                                    <?php echo do_shortcode('[user-average-ratings]');?>
                                </div>
                            </h3>
                        </div>
                    </div>
                    <div class="joining">
                        <div class="row" align="center" style="width: 50%">
                            <div class="col-sm-6">
                                <?php
                                $task_completed_count = 0;
                                $completed_task_list = get_user_meta($user_id,'task_completed',true);
                                if(!empty($completed_task_list)) {
                                    $completed_task_list = explode('_',$completed_task_list);
                                    $task_completed_count = count($completed_task_list);
                                }
                                ?>
                                <span class="profile_status"><?php echo $task_completed_count;?> Task Completed</span>
                            </div>
                            <div class="col-sm-6">
                                <span class="profile_joined">Joined:<?php echo $user_registered; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <br>
                <div class="reviews">
                    <div class="row">
                        <div class="col-sm-6">
                            <!--<h3>Your reviews</h3>-->
                            <?php
                            echo $print_reviews = do_shortcode('[user-recent-reviews limit="3"]');
                            if(!empty($print_reviews)){
                               // echo $print_reviews;
                                $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
                                $uri_segments = explode('/', $uri_path);
                                $uri_segments_count = count($uri_segments);
                                $user_segment = $uri_segments[$uri_segments_count - 2];
                                if(is_numeric($user_segment)){
                                    echo '<a href="'.get_permalink(get_page_by_path('all-reviews')).'?profile='.$user_segment.'">View All Reviews</a>';
                                }
                                else{
                                    echo '<a href="'.get_permalink(get_page_by_path('all-reviews')).'">View All Reviews</a>';
                                }



                            } else {
                                echo '<p>No Reviews Yet</p>';
                            }


                            global $current_user;
                            get_currentuserinfo();

                            $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
                            $uri_segments = explode('/', $uri_path);
                            $uri_segments_count = count($uri_segments);
                            $user_segment = $uri_segments[$uri_segments_count - 2];

                            if($this->username_exists_by_id($user_segment) == false && is_user_logged_in() ) {
                            ?>
                            <!-- MY TASKS -->
                            <div class="my-tasks">
                                <?php
								$argss = array(
                                    'author'        =>  $current_user->ID,
                                    'orderby'       =>  'post_date',
                                    'order'         =>  'DESC',
                                    'posts_per_page' => -1,
                                    'post_type' => 'task'
                                );
                                // The Query
                                $the_querys = new WP_Query( $argss );
								$count = $the_querys->post_count;
                                $args = array(
                                    'author'        =>  $current_user->ID,
                                    'orderby'       =>  'post_date',
                                    'order'         =>  'DESC',
                                    'posts_per_page' => 5,
                                    'post_type' => 'task'
                                );
                                // The Query
                                $the_query = new WP_Query( $args );
								
								
                                // The Loop
                                if ( $the_query->have_posts() ) {
                                    echo '<h3>My Tasks</h3>
                                            <ul>';
                                    while ( $the_query->have_posts() ) {
                                        $the_query->the_post();
                                        echo '<a href="'.get_permalink().'" ><li>' . get_the_title() . '</li></a>';
                                    }
                                    echo '</ul>';
                                    /* Restore original Post Data */
                                    wp_reset_postdata();
                                } else {
                                    # no posts found
                                }
								if($count>5){   #aisha get permalink remove
									?>
									<a href="<?php echo get_the_permalink(446); ?>">View all tasks</a>
									<?php
								}

                                ?>
                            </div>
                            <?php } ?>

                        </div>
                        <div class="col-sm-6">
                         <h3>Verifications</h3>
                            <!-- <div class="mobile_verify">
                                <label>Mobile number verified</label>
                                <span> -->
                                <?php
                                /*if ($phone_verify) {
                                    echo '&#9745;';
                                } else {
                                    echo '<a href="#">Verify your mobile number</a>';
                                }*/
                                ?>

                               <!--  </span>
                            </div> -->
                            <div class="photo_uploaded">
                                <label>Photo uploaded</label>
                                <span>
                                <?php if ($profile_pic!='') {
                                    echo '&#9745;';
                                } else {
                                    echo '<a href="#">Add your profile picture</a>';
                                }
                                ?>
                            </span>
                            </div>
                            <div class="fb_connected">
                                <label>Facebook connected</label>
                                <span>
                                <?php
                                if ($fb_id) {
                                    echo '&#9745;';
                                }
                                else
                                {
                                    global $facebook, $homeurl, $fbPermissions, $fbuser;
                                    $user_id = get_current_user_id();
                                    $fb_verify1 = get_user_meta($user_id, 'fb_verify', true);

                                    if (empty($fbuser)) {
                                        $loginUrl = $facebook->getLoginUrl(array('redirect_uri' => $homeurl, 'scope' => $fbPermissions));
                                        $output = '<a href="' . $loginUrl . '"><img src="' . PLUGIN_HTTP_URL . 'facebook/images/f-connect.png" width="70px"></a>';
                                    }
                                    else
                                    {
                                        $output = '&#9745;';
                                        $user_profile = $facebook->api('/me?fields=id,first_name,last_name,email,gender,locale,picture');
                                        $fb_id = $user_profile ["id"];
                                        $first_name = $user_profile ["first_name"];
                                        $last_name = $user_profile ["last_name"];
                                        $email = $user_profile ["email"];
                                        $gender = $user_profile ["gender"];
                                        $picture = $user_profile ["picture"]["data"]["url"];

                                        $fb_id = update_user_meta($user_id, 'fb_id', $fb_id);
                                        $fb_verify = update_user_meta($user_id, 'fb_verify', 'true');
                                        $fb_email = update_user_meta($user_id, 'fb_email', 'true');
                                        
                                        /*if (!empty($user_data))
                                        {
                                            $fb_verify = update_user_meta($user_id, 'fb_verify', 'true');
                                            $fb_email = update_user_meta($user_id, 'fb_email', 'true');
                                        }
                                        else
                                        {
                                            $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
                                        }*/
                                    }
                                }
                                echo $output;
                                ?>
                            </span>
                            </div>
							<div class="user_update_profile">
								<label>Update Profile</label>
								<span><a href="/user-information">edit</a></span>
							</div>
                            <div class="credit_card_connected">
                                <label>Credit card connected</label>
                                <span>
                                <?php
                                if ($credit_card_connected) {
                                    echo '&#9745;';
                                } else {
                                    echo '<a href="#" class="card_connect">Connect your Account </a>';
                                }
                                ?>
                            </span>
                            </div>
                            <div class="email_verify">
                                <label>E-mail verified</label>
                                <span>
                                <?php
                                if ($email_verify == '1') {
                                    echo '&#9745;';
                                } else {
                                    echo '<a href="#" id="verify">
                                      <p id="verify">   Verify your email address</p>
                                    </a>';
                                }
                                ?>
                                    <script>
                                    jQuery(document).ready(function () { 
                                        jQuery('#verify').click(function () {
                                            alerty.prompt('Email Verification',
                                            {
                                                inputType: 'text',
                                                inputPlaceholder: 'Enter Your Email Address',
                                                inputValue: '',
                                                okLabel: 'OK',
                                                cancelLabel: 'CANCEL'
                                            },
                                            function (value) {
                                                alerty.alert('Check Your Email at: <b>' + value + '</b>',{okLabel:'OK'});
                                            },
                                            /* function () {
                                                //alert('cancel callback')
                                            }) */
                                        });
                                    });
                                </script>
                            </span>
                            </div>
                            
                            
                        </div>

                            <?php 
                                    $user_profile_id = $uri_segments[2];
                                    #echo "<br>this is profile SEGMENT:";
                                    #echo $user_profile_id;
                                    if ($user_profile_id == '') 
                                    {
                                        ?>
                                        <div class="news-letter">
                                        <h4>Subscribe Our Newsletter</h4>
                                            <?php echo do_shortcode('[newsletter_form]'); ?>
                                                                        
                                        </div>
                                        <?php
                                    }
                                ?>
                        <div class="waseem_shortcode">
                            <?php #echo register_sidebar( 'sidebar-4' );
                            ?>
                            <?php echo do_shortcode('[user-satr-reviews]'); ?>
                            <?php 
                                $user_profile_id = $uri_segments[2];
                                /*
                                echo "URI SEGMENT";
                                print_r($user_profile_id);
                                echo "<br>";*/
                                $current_id = get_current_user_id();
                                /*echo "Current User";
                                print_r($current_id);
                                echo "<br>";*/
                                $journy_show ='';
								if($user_profile_id!='')
                                {
								    $journy_show='disabled';
                                }
								else{
									?>
									<script>
										jQuery(document).ready(function(){
											jQuery('.journey_details input').removeAttr('disabled');
										});
									</script>
									<?php
								}
                            ?>

                        </div>
                        <div class="journey_details" style="width:100%;">
                            <form method="POST" action="" name="save_journey" id="save_journey" class="save_journey">
                                <label>Your Regular Journey*</label>
                                <div class="row journey_1">
                                    <div class="col-sm-6" id="start_journey_1">
                                        <span>From(Required*)</span>
                                        <input id="start_1" name="start_1" class="start_1" type="text" size="50"
                                               value="<?php if (!empty($get_journey)) {
                                                   echo $start_1;
                                               } else {
                                                   echo '';
                                               } ?>" <?php echo $journy_show;?>/>
                                        <div class="map_1" style="height: 500px; display: none">  
                                        </div>
                                    </div>
                                    <div class="col-sm-6" id="end_journey_1">
                                        <span>To(Required*)</span>
                                        <input id="end_1" name="end_1" class="end_1" type="text" size="50"
                                               value="<?php if (!empty($get_journey)) {
                                                   echo $end_1;
                                               } else {
                                                   echo '';
                                               } ?>" <?php echo $journy_show;?>/>
                                        <div class="map_2" style="height: 500px; display: none"></div>
                                    </div>
                                </div>
                                <div class="row journey_2">
                                    <div class="col-sm-6" id="start_journey_2">
                                        <span>From</span>
                                        <input id="start_2" name="start_2" class="start_2" type="text" size="50"
                                               value="<?php if (!empty($get_journey)) {
                                                   echo $start_2;
                                               } else {
                                                   echo '';
                                               } ?>" <?php echo $journy_show;?>/>
                                        <div class="map_3" style="height: 500px; display: none"></div>
                                    </div>
                                    <div class="col-sm-6" id="end_journey_2">
                                        <span>To</span>
                                        <input id="end_2" name="end_2" class="end_2" type="text" size="50"
                                               value="<?php if (!empty($get_journey)) {
                                                   echo $end_2;
                                               } else {
                                                   echo '';
                                               } ?>" <?php echo $journy_show;?>/>
                                        <div class="map_4" style="height: 500px; display: none"></div>
                                    </div>
                                </div>
                                <div class="row journey_3">
                                    <div class="col-sm-6" id="start_journey_3">
                                        <span>From</span>
                                        <input id="start_3" name="start_3" class="start_3" type="text" size="50"
                                               value="<?php if (!empty($get_journey)) {
                                                   echo $start_3;
                                               } else {
                                                   echo '';
                                               } ?>" <?php echo $journy_show;?>/>
                                        <div class="map_5" style="height: 500px; display: none"></div>
                                    </div>
                                    <div class="col-sm-6" id="end_journey_3">
                                        <span>To</span>
                                        <input id="end_3" name="end_3" class="end_3" type="text" size="50"
                                               value="<?php if (!empty($get_journey)) {
                                                   echo $end_3;
                                               } else {
                                                   echo '';
                                               } ?>" <?php echo $journy_show;?>/>
                                        <div class="map_6" style="height: 500px; display: none"></div>
                                    </div>
                                </div>
                                <input type="submit" name="save_journey" id="save_journey" class="save_journey"
                                       value="Save journey">
                            </form>
                            
                        </div>
                        <?php
                        if (isset($_POST['save_journey'])) 
                        {
                            ## FOR JOURNEY 1##
                            $j_start_1 = $_POST['start_1'];
                            $j_end_1 = $_POST['end_1'];
                            $journey1 = array();
                            if (!empty($j_start_1) && !empty($j_end_1)) {
                                $journey1 = array(
                                    'start_point' => $j_start_1,
                                    'end_point' => $j_end_1,
                                );
                            }

                            ## FOR JOURNEY 2##
                            $j_start_2 = $_POST['start_2'];
                            $j_end_2 = $_POST['end_2'];
                            $journey2 = array();
                            if (!empty($j_start_2) && !empty($j_end_2)) {
                                $journey2 = array(
                                    'start_point' => $j_start_2,
                                    'end_point' => $j_end_2,
                                );
                            }

                            ## FOR JOURNEY 3##
                            $j_start_3 = $_POST['start_3'];
                            $j_end_3 = $_POST['end_3'];
                            $journey3 = array();
                            if (!empty($j_start_3) && !empty($j_end_3)) 
                            {
                                $journey3 = array(
                                    'start_point' => $j_start_3,
                                    'end_point' => $j_end_3,
                                );
                            }
                            $journey_data = array(
                                $journey1,
                                $journey2,
                                $journey3
                            );
                            $save_journey = update_user_meta($user_id, 'save_journey', $journey_data);
                            
                            #remove startupbug
                            header('Location:http://ecour.startupbug.net/ecour-profile-page/');
                            echo '<h3>YOUR JOURNEY HAS BEEN SAVE</h3><br>';
                            ?>
                            <!-- <script type="text/javascript">
                                jQuery(document).ready(function()
                                {
                                    
                                    window.location.reload();
                                   
                                    //jQuery('#save_journey').trigger('click');

                                });
                            </script> -->

                            <?php
                            #print_r($save_journey);
                        }
                        ?>
                    </div>
                </div>
            </div>
            <?php
        }
        else
        {
            ?>
             <p>You Will Have to <a href="<?php echo site_url().'/ecour-login/'; ?>">Login</a> Your Account To View Profile.</p>
            <?php
        }
    }

    function verify_email_javascript()
    { ?>
        <script type="text/javascript" >

            /* Make this document ready function to work on click where you want */
            jQuery(document).ready(function($)
            {
                var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
                /* In front end of WordPress we have to define ajaxurl */

                jQuery('#verify').click(function ()
                {
                    alerty.prompt('Email Verification',
                        {
                            inputType: 'text', inputPlaceholder: 'Enter Your Email Address', inputValue: '',
                            okLabel:'OK',cancelLabel:'CANCEL'
                        },
                        function(value)
                        {
                            var data = {
                                'action': 'verify_email',
                                'email_to_verify' : value,
                            };
                            $.post(ajaxurl, data, function(response)
                            {
                                alerty.alert(response, {
                                    title: 'Info',
                                    time: 3000,
                                    okLabel:'OK'
                                }, function(){//alert('callback')})
                            });
                        },
                        function(){
                        });
                });
			}); 
		});
        </script> <?php
    }

    function verify_email_callback()
    {
        $email =  $_POST['email_to_verify'];
        ##### WELCOME EMAIL #######
        $to = $email;
        $user_id = get_current_user_id();
        $hash = md5(rand(1000,5000));	//for unique registartion for register user
        $subject = "Welcome to Ecour";
        $message = '
                      <html align="center">
                        <head>
                        <title>Welcome to Ecour</title>
                        </head>
                        <body>
                        <h1>Welcome to Ecour :)</h1>
                        <p>With Ecour you can send anything anywhere - with decent, helpful people who will be going that way, anyway. You can finally bring home that chair you inherited from grandma, or the skis that remained in your shed last year. How else would you pick them up in an easy, safe and cost-effective way? </p><br>
                    <p>Wanna send or bring something? Use the buttons <below>2cb cb cb cb cb cb cb cb cb cb cb cb cb cb cb cb </below> to do it</p>
                    <p>All bringers are registered with their name, email address and credit card information. It provides that extra security and helps us to assure and simplify the service at the same time.</p>   
                   <p>Please click this link to activate your account:' . get_permalink( get_page_by_path( 'activate-account' ) ). '?verify=1&user_id=' . $user_id . '&email=' . $email . '&hash=' . $hash . '</p>
                        </body>
                        </html>
                        ';
        # Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        # More headers
        $headers .= 'From: <webmaster@example.com>' . "\r\n";
        $headers .= 'Cc: ayesha.aimviz@gmail.com' . "\r\n";
        $email_sen = mail($to, $subject, $message, $headers);
        echo 'Email Address3: '.$email;
        ##### WELCOME EMAIL #######
        die(); // this is required to terminate immediately and return a proper response

    }

    function username_exists_by_id($user_ID){

        global $wpdb;

        $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $wpdb->users WHERE ID = %d", $user_ID));

        if($count == 1){ return true; }else{ return false; }
    }


    function credit_card_javascript()
    {
        ?>
        <script>
        // Send a message
        jQuery(document).ready(function($)
        {
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
            jQuery('.card_connect').click(function()
            {

                //var postid = <?php echo get_the_ID(); ?>;
                var user_id = <?php echo get_current_user_id(); ?>;
                alerty.confirm('Enter Your Credit Card Number <p><input type="text" class="e-card_num" id="e-card_num" placeholder="Credit Card Number"></p>CSV Number<p><input type="text" class="e-card_csv"/></p>', {
                        title: 'Send message to sender',
                        cancelLabel: 'Cancel', okLabel: 'Save'
                    }, function(value)
                    {
                        var data = {
                            'action': 'credit_card',
                            'card_detail' : value,
                        };
                        $.post(ajaxurl, data, function(response)
                        {
                           // alert(response);
                            alerty.alert('Your Account has been Connected <span style="color:green">&#10003;</span>',{title: 'Successful',okLabel: 'OK'});
                        });
                    },
                    function()
                    {
                        alerty.alert('cancel <span style="color:green">&#10003;</span>',{title: 'Successful',okLabel: 'OK'});
                    });
            });
        });

        </script>
    <?php
    }


    function credit_card_callback()
    {
        $user_id = get_current_user_id();
        $card_info =  explode('|',$_POST['card_detail']);
        $card_num = $card_info[0];
        $card_csv = $card_info[1];
        $data = 'CARDNUM:' . $card_num;
        $data .= 'CARDCSV:' . $card_csv;
        echo $data;
        $card_info =array(
            'card_num'=>$card_num,
            'card_csv'=>$card_csv,
        );
        $credit_card = update_user_meta($user_id,'credit_card_detail',$card_info);
        die();
    }


}   ### CLASS END