<?php
get_header(); ?>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCi7_en6OpMbjn7j0A251CVbLQkrHIk2_8&sensor=false&amp;libraries=places"
        async defer></script>-->
<!--<script scr="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
-->
<div id="primary" class="content-area">
    <main id="main" class="site-main user-task" role="main">
        <?php
        do_action('task_header');
        global $post;
        $post_description = $post->post_content;
        $post_title = $post->post_title;
        $post_author = $post->post_author;
        setup_postdata($post);  // FOR AUTHOR
        $current_user_1 = get_current_user_id();
        /*print_r($current_user_1);
        echo "AISHA AKBER's ID";*/
        /**
         * @Aisha
         * offer reviews
         */
        $post_ID = $post->ID;
        /*echo "<br>Admin Side:";
         echo "<br>POST ID:";
        print_r($post_ID);
        echo "<br>Author ID:";
        print_r($post_author);
        echo "<br>Current user ID:";
        print_r($current_user_1);*/

        /*$post_author = get_post_field( 'post_author', $post_ID );
        echo "<br>POST AUTHOR: ";
        print_r($post_author);*/
        
        $post_accepted = get_post_meta($post_ID,'offer_accepted',true);//user id
        $post_interested = get_post_meta($post_ID,'task_offers',true);
        $successfull_task = get_post_meta($post_ID,'successfull_task',true);//user id
        /*echo "<br>ADMIN SIDE:TASK SUCESFULL DELIVERED:";
        print_r($successfull_task);
        echo "<br>";*/
       /*  echo "<br>Offer Accepted ID:";
        print_r($post_accepted);
         echo "<br>Post interested ID:";
        print_r($post_interested);*/
        /**
         * @Aisha
         * offer reviews
         */
        $client_id = $_SERVER['REMOTE_ADDR'];
        $data_base_client = get_post_meta($post->ID,'client_ip_address',true);
        $clients = get_post_meta($post->ID,'client_ip_address',true);
        $old_clients_ip = explode('_',$clients);

        if(!empty($data_base_client) && !in_array($client_id,$old_clients_ip)) {
            $data_base_client = $data_base_client.'_'.$client_id;
            update_post_meta($post->ID,'client_ip_address',$data_base_client);
        } else if(!in_array($client_id,$old_clients_ip)){
            update_post_meta($post->ID,'client_ip_address',$client_id);
        }
        $clients = get_post_meta($post->ID,'client_ip_address',true);
        $old_clients_ip = explode('_',$clients);

        if ($post_author == $current_user_1 )
        {
            if($post_accepted && $successfull_task!='1')
            {
                 do_action('bringer_sender_chat',get_the_ID(),1);
            }
            else if($successfull_task=='1')
            {
                echo "This item is Already Delivered!";

            }
            else
            {
                 do_action('task_details_header',$current_user_1);
            }

            #do_action('bringer_sender_chat',get_the_ID(),1);
            #do_action('task_details_header',$current_user_1);
        }
        else if(!empty($post_accepted))
        {
            echo "OOPSSS! This Task has been Expired!";
        }

        
        /*else
        {
            echo "OOPSSS! This Task has been Expired!";
            #do_action('task_details_header',$current_user_1);
        }*/
        /*else
        {
             do_action('task_details_header',$current_user_1);
        }*/
        /**
         * @Aisha
         * offer reviews
         */
        $extra_need = get_post_meta($post->ID,'extra_need',true);
        $extra_result = '';
        if($extra_need!='')
        {
            $extra_result = 'Update Your Extra Need';
        }
        else
        {
            $extra_result = 'Add Your Extra Need Here.';
        }
          
        /// OFFER AREA  //

        $def_ins = esc_attr( get_option('change_insurances_color_errors') );   ##old
         #$def_ins = get_post_meta( $post->ID, 'sender_insurance', true );   ##new
    /*$total_miles = get_post_meta($post->ID,'total_miles',true);
    echo "<BR>TOTAL MILES IN POST:";
    print_r($total_miles);*/
        $html .= '<div class="page-visit-counter"><span class="total-count"><i class="fa fa-eye" aria-hidden="true"></i> Total Views: </span>'.count($old_clients_ip).'</div><div class="map-google">
                    <div id="map" style="width: 100%;height:300px"></div>
                  </div>
                  <button class="delete-taks">X Delete Task</button>';
        $upload_dir = wp_upload_dir();
        $base =$upload_dir['baseurl'];
        $html .= '<div class="task-details">
                        <div class="task-item-detail">
                            <div class="task-labels"></div>
                            <div class="task-value">Report task</div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Insurance</div>
                            <div class="task-value">
                            <p>Your parcel is covered up to £'.$def_ins.'</p>
                            </div>
                        </div>
						<div class="task-item-detail">
                            <div class="task-labels">Photo</div>
                            <div class="task-value">
								<div class = "detail-upload-task-files upload-form">
									<div class="loader_animateds" style="display:none;"><img src="'.$base.'/ajax-loader.gif"/></div>
									<div class= "upload-response"></div>';
                                    $select_pst = "SELECT $wpdb->posts.ID from $wpdb->posts where $wpdb->posts.post_parent='".$post_ID."' ORDER BY wp_0fb446804f_posts.`ID` DESC LIMIT 1";
                                    $result = $wpdb->get_results($select_pst,object);
									if(empty($result)){
									    $html .='<div class = "form-group detail-task">
								            <a href="javascript:void(0);" id="add_photo_task">Add Photo</a>
								            <input type = "file" id="taskaddphotos" name = "files[]" accept = "image/*" class = "files-data-detail form-control detail-task-fld" multiple style="display: none;" />
							            </div>';
                                    }
                                    else 
                                    {
                                        $html .= '<div class = "form-group detail-task">
                                                <a href="javascript:void(0);" id="change_photo_task">Change Photo</a>
										<input type = "file" id="taskchangephotos" name = "files[]" accept = "image/*" class = "files-data-detail form-control detail-task-fld" multiple  style="display: none;"/>
									   </div>';
                                    }
									$html .='<div class = "form-group">
										<!--<input type = "submit" value = "Upload" class = "btn btn-primary btn-upload" />-->
									</div>
								</div>
							</div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Fits in:</div>
                            <div class="task-value" id="size"> <div class="edit-btn"><span>size</span><span>'.get_post_meta($post->ID,'size',true).'</span>Edit</div><div class="task-item-value">'.get_post_meta($post->ID, 'size' ,true).'</div></div>
                        </div>
                        
                        <div class="task-item-detail">
                            <div class="task-labels">Delivered by:</div>';

                            #$reward = get_post_meta($post->ID,'payment_amount',true);
                            $author_post = $post->post_author;
                            /*echo "<br>author id:";
                            print_r($author_post );*/
                            $current_user_id = get_current_user_id();
                            /* echo "<br>current_user_id id:";
                            print_r($current_user_id );*/

                            $reward = '';
                            if ($current_user_id == $author_post ) 
                            {
                                 $reward = get_post_meta($post->ID,'payable',true);
                            }
                            else
                            {
                                 $reward = get_post_meta($post->ID,'transporter_paid',true);
                            }
                              /*echo "<br>reward:";
                            print_r($reward);
*/

        $html .='<div class="task-value" id="delivery_flex"> <div class="edit-btn"><span>delivery_flex</span><span>'.get_post_meta($post->ID,'delivery_flex',true).'</span>Edit</div><div class="task-item-value">'.get_post_meta($post->ID, 'delivery_flex', true). ' '.get_post_meta($post->ID,'select_time',true).'</div></div>
                        </div>
                        
                        <div class="task-item-detail">
                            <div class="task-labels">Cost:</div>
                            <div class="task-value" id="payment_amount"> <div class="task-item-value">'.$reward.'</div>£<p>ecour will debit this amount when a transporter collects the item.</p></div>
                        </div>
                         
                        <div class="task-item-detail">
                            <div class="task-labels">Description:</div>
                            <div class="task-value" id="post_desc"> <div class="edit-btn"><span>post_desc</span><span>'.$post_description.'</span>Edit</div><div class="task-item-value">'.$post_description.'</div></div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Picked up from:</div>
                            
                            <div class="address-field" style="display:none">
                            <input id="autocomplete" style=" width: 33%;font-size: 11px;padding: 8px;float: left; margin: 0px 7px 0px 0px;" placeholder="Enter your address" onFocus="geolocate()" type="text" />
                            <input type="button" value="Update" class="update_pickup_address update_address" />
                            </div>
                                

                            <div class="task-value" id="pic_up"> <div class="edit-btn"><span>pic_up</span><span>'.get_post_meta($post->ID,'pic_up',true).'</span>Edit</div><div class="task-item-value">'.get_post_meta($post->ID, 'pic_up', true).'</div></div>
                        </div>
                        <div class="task-item-detail">
                            <div class="task-labels">Delivered to:</div>
                            
                            <div class="address-field-delivery" style="display:none">
                            <input id="autocomplete2" style="width: 33%;font-size: 11px;padding: 8px;float: left; margin: 0px 7px 0px 0px;" placeholder="Enter your address" onFocus="geolocate2()" type="text" />
                            <input type="button" value="Update" class="update_delivery_address update_address" />
                            </div>
                            
                            <div class="task-value" id="delievery_address"> <div class="edit-btn"><span>delievery_address</span><span>'.get_post_meta($post->ID,'delievery_address',true).'</span>Edit</div><div class="task-item-value">'.get_post_meta($post->ID, 'delievery_address', true).'</div></div>
                        </div> 
                        
                        <div class="task-item-detail" style="display:none;">
                            <div class="task-labels">Extra Need:</div>
                            <div class="task-value" id="extra_need"> 
                                <div class="edit-btn">
                                <span>extra_need</span>
                                <span></span>Edit
								</div>
								<div class="task-item-value">'.$extra_result.'</div>
							</div>
                        </div> 
                  </div>';
        echo $html;

        $pic_up_address = get_post_meta($post->ID,'pic_up',true);
        $delivery_address = get_post_meta($post->ID,'delievery_address',true);

        $pic_up_address = get_post_meta($post->ID,'pic_up',true);
        $delivery_address = get_post_meta($post->ID,'delievery_address',true);

        $delivery_address_loc = get_post_meta($post->ID,'deliever_lat_long',true);
        $delivery_address_loc = explode('_',$delivery_address_loc);

        $pick_up_address = get_post_meta($post->ID,'pick_lat_long',true);
        $pick_up_address = explode('_',$pick_up_address);

        ?>
        <script>var marker1, marker2;
            var poly, geodesicPoly;
      function initMap() {
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 7,
          center: {lat: 41.85, lng: -87.65}
        });
        
         if(map) map.setOptions({ scrollwheel: false });
         /* var myOptions = { zoom : 3,center: {lat: 30.267153, lng: -97.74306079999997}};
         
            map.setOptions(myOptions); */

        directionsDisplay.setMap(map);
        calculateAndDisplayRoute(directionsService,directionsDisplay);
      
        /**
        * AutoComplete Address Fields
        **/
         initAutocomplete();

      }
      
     /*   function run_time(){
         alert("work");
          var myOptions = { zoom : 3,center: {lat: <?php echo $pick_up_address[0]?>, <?php echo $delivery_address_loc[1]?>}};
          map.setOptions(myOptions);
          return false; 
          
      }
      
      jQuery(document).ready(function(){
         setTimeout(function(){
                // run_time(); 
                var myOptions = { zoom : 3,center: {lat: 30.267153, lng: -97.74306079999997}};
map.setOptions(myOptions);
            }, 2000); 
      });
*/

      function calculateAndDisplayRoute(directionsService, directionsDisplay) {
        directionsService.route({
          origin: '<?php echo $pic_up_address?>',
          destination: '<?php echo $delivery_address?>',
          travelMode: 'DRIVING'
        }, function(response, status) {
          if (status === 'OK') {
               // if(map) map.setOptions({ scrollwheel: false });
            directionsDisplay.setDirections(response);
          } else {

                var map = new google.maps.Map(document.getElementById('map'), {
                    /*zoom: 4,
                    center: {lat: 34, lng: -40.605}*/
                });

                if(map) map.setOptions({ scrollwheel: false });

                map.controls[google.maps.ControlPosition.TOP_CENTER].push(
                    document.getElementById('info'));

                marker1 = new google.maps.Marker({
                    map: map,
                    draggable: false,
                    position: {lat: <?php echo $pick_up_address[0]?>, lng: <?php echo $pick_up_address[1]?>}
                });

                marker2 = new google.maps.Marker({
                    map: map,
                    draggable: false,
                    position: {lat: <?php echo $delivery_address_loc[0]?>, lng: <?php echo $delivery_address_loc[1]?>}
                });

                var bounds = new google.maps.LatLngBounds(
                    marker1.getPosition(), marker2.getPosition());
                map.fitBounds(bounds);

                google.maps.event.addListener(marker1, 'position_changed', update);
                google.maps.event.addListener(marker2, 'position_changed', update);

                poly = new google.maps.Polyline({
                    strokeColor: '#FF0000',
                    strokeOpacity: 1.0,
                    strokeWeight: 3,
                    map: map,
                });

                geodesicPoly = new google.maps.Polyline({
                    strokeColor: '#CC0099',
                    strokeOpacity: 1.0,
                    strokeWeight: 3,
                    geodesic: true,
                    map: map
                });
                update();

                /////////// MAP FIELDS/////////////
                /* setTimeout(function ()
                 {*/

                /*},2000); {*/
             }
          
          
        });
      }

            function update() {
                var path = [marker1.getPosition(), marker2.getPosition()];
                poly.setPath(path);
                geodesicPoly.setPath(path);
                var heading = google.maps.geometry.spherical.computeHeading(path[0], path[1]);
                document.getElementById('heading').value = heading;
                document.getElementById('origin').value = path[0].toString();
                document.getElementById('destination').value = path[1].toString();

            }

            function initAutocomplete() {

                autocomplete = new google.maps.places.Autocomplete(
                    /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
                    {types: ['geocode']});

                autocomplete2 = new google.maps.places.Autocomplete(
                    /** @type {!HTMLInputElement} */(document.getElementById('autocomplete2')),
                    {types: ['geocode']});
            }

            function geolocate() {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(function(position) {
                        var geolocation = {
                            lat: position.coords.latitude,
                            lng: position.coords.longitude
                        };
                        var circle = new google.maps.Circle({
                            center: geolocation,
                            radius: position.coords.accuracy
                        });
                        autocomplete.setBounds(circle.getBounds());
                    });
                }
            }

            function geolocate2() {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(function(position) {
                        var geolocation = {
                            lat: position.coords.latitude,
                            lng: position.coords.longitude
                        };
                        var circle = new google.maps.Circle({
                            center: geolocation,
                            radius: position.coords.accuracy
                        });
                        autocomplete2.setBounds(circle.getBounds());
                    });
                }
            } 
            //https://maps.googleapis.com/maps/api/js?key=AIzaSyCi7_en6OpMbjn7j0A251CVbLQkrHIk2_8&libraries=places&callback=initMap
            //AIzaSyB5T2Get99X0Ybu3Xbpl01SdVWux5upaAM
        </script>

        <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyCi7_en6OpMbjn7j0A251CVbLQkrHIk2_8&libraries=places&callback=initMap"
                async defer></script>

         <!-- <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyB5T2Get99X0Ybu3Xbpl01SdVWux5upaAM&libraries=places&callback=initAutocomplete"
        async defer></script> -->

        <script>
            jQuery(document).ready(function() {
                // When the Upload button is clicked...
                jQuery('body').on('change', '.upload-form .files-data-detail', function(e){
                    e.preventDefault();

                    var fd = new FormData();
                    var files_data = jQuery('.upload-form .files-data-detail'); // The <input type="file" /> field

                    // Loop through each data and create an array file[] containing our files data.
                    jQuery.each(jQuery(files_data), function(i, obj) {
                        jQuery.each(obj.files,function(j,file){
                            fd.append('files[' + j + ']', file);
                        })
                    });

                    // our AJAX identifier
                    fd.append('action', 'cvf_upload_files_detail');

                    // Remove this code if you do not want to associate your uploads to the current page.
                    fd.append('post_id', <?php echo $post->ID; ?>);
                    jQuery('.loader_animateds').show();
                    jQuery.ajax({
                        type: 'POST',
                        url: '<?php echo admin_url( 'admin-ajax.php' ); ?>',
                        data: fd,
                        contentType: false,
                        processData: false,
                        success: function(response){
                            jQuery('.task-profile-pic img').attr('src',response); // Append Server Response
                            jQuery('html, body').animate({
                                scrollTop: jQuery(".task-profile-pic").offset().top
                            }, 2000);
                            jQuery('.loader_animateds').hide();
                        }
                    });
                });
            });
            jQuery(document).ready(function(){
                jQuery('#change_photo_task').click(function(){
//                    jQuery('#taskchangephotos').show();
                    jQuery('#taskchangephotos').trigger('click');

                    //jQuery('#change_photo_task').hide();
                });
                jQuery('#add_photo_task').click(function(){
                    jQuery('#taskaddphotos').trigger('click');
                });
            });
        </script>

        <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCi7_en6OpMbjn7j0A251CVbLQkrHIk2_8&libraries=geometry&callback=init"
                 async defer></script>-->
    </main><!-- .site-main -->

    <?php //get_sidebar( 'content-bottom' ); ?>

</div><!-- .content-area -->

<?php //get_sidebar(); ?>
<?php get_footer(); ?>