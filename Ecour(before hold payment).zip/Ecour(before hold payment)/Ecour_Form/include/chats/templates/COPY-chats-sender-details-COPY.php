<?php get_header(); ?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
            <?php
            global $post;
            #step 1. GET CURRENT POST ID
            $post_ID =$_GET['task_id'];

            #step 2. GET AUTHOR ID BY POST ID
            $post_author = get_post_field( 'post_author', $post_ID );

            #GET CURRENT USER ID
            $user_id= get_current_user_id();
            $post_msgs = get_user_meta($post_author,'message',true);

            # step3. GET ALL CHATS BY AUTHOR ID
            #if($user_id == $post_author)

            ### FOR MESSAGE SEND ###
            echo '<form action="" method="POST">';
            echo '<div>
                 <textarea name="task_msg" class="task_msg" id="task_msg"> </textarea> 
                 <input type="submit" name="send_msg" class="send_msg" id="send_msg" value="SEND"> 
              </div>';
            echo '</form>';
            ### FOR MESSAGE SEND ###

            $html = '';
            $class = '';
            $html .= '<div class="chats">';
            foreach ($post_msgs as $value)
            {
                $user_id_in_msg = $value[3];
                $user_msg = $value[0];

                if($user_id == $value[3])
                    $class = 'msg-right';
                else
                    $class = 'msg-left';
                ## GET USERS INFO ##


                $user_photo = get_user_meta($value[3],'photo',true);
                if(empty($user_photo))
                {
                    $user_photo = get_avatar_url($value[3]);
                }
                $time_ago = humanTiming ($value[5]);
                //print_r($time_ago);

                $html .= '<div class="chat-msg '.$class.'"> <img src="'.$user_photo.'" />'  .$value[0] . ' ' .'<br>'. $time_ago.' ago'. '</div>';
                //$html .= $time_ago;

            }
            $html .= '</div>';
           // echo $html;
            /*echo '<pre>';
            print_r($post_msgs);
            echo '</pre>';*/


            if(isset($_POST['send_msg']))
            {
                $post_author = $post_author;
                $msg_detail = $_POST['task_msg'];
                $old_msg_detail = $post_msgs;
                $timing = date('F jS, Y, h:i:s ');	//current date and time
                if(!empty($old_msg_detail))
                {
                    $msg_detail = explode('|',$msg_detail);
                    $msg_detail[] = '';
                    $msg_detail[] = '';
                    $msg_detail[] = $user_id;
                    $msg_detail[] = $post_ID;
                    $msg_detail[] = $timing;
                    $new_msg_detail = $old_msg_detail;
                    $new_msg_detail[] = $msg_detail;
                    update_user_meta($post_author,'message',$new_msg_detail);
                    echo '<pre>';
                    echo print_r(get_user_meta($post_author,'message',true));
                    echo '</pre>';
                }
                else
                {
                    $msg_detail = explode('|',$msg_detail);
                    $msg_detail[] = '';
                    $msg_detail[] = '';
                    $msg_detail[] = $user_id;
                    $msg_detail[] = $post_ID;
                    $msg_detail[] = $timing;
                    $new_msg_detail[] = $msg_detail;
                    update_user_meta($post_author,'message',$new_msg_detail);
                    echo '<pre>';
                    echo print_r(get_user_meta($post_author,'message',true));
                    echo '</pre>';
                }
            }

            #print_r($post_msgs);

            ##count time ago##
            function humanTiming ($time)
            {
                $time = strtotime($time);
                $time = time() - $time; // to get the time since that moment
                $time = ($time<1)? 1 : $time;
                $tokens = array (
                    31536000 => 'year',
                    2592000 => 'month',
                    604800 => 'week',
                    86400 => 'day',
                    3600 => 'hour',
                    60 => 'minute',
                    1 => 'second',
                );
                foreach ($tokens as $unit => $text)
                {
                    if ($time < $unit) continue;
                    $numberOfUnits = floor($time / $unit);
                    return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'');
                }
            }

            ?>
        </main><!-- .site-main -->
    </div><!-- .content-area -->
<?php get_footer(); ?>