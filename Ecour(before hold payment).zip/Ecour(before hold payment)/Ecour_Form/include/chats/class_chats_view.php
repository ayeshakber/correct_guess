<?php

/**
 * Created by PhpStorm.
 * User: Ayesha
 * Date: 9/29/2016
 * Time: 5:14 PM
 */
class class_chats_view
{
    public function __construct()
    {
        add_filter( 'template_include', array($this,'get_msgs_template'), 99 );
        #add_shortcode( 'sender_bring_chats', array($this,'get_msgs_template') );
        
        ### FOR CHATS###
        add_action( 'wp_footer', array($this,'chats_msgs_javascript') );
        add_action( 'wp_ajax_chats_msgs', array($this,'chats_msgs_callback') );
        add_action( 'wp_ajax_nopriv_chats_msgs', array($this,'chats_msgs_callback') );
        add_action( 'bringer_sender_chat', array($this,'bringer_sender_chat'),10,2 );
        
        #### FOR OFFFER####
        add_action( 'wp_footer', array($this,'offers_msgs_javascript') );
        /* add_action( 'wp_ajax_offers_msgs', array($this,'offers_msgs_callback') );
        add_action( 'wp_ajax_nopriv_offers_msgs', array($this,'offers_msgs_callback') ); */

        ##PAYMENT SUCCESSFULLY###
         //add_action( 'wp_footer', array($this,'payment_successfully') );
        add_shortcode('payment_successfully', array($this,'payment_successfully') );
    }

    function get_msgs_template($template)
    {
        $user_id = get_current_user_id();
        if ( is_page('chats'))
        {
            $user_template =  dirname(__FILE__) . "/templates/chats-sender-details.php";
            if ( '' != $user_template ) {
                return $user_template ;
            }
        }
        
        if ( is_page('offer'))
        {
           /* $user_template =  dirname(__FILE__) . "/templates/offers-sender-details.php";
            if ( '' != $user_template ) {
                return $user_template ;
            }*/
           global $post;
            $post_ID = $_GET['task_id'];
             /* print_r( $post_ID);
              print_r( 'POst id using get post func');
            die();*/
            $current_user = get_current_user_id();
            $get_user_id = $_GET['user_id'];
            $post_author = get_post_field( 'post_author', $post_ID );
        /* print_r($post_author);
            die();*/
            if($current_user == $post_author)
            {
                $user_template =  dirname(__FILE__) . "/templates/offers-sender-details.php";
                if ( '' != $user_template ) {
                    return $user_template ;
                }
            }
            else
            {
               $user_template =  dirname(__FILE__) . "/templates/offers-bringer-details.php";
                if ( '' != $user_template ) {
                    return $user_template ;
                } 
            }
        }
        return $template;
    }

    function chats_msgs_javascript() {
        if( is_singular( 'task' ) == false && is_page('chats') == false )
            return;
        ?>
        <script type="text/javascript" >

            /* Make this document ready function to work on click where you want */
            jQuery(document).ready(function($) {

                /* In front end of WordPress we have to define ajaxurl */
                ///////////////////////////
                var ajaxurl2 = '<?php echo PLUGIN_HTTP_URL . 'include/chats/test.php' ?>';
                
                var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
				
                if(jQuery('.chat-msg').length)
					var old_chat = jQuery('.chat-msg').length;
                else
					var old_chat = 0;
                var postid = jQuery('#post_ID').val();
                setInterval(function() {
                    $('#links').load('test.php',function () {
                        $(this).unwrap();
                    });
                    var data = {
                        'action': 'chats_msgs',
                        'postid' : postid,
                        'request' : 'chat_update'
                    };
                    $.post(ajaxurl2, data, function(response) {
                        //alert(response);
                        //var old_chat = jQuery('.chats').html();
						if(response.match(/chat-msg/g))
							var current_chat = response.match(/chat-msg/g).length;
                        else
							var current_chat = 0;
						
                        console.log("old: "+old_chat);
                        console.log("current: "+current_chat);
                        if(old_chat != current_chat) {
                            old_chat = current_chat;
                            jQuery('.chats').html(response);
                            $(".chats").css('height','auto');
                            $(".chats").animate({ scrollTop: $(".chats").height() }, "slow");
                            $(".chats").css('height','300px');
                        }

                    });
                }, 3000);

                jQuery('#send_msg').click(function() {
                    /* You can get this value from some hidden field or div */
                    var get_msg= jQuery('#task_msg').val();
                    var sender_id= jQuery('#sender_ID').val();
                    var postid= jQuery('#post_ID').val();
                    var user_ID = jQuery('#user_ID').val();

                    console.log(get_msg + ' ' +sender_id + ' ' +postid);
                    var data = {
                        'action': 'chats_msgs',
                        'sender_id' : sender_id,
                        'notify_to' : user_ID,
                        'get_msg' : get_msg,
                        'request' : 'msg_send',
                        'postid' : postid,
                    };
                    $.post(ajaxurl2, data, function(response) {
                        var temp = new Array();
                        temp = response.split("|");
                        var old_msg = jQuery('.chats').html();
                        var row = '<div class="chat-msg msg-right"> <img src="http://0.gravatar.com/avatar/95c5c02df2c06e97c2775002e7adc134?s=96&amp;d=mm&amp;r=g"> ' + temp[1] + '<br>'+ temp[0] +'</div>';
                        jQuery('.chats').html(old_msg);
                        jQuery('.chats').append(row);
                        jQuery('#task_msg').val('');
                      // alert(response);
                    });
                });
                //////////////
            });
        </script> <?php
    }

    function chats_msgs_callback()
    {
        $user_id = get_current_user_id();
        $post_ID =  $_POST['postid'];
        $sender_id =  $_POST['sender_id'];
        $msg_detail =  $_POST['get_msg'];

        if($_POST['request'] == 'msg_send') {
                $post_author = get_post_field( 'post_author', $post_ID );
                $timing = date('F jS, Y, h:i:s ');  //current date and time
                $old_msg_detail = get_post_meta($post_ID,'message',true);

                if(!empty($old_msg_detail))
                {
                    $msg_detail = explode('|',$msg_detail);
                    $msg_detail[] = '';
                    $msg_detail[] = '';
                    $msg_detail[] = $user_id;
                    $msg_detail[] = $post_ID;
                    $msg_detail[] = $timing;
                    $new_msg_detail = $old_msg_detail;
                    $new_msg_detail[] = $msg_detail;
                    #update_user_meta($post_author,'message',$new_msg_detail);
                    update_post_meta($post_ID,'message',$new_msg_detail);
                    #update_post_meta($post_ID,'message2',$new_msg_detail);
                    #print_r(get_user_meta($post_author,'message',true));
                    #NOTIFICATION #
                    $__post = get_post($post_ID);
                    $old_notify = get_user_meta($sender_id,'notify',true);
                    $user_index = count($old_notify) - 1;
                    #$msg = explode('|',$_POST['message_details']);
                    $notify['Type'] = 'Message';
                    $notify['read'] = '0';
                    $notify['text'] = 'New Message';
                    $notify['msg'] = $msg_detail;
                    $notify['m_uid'] = $old_notify[$user_index]['m_uid'];
                    $notify['t_id'] = $post_ID;
                    $notify['t_uid'] = $__post->post_author;
                    $new_notify = $old_notify;
                    $new_notify[] = $notify;
                    update_user_meta(51,'notify','test');
                    #NOTIFICATION #
                }
                else
                {
                    $msg_detail = explode('|',$msg_detail);
                    $msg_detail[] = '';
                    $msg_detail[] = '';
                    $msg_detail[] = $user_id;
                    $msg_detail[] = $post_ID;
                    $msg_detail[] = $timing;
                    $new_msg_detail[] = $msg_detail;
                    #update_user_meta($post_author,'message',$new_msg_detail);
                    update_post_meta($post_ID,'message',$new_msg_detail);
                   # print_r(get_user_meta($post_author,'message',true));
                   # NOTIFICATION #
                    $old_notify = get_user_meta($sender_id,'notify',true);
                   #$msg = explode('|',$_POST['message_details']);
                    $notify['Type'] = 'Message';
                    $notify['read'] = '0';
                    $notify['text'] = 'New Message';
                    $notify['msg'] = $msg_detail;
                    $notify['m_uid'] = $user_id;
                    $notify['t_id'] = $post_ID;
                    $new_notify = $old_notify;
                    $new_notify[] = $notify;

                    update_user_meta($sender_id,'notify2',$new_notify);
                    # NOTIFICATION #
                }
            $result = $timing.'|'.$_POST['get_msg'];
            print_r($result);
        }
        else if($_POST['request'] == 'chat_update') {
            global $post;
            $post_author = get_post_field( 'post_author', $post_ID );
            #GET CURRENT USER ID
            $user_id= get_current_user_id();
            $post_msgs = get_post_meta($post_ID,'message',true);
            $html ='';
            $class = '';
           #$html .= '<div class="chats">' ;
            if(!empty($post_msgs)) 
            {
                foreach ($post_msgs as $value)  
                {
                    $user_id_in_msg = $value[3];
                    $user_msg = $value[0];
                    if($user_id == $value[3])
                        $class = 'msg-right';
                    else
                        $class = 'msg-left';
                    $user_photo = get_user_meta($value[3],'photo',true);
                    $user_info_at_chat = get_userdata($value[3]);
                   /* echo "<pre>";
                    print_r($user_info_at_chat);
                    echo "</pre>";*/
                    $chat_user_name = $user_info_at_chat->display_name;
                    #print_r($chat_user_name);
                    if(empty($user_photo))
                    {
                        $user_photo = get_avatar_url($value[3]);
                    }
                    $time_ago = $this->humanTiming($value[5]);
                    #print_r($time_ago);
                    $html .= '<div class="chat-msg '.$class.'"> <img src="'.$user_photo.'" width="40"/>'  .$value[0] . ' ' .'<br>'.$chat_user_name. '<br>'.$time_ago.' ago'. '</div>';
                    #$html .= $time_ago;
                } #<div class="chat-user-name">'.$chat_user_name.'</div>
            }
            $html .= '</div>';
            #$html .= '</div>';
            echo $html;
            #print_r($html);
        }
        die(); #this is required to terminate immediately and return a proper response
    }
    function humanTiming ($time)
    {
        $time = strtotime($time);
        $time = time() - $time; // to get the time since that moment
        $time = ($time<1)? 1 : $time;
        $tokens = array (
            31536000 => 'year',
            2592000 => 'month',
            604800 => 'week',
            86400 => 'day',
            3600 => 'hour',
            60 => 'minute',
            1 => 'second',
        );
        foreach ($tokens as $unit => $text)
        {
            if ($time < $unit) continue;
            $numberOfUnits = floor($time / $unit);
            return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'');
        }
    }

    ### FOR OFFER ####
     function offers_msgs_javascript() 
     {
         ?>
          <script type="text/javascript" >

            /* Make this document ready function to work on click where you want */
            jQuery(document).ready(function($) 
            {
                jQuery('.accept-offer').click(function()
                {
                    alert('Offer Accepted');
                    
                });
            });
        </script> 
        <?php
     }

     public function bringer_sender_chat($task_id, $hide_extra = 0) 
     {
        global $post;
        #step 1. GET CURRENT POST ID
        $post_ID = $task_id;
        #step 2. GET AUTHOR ID BY POST ID
        $post_author = get_post_field( 'post_author', $post_ID );
        $post_name = get_post_field( 'post_name', $post_ID );
        global $current_user;
        #GET CURRENT USER ID
        # $user_id= get_current_user_id();
        $user_id= $current_user->ID ;
        #$current_user= wp_get_current_user();
        $post_msgs = get_post_meta($post_ID,'message',true);
        # step3. GET ALL CHATS BY AUTHOR ID
        ### FOR MESSAGE SEND ###
        $html = '';
        $class = '';
        ### FOR MESSAGE SEND ###
        $user_info = get_userdata($post_author);

        $post_interested = get_post_meta($post_ID,'task_offers',true);
        $post_accepted = get_post_meta($post_ID,'offer_accepted',true);
		// var_dump($post_accepted); 
        /*echo "<br>Post ID:";
        print_r($post_ID);
        echo "<br>Post Author ID:";
        print_r($post_author);
        echo "<br>Current user ID:";
        print_r($user_id);
        echo "<br>Post Interested ID:";
        print_r($post_interested);
        echo "<br>Offer Accepted ID:";
        print_r($post_accepted);*/
        if($hide_extra != 1) 
        {
            $html .= '<div class="conversation-user">Conversation with '.$user_info->user_login.'</div>';

            $html .= '<div class="conversation-notify">Make certain you make an offer and it is accepted. Once it\'s accepted the item will be insured and you\'ll be paid after delivery.</div>';

            $html .= '<div class="load-msg-btn"><button>LOAD PREVIOUS MESSAGES</button></div>';
        }
         $html .= '<div class="chats">';
         $counter = 0;
         if(!empty($post_msgs)) {
             foreach ($post_msgs as $value)  {

                 $user_id_in_msg = $value[3];
                 $user_msg = $value[0];
                 if($user_id == $value[3])
                     $class = 'msg-right';
                 else
                     $class = 'msg-left';
                 $user_photo = get_user_meta($value[3],'photo',true);
                 if(empty($user_photo))
                 {
                    $user_photo = get_avatar_url($value[3]);
                 }
                 $time_ago = $this->humanTiming ($value[5]);
                 #print_r($time_ago);
                 $user_info_at_chat = get_userdata($value[3]);
                  /*  echo "<pre>";
                    print_r($user_info_at_chat);
                    echo "</pre>";*/
                    $chat_user_name = $user_info_at_chat->display_name;
                    #print_r($chat_user_name);

                 $html .= '<div class="chat-msg '.$class.'"> <img src="'.$user_photo.'" width="40"/><div class="chat-user-name">'.$chat_user_name.'</div> <div class="msg-body"> <div class="trip"></div>  <p class="user-msg">' .$value[0] . '</p> ' .'<p>'. $time_ago.' ago</p> </div>'. '</div>';
                 #$html .= $time_ago;
             }
         }
         $html .= '</div>';
         $html .= '<div class="chat-box">
                     <textarea name="task_msg" class="task_msg" id="task_msg"></textarea> 
                     <input type="button" name="send_msg" class="send_msg" id="send_msg" value="SEND"> 
                     <input type="hidden" name="sender_ID" class="sender_ID" id="sender_ID" value="'.$user_id.'"> 
                     <input type="hidden" name="post_ID" class="post_ID" id="post_ID" value="'.$post_ID.'">
                     <input type="hidden" name="user_id" class="user_ID" id="user_ID" value="'.$_GET['user_id'].'">
                 <div>';
            ############AISHA CHAT USER DETAIL#############
              ##########AISHA BRINGER DETAIL######
        //global $post;
        #step 1. GET CURRENT POST ID
        #$post_ID =$_GET['task_id'];
        //$post_ID =$post->ID;
            //$post_ID = $_GET['task_id'];
            $get_user_id = $_GET['user_id'];
           /* echo "<br> $ GET USER ID:";
            print_r($get_user_id );*/

            $post_ID = $task_id;
            #print_r($post_ID);
        #step 2. GET AUTHOR ID BY POST ID
        //$post_author = get_post_field( 'post_author', $post_ID );
        /*print_r($post_author);
        print_r('POST ID Sender');
        die('sender');*/
        #GET CURRENT USER ID
        //$user_id = get_current_user_id();
        if(!empty($post_interested))
        {
            $user_id_in_msg ='';
             $post_accepted = get_post_meta($post_ID,'offer_accepted',true);
             $user_name='';
             $user_email='';
             $user_phone='';
             $user_photo='';
             $profile_link='';
             $stripe_payment ='';
             foreach ($post_interested as $value)
            {
                $user_id_in_msg = $value[3];
                #print_r($user_id_in_msg );
                $user_msg = $value[0];
                #print_r($get_user_id );
                ####### $post_author == post author id
                ####### $user_id == current user id
                /*echo "<br>current USER id:";
                print_r($user_id);*/
                /* echo "<br>current POST USER id:";
                print_r($post_author);*/
                if($user_id == $post_author)
                {
                    $user_info = get_userdata($user_id_in_msg);
                    $user_name = $user_info->display_name;
                    $user_email = $user_info->user_email;
                    $user_phone = get_user_meta($get_user_id,'user_phone',true);
                    $profile_link = get_permalink(get_page_by_path('ecour-profile-page')).$user_id_in_msg;
                    /*$user_msg = $value[0];
                     $offer_date = $value[2];
                     $time_ago = humanTiming ($value[2]);*/
                     $user_photo = get_user_meta($user_id_in_msg,'photo',true);
                    if(empty($user_photo))
                    {
                        $user_photo = get_avatar_url($user_id_in_msg);
                    } 
                    ###check task is in process
                    $task_completed = get_post_meta($post_ID,'task_completed',true);
                  /*  echo "<br> TASK COMPLETED";
                   print_r($task_completed);*/
                    if(empty($task_completed))
                    {
                        $stripe_payment = 'Please Wait! Your Task is Being Process.';
                    }
                    else
                    {
                        $payment_price = get_post_meta($post_ID, 'payable', true );
                        //$stripe_payment = do_shortcode ('[accept_stripe_payment button_text="Press when task is delivered" ]');
                        $stripe_payment = do_shortcode ('[accept_stripe_payment name="'.$post_name.'" price="'.$payment_price.'" url="http://ecour.startupbug.net/stripe-checkout-result/" button_text="Press when task is delivered" currency="GBP"] ');
                        

                    }
                }
                else 
                {
                    $user_info = get_userdata($post_author);
                    $user_name = $user_info->display_name;
                    $user_email = $user_info->user_email;
                    $user_phone = get_user_meta($get_user_id,'user_phone',true);
                    $profile_link = get_permalink(get_page_by_path('ecour-profile-page')).$post_author;
                    /*$user_msg = $value[0];
                     $offer_date = $value[2];
                     $time_ago = humanTiming ($value[2]);*/
                     $user_photo = get_user_meta($post_author,'photo',true);
                    if(empty($user_photo))
                    {
                       $user_photo = get_avatar_url($post_author);
                    } 
                    ## START task completed action
                    ###check task is in process
                    $task_completed = get_post_meta($post_ID,'task_completed',true);
                   /* echo "<br> TASK COMPLETED";
                   print_r($task_completed);*/
                    if(empty($task_completed))
                    {
                        # echo "hekkfd ";
                        $stripe_payment = '<form action="" method="POST" > <div class="accept"><input type="submit" class="bringer-accept" value="Press when task is delivered" name="bringer_accept" /></div></form>';
                    }
                    else
                    {
                        $stripe_payment='This Task has been CONFIRMED!.';
                    }

                    #$task_completed='';
                    if(isset($_POST['bringer_accept']))
                    {
                        #$post_ID = $_GET['task_id'];
                        #$get_user_id = $_GET['user_id'];
                        $task_completed = update_post_meta($post_ID,'task_completed',$user_id);
                        ##############
                           $user_completed = get_user_meta($user_id,'task_completed',true);
                            if(!empty($user_completed))
                            {
                                $user_completed = update_user_meta($user_id,'task_completed',$user_completed.'_'.$post_ID);
                            }
                            else
                            {
                                $user_completed = update_user_meta($user_id,'task_completed',$post_ID);

                            }

                        ########################################
                        #$user_completed = update_user_meta($user_id,'task_completed',$post_ID);
                        
                        ##############
                        $task_completed = 'Thank You! You have been Delevered Your Task.';
                        echo $task_completed ;
                    }
                     ## END task completed action
                }
            }
             $html .='<div class="chat_user_show">
             <div class><img src="'.$user_photo.'" width="40"/></div>
                    <div><a href="'.$profile_link.'">'.$user_name.'</a></div>                   
                    <div>'.$user_email.'</div>                  
                    <div>'.$user_phone.'</div>';
                    $html .= '<div>';
                    $user_views = get_user_meta($user_id_in_msg,'user_rate_on_profile',true);
                   /* echo "USER VIEWS:";
                    print_r($user_views);*/
                    if(!empty($user_views))
                    {
                        $view_count = count($user_views);
                        $average = 0;
                        $rating_1 = 0;
                        foreach ($user_views as $rating)
                        {
                            $rating_1 += $rating['user_rating'];
                            $average = $rating_1 / count($user_views);
                           /* echo '<br>';*/
                            $average  = round($average , 1);
                            #print_r($average);
                        }
                        $html .= '<div class="average"> '. do_shortcode('[user-average-ratings user_id="'.$_GET["user_id"].'"]') .' &#9733;</div>';
                        $html .='<div class="reviews-count"> '.(count($user_views).'reviews').'</div>';
                    }
                     $html .='<div class="task-completed">'.$stripe_payment.'</div>';
                    $html .= '</div>';
                $html .= '</div>';
        }
        ##########AISHA BRINGER DETAIL######      
            ############AISHA CHAT USER DETAIL#############
        echo $html;

     }

     ### AFTER PAYMENT##
     function payment_successfully()
     {
         /*global $post;
         print_r($post->ID);*/
        $post_ID = $_SESSION['post_ID'];
        #print_r($_SESSION['post_ID']);
        update_post_meta($post_ID,'successfull_task','1');
     }
}   #end Class
