<?php

include '../../../../../wp-config.php';

$user_id = get_current_user_id();

        $post_ID =  $_POST['postid'];
        $sender_id =  $_POST['sender_id'];
        $msg_detail =  $_POST['get_msg'];

        if($_POST['request'] == 'msg_send') {
                $post_author = get_post_field( 'post_author', $post_ID );

                $timing = date('F jS, Y, h:i:s ');	//current date and time
                $old_msg_detail = get_post_meta($post_ID,'message',true);
                if(!empty($old_msg_detail))
                {
                    $msg_detail = explode('|',$msg_detail);
                    $msg_detail[] = '';
                    $msg_detail[] = '';
                    $msg_detail[] = $user_id;
                    $msg_detail[] = $post_ID;
                    $msg_detail[] = $timing;
                    $new_msg_detail = $old_msg_detail;
                    $new_msg_detail[] = $msg_detail;
                    //update_user_meta($post_author,'message',$new_msg_detail);
                    update_post_meta($post_ID,'message',$new_msg_detail);

                    // NOTIFICATION //
                    $old_notify = get_user_meta($_POST['notify_to'],'notify',true);
                    $user_index = count($old_notify) - 1;
                    // $msg = explode('|',$_POST['message_details']);
                    $notify['Type'] = 'Message';
                    $notify['read'] = '0';
                    $notify['text'] = 'New Message';
                    $notify['msg'] = $msg_detail[0];
                    $notify['m_uid'] = $user_id;
                    $notify['t_id'] = $post_ID;

                    $new_notify = $old_notify;
                    $new_notify[] = $notify;

                    update_user_meta($_POST['notify_to'],'notify',$new_notify);
                    //update_user_meta($notify['m_uid'],'notify',$new_notify);
                    // NOTIFICATION //

                   #print_r(get_user_meta($post_author,'message',true));

                }
                else
                {
                    $msg_detail = explode('|',$msg_detail);
                    $msg_detail[] = '';
                    $msg_detail[] = '';
                    $msg_detail[] = $user_id;
                    $msg_detail[] = $post_ID;
                    $msg_detail[] = $timing;
                    $new_msg_detail[] = $msg_detail;
                    //update_user_meta($post_author,'message',$new_msg_detail);
                    update_post_meta($post_ID,'message',$new_msg_detail);

                    // NOTIFICATION //
                    $old_notify = get_user_meta($user_id,'notify',true);
                    // $msg = explode('|',$_POST['message_details']);
                    $notify['Type'] = 'Message';
                    $notify['read'] = '0';
                    $notify['text'] = 'New Message';
                    $notify['msg'] = $msg_detail;
                    $notify['m_uid'] = $sender_id;
                    $notify['t_id'] = $post_ID;

                    $new_notify = $old_notify;
                    $new_notify[] = $notify;

                    update_user_meta($user_id,'notify',$new_notify);
                    // NOTIFICATION //
                   # print_r(get_user_meta($post_author,'message',true));

                }
            $result = $timing.'|'.$_POST['get_msg'];
            print_r($result);
        }
        else if($_POST['request'] == 'chat_update') {
            global $post;

            $post_author = get_post_field( 'post_author', $post_ID );

            #GET CURRENT USER ID
            $user_id= get_current_user_id();
            $post_msgs = get_post_meta($post_ID,'message',true);

            $html ='';
            $class = '';
           #$html .= '<div class="chats">';
            if(!empty($post_msgs)) {
                foreach ($post_msgs as $value)  {
                    $user_id_in_msg = $value[3];
                    $user_msg = $value[0];

                    if($user_id == $value[3])
                        $class = 'msg-right';
                    else
                        $class = 'msg-left';

                    $user_photo = get_user_meta($value[3],'profile_pic',true);
                    if(empty($user_photo))
                    {
                        $user_photo = get_avatar_url($value[3]);
                    }
                    $time_ago = humanTiming ($value[5]);
                    #print_r($time_ago);

                    $html .= '<div class="chat-msg '.$class.'"> <img src="'.$user_photo.'" width="40"/> <div class="msg-body"> <div class="trip"></div> <p class="user-msg">' .$value[0] . '</p> ' .'<p>'. $time_ago.' ago</p> </div>'. '</div>';
                    #$html .= $time_ago;
                }
            }
            $html .= '</div>';
            #$html .= '</div>';
            echo $html;
		}
	


	
		function humanTiming ($time)
    {
        $time = strtotime($time);
        $time = time() - $time; // to get the time since that moment
        $time = ($time<1)? 1 : $time;
        $tokens = array (
            31536000 => 'year',
            2592000 => 'month',
            604800 => 'week',
            86400 => 'day',
            3600 => 'hour',
            60 => 'minute',
            1 => 'second',
        );
        foreach ($tokens as $unit => $text)
        {
            if ($time < $unit) continue;
            $numberOfUnits = floor($time / $unit);
            return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'');
        }
    }