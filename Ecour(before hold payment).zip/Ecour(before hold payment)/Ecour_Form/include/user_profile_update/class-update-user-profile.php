<?php
Class update_user_profile{
	 public function __construct() {
		 add_filter( 'template_include', array($this,'update_user_profile'), 99 );
		 add_action('save_information',array($this,'userpost_paymentdata'));
		 add_action('save_information',array($this,'update_user_coupon_info'));
		 add_action('save_information',array($this,'user_profile_update_info'));
		 add_action('save_information',array($this,'user_paymentinfo_bank'));
         add_action('wp_ajax_cvf_upload_files1', array($this,'cvf_upload_files1'));
         add_action('wp_ajax_nopriv_cvf_upload_files1', array($this,'cvf_upload_files1')); // Allow front-end submission
	 }


    function cvf_upload_files1(){
        //$parent_post_id = isset( $_POST['post_id'] ) ? $_POST['post_id'] : 0;  // The parent ID of our attachments
        $valid_formats = array("jpg", "png", "gif", "bmp", "jpeg"); // Supported file types
        $max_file_size = 1024 * 500; // in kb
        $max_image_upload = 10; // Define how many images can be uploaded to the current post
        $wp_upload_dir = wp_upload_dir();
        $path = $wp_upload_dir['path'] . '/';
        $count = 0;
        $user_id = get_current_user_id();
        // Create post object
        $my_post = array(
            'post_title'    => 'asbn',
            'post_content'  => 'dfsdf',
            'post_status'   => 'publish',
            'post_author'   => $user_id
        );

// Insert the post into the database
        $prof_id = wp_insert_post( $my_post );
        $attachments = get_posts( array(
            'post_type'         => 'attachment',
            'posts_per_page'    => -1,
            'post_parent'       => $prof_id,
            'exclude'           => get_post_thumbnail_id() // Exclude post thumbnail to the attachment count
        ) );

        // Image upload handler
        if( $_SERVER['REQUEST_METHOD'] == "POST" ){

            // Check if user is trying to upload more than the allowed number of images for the current post
            if( ( count( $attachments ) + count( $_FILES['files']['name'] ) ) > $max_image_upload ) {
                $upload_message[] = "Sorry you can only upload " . $max_image_upload . " images for each Ad";
            } else {

                foreach ( $_FILES['files']['name'] as $f => $name ) {
                    $extension = pathinfo( $name, PATHINFO_EXTENSION );
                    // Generate a randon code for each file name
                    $new_filename = $this->cvf_td_generate_random_code1( 20 )  . '.' . $extension;

                    if ( $_FILES['files']['error'][$f] == 4 ) {
                        continue;
                    }

                    if ( $_FILES['files']['error'][$f] == 0 ) {
                        
                        if( ! in_array( strtolower( $extension ), $valid_formats ) ){
                            $upload_message[] = "$name is not a valid format";
                            continue;

                        } else{
                            // If no errors, upload the file...
                            if( move_uploaded_file( $_FILES["files"]["tmp_name"][$f], $path.$new_filename ) ) {

                                $count++;

                                $filename = $path.$new_filename;
                                $filetype = wp_check_filetype( basename( $filename ), null );
                                $wp_upload_dir = wp_upload_dir();
                                $attachment = array(
                                    'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ),
                                    'post_mime_type' => $filetype['type'],
                                    'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
                                    'post_content'   => '',
                                    'post_status'    => 'inherit'
                                );
                                // Insert attachment to the database
                                $attach_id = wp_insert_attachment( $attachment, $filename, $prof_id );

                                require_once( ABSPATH . 'wp-admin/includes/image.php' );

                                // Generate meta data
                                $attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
                                wp_update_attachment_metadata( $attach_id, $attach_data );
                                $profile_pics =  wp_get_attachment_url( $attach_id );
                                update_user_meta($user_id,'profile_pic',$profile_pics);
                            }
                        }
                    }
                }
            }
        }
        // Loop through each error then output it to the screen
        if ( isset( $upload_message ) ) :
            foreach ( $upload_message as $msg ){
                printf( __('<p class="bg-danger">%s</p>', 'wp-trade'), $msg );
            }
        endif;

        // If no error, show success message
        if( $count != 0 ){
			// echo "Successfull Profile picture Upload";
			?>
			<img src="<?php echo $profile_pics;?>" style="width:150px; height:150px;"/>
			<?php
        }

        exit();
    }

// Random code generator used for file names.
    function cvf_td_generate_random_code1($length=10) {

        $string = '';
        $characters = "23456789ABCDEFHJKLMNPRTVWXYZabcdefghijklmnopqrstuvwxyz";

        for ($p = 0; $p < $length; $p++) {
            $string .= $characters[mt_rand(0, strlen($characters)-1)];
        }

        return $string;

    }
	 public function update_user_profile( $template ){
		global $post;

        if ( is_page('user-information') ) { // CUSTOM TEMPLATE PAGE FOR TASK & IS NOT POST AUTHOR
            $new_template =  dirname(__FILE__) . "/templates/user-information.php" ;
            if ( '' != $new_template ) {
                return $new_template ;
            }
        }
		
		return $template;
	 }
	 public function userpost_paymentdata(){
		 if(isset($_POST["payment_info_btn"])){
			 $user_id = get_current_user_id();
			 $cardholder_name = $_POST["cardholder_name"];
			 $credit_card_number = $_POST["credit_card_number"];
			 $credit_card_exp_month = $_POST["credit_card_exp_month"];
			 $credit_card_exp_year = $_POST["credit_card_exp_year"];
			 $cvvs = $_POST["cvvs"];
			 
			 update_user_meta($user_id,'cardholder_name',$cardholder_name);
			 //update_user_meta($user_id,'credit_card_number',$credit_card_number);
			 $card_info =array(
            'card_num'=>$credit_card_number,
            'card_csv'=>$cvvs,
			);
			$credit_card = update_user_meta($user_id,'credit_card_detail',$card_info);
			 update_user_meta($user_id,'credit_card_exp_month',$credit_card_exp_month);
			 update_user_meta($user_id,'credit_card_exp_year',$credit_card_exp_year);
			 update_user_meta($user_id,'cvv',$cvvs);
			 $message = '<div class="add-card-msg">Successful payment information.</div>';
			 echo $message;
		 }
	 }
	 public function user_paymentinfo_bank(){
		 if(isset($_POST["bank_account_save"])){
			 $user_id = get_current_user_id();
			 $personal = $_POST["personal"];
			 $ac_holder_name = $_POST["ac_holder_name"];
			 $ac_holder_no = $_POST["ac_holder_no"];
			 $routing_ac_holder_no = $_POST["routing_ac_holder_no"];
			 $currencys = $_POST["currencys"];
			 $country = $_POST["country"];
			 
			 update_user_meta($user_id,'banck_ac_type',$personal);
			 update_user_meta($user_id,'bank_account_holder_name',$ac_holder_name);
			 update_user_meta($user_id,'bank_account_number',$ac_holder_no);
			 update_user_meta($user_id,'bank_rounting_number',$routing_ac_holder_no);
			 update_user_meta($user_id,'currency',$currencys);
			 update_user_meta($user_id,'country',$country);
			 $message = "Successful bank account information";
			 echo $message;
		 }
	 }
	 public function update_user_coupon_info()
	 {
		 if(isset($_POST["redeem_button"]))
		 {
			 $user_ids = get_current_user_id();
			  $code_coupon = $_POST["code_coupon"];
			  $current_date = date('Y-m-d');
			if ( ! is_admin() ) 
			{
				require_once( ABSPATH . 'wp-admin/includes/post.php' );
			}
			$coupon = post_exists($code_coupon);
			
			if(!empty($coupon))
			{
				$page = get_page_by_title($code_coupon, OBJECT, 'couponcode');
				$exp_date = get_post_meta($page->ID,'expiry_coupon_date',true);
				$datetime1 = strtotime($current_date);
				$datetime2 = strtotime($exp_date);
				if($datetime2 > $datetime1) 
				{
				  	update_user_meta($user_ids,'code_coupon',$code_coupon);
					$messages = "Successful Coupon information added";
					echo $messages;
				} 
				else 
				{
						echo "Coupon Code Expiry";
				}
			
			}
			else
			{
				echo 'Error in coupon';
			}
			  
			 
		 }
	 }
	 public function user_profile_update_info()
	 {
		 if(isset($_POST["update_info_btn"]))
		 {
			 $user_idss = get_current_user_id();
			 $profile_uploads_img = $_FILES["profile_uploads_img"]["name"];
			 $firstname = $_POST["firstname"];
			 $lastname = $_POST["lastname"];
			 $email = $_POST["email"];
			  $address = $_POST["address"];
			 $user_country_phone_code = $_POST["user_country_phone_code"];
			 $country_ph_number = $_POST["country_ph_number"];
			 
			 $old_pass = $_POST["old_pass"];
			 $new_pass = $_POST["new_pass"];
			 $args = array(
						'ID'         => $user_idss,
						'user_email' => esc_attr( $email )
					);
			 $useremail = wp_update_user( $args );
			 if(empty($useremail)){
				 echo "email address already exit";
			 }
			 update_user_meta($user_idss,'first_name',$firstname);
			 update_user_meta($user_idss,'last_name',$lastname);
			 update_user_meta($user_idss,'nickname',$email);
			 update_user_meta($user_idss,'user_location',$address);
			 update_user_meta($user_idss,'user_phone',$country_ph_number);
			 update_user_meta($user_idss,'user_country_code',$user_country_phone_code.'_'.$country_ph_number);
			 $user = get_userdata( $user_idss );
			 $chek = wp_check_password( $old_pass, $user->data->user_pass, $user_idss);
			 if($chek==true)
			 {
				wp_set_password( $new_pass, $user_idss );
				$get_current_user_ingfo = get_user_by('id', $user_idss); 
				$user_email = $get_current_user_ingfo->user_email;
				#print_r($user_email);
				##### Password Reset EMAIL#######
                $to = $user_email;
                $subject = "Ecour-Password Changed";
                $message = '
                        <html align="center">
                        <head>
                        <title>Password Changed</title>
                        </head>
                        <body>
                        <h1>Your Password Has Been Changed</h1>
                        <p>Your Password has been changed using your Ecour Account:  '.$user_email.' </p>
                   		<p>Please click this link to see your Profile:' . get_permalink(get_page_by_path('ecour-profile-page')).'/'.$user_idss.'</p>
                        </body>
                        </html>
                        ';
                # Always set content-type when sending HTML email
                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                # More headers
                $headers .= 'From: <webmaster@example.com>' . "\r\n";
                $headers .= 'Cc: ayesha.aimviz@gmail.com' . "\r\n";
                $email_sent = mail($to, $subject, $message, $headers);
                #####  Password Reset EMAIL#######
			 }
			 //echo 'DONE!';
		 }
	} 
}
?>