<?php

class Users {

    function __construct()
    {
        /*# START database configuration
        $dbServer = 'localhost'; //Define database server host
        $dbUsername = 'root'; //Define database username
        $dbPassword = ''; //Define database password
        #$dbName = 'codexworld'; //Define database name
        $dbName = 'users'; //Define database name

        #connect databse
        $con = mysqli_connect($dbServer,$dbUsername,$dbPassword,$dbName);
        if(mysqli_connect_errno())
        {
            die("Failed to connect with MySQL: ".mysqli_connect_error());
        }
        else
        {
            $this->connect = $con;
        }
        # END database configuration*/

    }

    ###START FOR PROFILE CONNECTION###
    function checkUser($oauth_provider='',$oauth_uid='',$fname='',$lname='',$email='',$gender='',$locale='',$picture='')
    {
        // WP INSERT USER

        #Start the session
        ### FOR SIGN UP  ###
        session_start();
        $_SESSION["oauth_provider"] = $oauth_provider;
        $_SESSION["first_name"] = $fname;
        $_SESSION["last_name"] = $lname;
        $_SESSION["oauth_uid"] = $oauth_uid;
        $_SESSION["user_email"] = $email;
        $_SESSION["picture"] = $picture;


        $sign_session = array(
            'oauth_provider'=> $_SESSION["oauth_provider"],
            'first_name'=>  $_SESSION["first_name"],
            'last_name'=> $_SESSION["last_name"],
            'oauth_uid'=> $_SESSION["oauth_uid"],
            'user_email'=>$_SESSION["user_email"],
            'picture'=>$_SESSION["picture"]
        );
        return $sign_session;
        ### FOR SIGN UP  ###


        ### FOR PROFILE PAGE  ###
        $user_id = get_current_user_id();
        $oauth_provider = get_user_meta($user_id,'oauth_provider',true);
        $oauth_uid = get_user_meta($user_id,'oauth_uid',true);

        if ((!empty($oauth_provider)) && (!empty($oauth_uid)) )
        {
            $oauth_provider = update_user_meta($user_id,'oauth_provider',$oauth_provider);
            $oauth_uid = update_user_meta($user_id,'oauth_uid',$oauth_uid);
            $fb_verify = update_user_meta($user_id,'fb_verify','true');
            $fb_email = update_user_meta($user_id,'fb_email','true');
        }
        else
        {
            $oauth_provider = add_user_meta($user_id,'oauth_provider',$oauth_provider);
            $oauth_uid = add_user_meta($user_id,'oauth_uid',$oauth_uid);
            $fb_verify = update_user_meta($user_id,'fb_verify','true');
/*          $fb_verify = add_user_meta($user_id,'fb_verify','false');
            $fb_email = add_user_meta($user_id,'fb_email','false');*/
        }

        $user_info = get_userdata($user_id);
        $user_email = ($user_info->user_email);
        $user_first_name = get_user_meta($user_id,'first_name',true);
        $user_last_name = get_user_meta($user_id,'last_name',true);
        $get_oauth_provider = get_user_meta($user_id,'oauth_provider',true);
        $get_oauth_uid = get_user_meta($user_id,'oauth_uid',true);

       /* $fb_verify = update_user_meta($user_id,'fb_verify','true');
        $fb_email = update_user_meta($user_id,'fb_email','true');*/

        $fb_user_detail = array(
            'user_email' =>$user_email,
            'first_name' =>$user_first_name,
            'last_name' =>$user_last_name,
            'oauth_provider' =>$get_oauth_provider,
            'oauth_uid' =>$get_oauth_uid,
        );
        return $fb_user_detail;
        ### FOR PROFILE PAGE  ###

    }
    ###END FOR PROFILE CONNECTION###

    ###START FOR PROFILE CONNECTION###
    function signupUser($oauth_provider='',$oauth_uid='',$fname='',$lname='',$email='',$gender='',$locale='',$picture='')
    {

        $user_id = get_current_user_id();
        $u_id='';

        if (!empty($user_id))
        {
            $oauth_provider = update_user_meta($user_id,'oauth_provider',$oauth_provider);
            $oauth_uid = update_user_meta($user_id,'oauth_uid',$oauth_uid);
            $fb_verify = update_user_meta($user_id,'fb_verify','true');
            $fb_email = update_user_meta($user_id,'fb_email','true');

        }
        else
        {
            $username = $fname.'_'.$lname;
            $user_email = $email;
            $display_name = $fname.' '.$lname;
            $user_info = array(
                'user_login' => $username,
                'user_email' => $user_email,
                //'user_pass' => $res['password'],
                'display_name' => $display_name,
                'role' => 'subscriber',
            );

            #USER INSERT FUNCTION
            $u_id = wp_insert_user($user_info);
            $picture = update_user_meta($u_id,'',$picture);
            $fname = update_user_meta($u_id,'first_name',$fname);
            $lname = update_user_meta($u_id,'last_name',$lname);

            $oauth_provider = update_user_meta($u_id,'oauth_provider',$oauth_provider);
            $oauth_uid = update_user_meta($u_id,'oauth_uid',$oauth_uid);
            $fb_verify = update_user_meta($u_id,'fb_verify','true');
            $fb_email= update_user_meta($u_id,'fb_email','true');

        }

        $user_info = get_userdata($u_id);
        $user_email = ($user_info->user_email);
        $user_first_name = get_user_meta($u_id,'first_name',true);
        $user_last_name = get_user_meta($u_id,'last_name',true);
        $get_oauth_provider = get_user_meta($u_id,'oauth_provider',true);
        $get_oauth_uid = get_user_meta($u_id,'oauth_uid',true);

        /* $fb_verify = update_user_meta($user_id,'fb_verify','true');
         $fb_email = update_user_meta($user_id,'fb_email','true');*/

        $fb_user_signup = array(
            'user_email' =>$user_email,
            'first_name' =>$user_first_name,
            'last_name' =>$user_last_name,
            'oauth_provider' =>$get_oauth_provider,
            'oauth_uid' =>$get_oauth_uid,
        );
        return $fb_user_signup;


    }
    ###END FOR PROFILE CONNECTION###



}
?>