<?php
include_once("config.php");
//if(array_key_exists('logout',$_GET))
if(isset($_GET['logout']))
{
    $facebook->getLogoutUrl();

	$facebook->destroySession();
	#session_start();
	#unset($_SESSION['userdata']);
	#session_destroy();
	#header("Location:index.php");
	header("Location:http://110.37.221.34:7777/blog/wordpress/ecour-forms/");

    /*$url = site_url().'/ecour-forms';
    wp_redirect( $url );
    exit;*/

}
?>