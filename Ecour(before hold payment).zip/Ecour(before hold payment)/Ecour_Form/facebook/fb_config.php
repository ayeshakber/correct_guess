<?php
include_once("inc/facebook.php"); //include facebook SDK
######### Facebook API Configuration ##########
########## https://developers.facebook.com/ ##############
########## APPLICATION NAME "Ecour Signup" ##############

#$appId = '208244329588718'; //Facebook App ID
#$appSecret = '7ce849da1d1fbdb40e04384b3b950b28'; // Facebook App Secret

$appId = '982217018574488'; //Facebook App ID 2nd waseem personal ID
$appSecret = '25d89c61b34ce932a0dcd1a3963289a5'; // Facebook App Secret 2nd waseem personal ID

$homeurl = site_url(). '/ecour-profile-page';  //return to profile page
$homeurl_singup = site_url(). '/my-registration';   //return to home

$homeurl_task = site_url(). '/new'; 	//return to task page

//$homeurl_task = site_url(). '/new/?task_id='.$_SESSION['post_ID']; 	//return to task page


/* $homeurl = get_permalink( get_page_by_path( 'ecour-profile-page' ) );  //return to profile page
$homeurl_singup = get_permalink( get_page_by_path( 'my-registration' ) );  //return to home
$homeurl_task = get_permalink( get_page_by_path( 'new' ) );  //return to task page */
$fbPermissions = 'email';  //Required facebook permissions

//Call Facebook API
$facebook = new Facebook(array(
    'appId'  => $appId,
    'secret' => $appSecret

));
$fbuser = $facebook->getUser();
//$user_id= get_current_user_id();
/*$fb_verify = get_user_meta($user_id,'fb_verify',true);
if(!empty($fb_verify))
{
    $fbuser = 0;
}
else
{
    $fbuser = 1;
}*/

$abc  = $facebook->getLoginUrl();

?>